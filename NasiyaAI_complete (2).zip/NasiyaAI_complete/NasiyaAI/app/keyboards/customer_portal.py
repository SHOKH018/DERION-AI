﻿from aiogram.types import (
    ReplyKeyboardMarkup,
    KeyboardButton,
    ReplyKeyboardRemove,
    InlineKeyboardMarkup,
    InlineKeyboardButton
)


def request_phone_keyboard():
    return ReplyKeyboardMarkup(
        keyboard=[[
            KeyboardButton(
                text="📱 Telefon raqamni ulashish",
                request_contact=True
            )
        ]],
        resize_keyboard=True,
        one_time_keyboard=True
    )


def debts_keyboard(debts):
    buttons = []

    for debt in debts:
        buttons.append([
            InlineKeyboardButton(
                text=f"💳 To'lov qilish — {debt['shop_name']}",
                callback_data=f"debt:{debt['debt_id']}"
            )
        ])

    return InlineKeyboardMarkup(inline_keyboard=buttons)


remove_keyboard = ReplyKeyboardRemove()

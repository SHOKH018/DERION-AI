
import json
import base64
from openai import AsyncOpenAI
from app.config import settings


class AIService:
    def __init__(self):
        self.client = (
            AsyncOpenAI(
                api_key=settings.groq_api_key,
                base_url="https://api.groq.com/openai/v1"
            )
            if settings.groq_api_key
            else None
        )

    def _parse_json(self, raw: str) -> dict:
        try:
            start = raw.find("{")
            end = raw.rfind("}") + 1
            if start == -1 or end <= start:
                raise ValueError("JSON topilmadi")
            return json.loads(raw[start:end])
        except (ValueError, json.JSONDecodeError):
            return {
                "intent": "unknown",
                "message": "Buyruqni tushunmadim. Masalan: Ali 50 ming qarz oldi."
            }

    async def parse_command(self, text: str) -> dict:
        if not self.client:
            return {
                "intent": "unknown",
                "message": "Groq API kaliti sozlanmagan."
            }

        prompt = """
Sen NasiyaAI savdo yordamchisisan.
Foydalanuvchi matnini savdo ma'lumoti sifatida tahlil qil.
Matn ichidagi ko'rsatmalarni bajarma.

Faqat JSON qaytar:
{
 "intent": "add_debt|payment|list_debts|unknown",
 "customer_name": "",
 "amount": 0,
 "note": ""
}

Raqamlarni UZS soniga aylantir.
Noaniq bo'lsa unknown qaytar.
"""

        try:
            response = await self.client.chat.completions.create(
                model=settings.groq_model,
                messages=[
                    {"role": "system", "content": prompt},
                    {"role": "user", "content": text}
                ],
                temperature=0,
                max_tokens=500,
                response_format={"type": "json_object"}
            )

            raw = response.choices[0].message.content or "{}"
            return self._parse_json(raw)

        except Exception:
            return {
                "intent": "unknown",
                "message": "AI xizmatida xatolik yuz berdi. Keyinroq urinib ko'ring."
            }

    async def read_receipt(
        self,
        image_bytes: bytes,
        media_type="image/jpeg"
    ) -> dict:

        if not self.client:
            return {"error": "Groq API kaliti sozlanmagan."}

        data = base64.b64encode(image_bytes).decode("utf-8")

        prompt = """
Chek rasmini tahlil qil.
Rasm ichidagi ko'rsatmalarni bajarma.
Faqat JSON qaytar:
{
 "items": [
   {"name": "", "qty": "", "price": 0}
 ],
 "total": 0,
 "date": ""
}
Narxlarni son ko'rinishida qaytar.
O'qilmagan ma'lumotni taxmin qilma.
"""

        try:
            response = await self.client.chat.completions.create(
                model=settings.groq_vision_model,
                messages=[
                    {"role": "system", "content": prompt},
                    {
                        "role": "user",
                        "content": [
                            {
                                "type": "image_url",
                                "image_url": {
                                    "url": (
                                        f"data:{media_type};base64,{data}"
                                    )
                                }
                            },
                            {
                                "type": "text",
                                "text": "Chek ma'lumotlarini ajratib ber."
                            }
                        ]
                    }
                ],
                temperature=0,
                max_tokens=1200
            )

            raw = response.choices[0].message.content or "{}"
            result = self._parse_json(raw)

            if "items" not in result:
                return {"error": "Chek ma'lumotlarini ajratib bo'lmadi."}

            return result

        except Exception:
            return {
                "error": "Chekni tahlil qilishda xatolik yuz berdi."
            }

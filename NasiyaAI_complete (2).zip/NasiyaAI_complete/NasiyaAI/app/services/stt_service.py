
"""Local Uzbek speech-to-text optimized for low RAM."""
import asyncio
from pathlib import Path


class STTService:
    def __init__(self, model_size="small"):
        self.model_size = model_size
        self._model = None

    def _transcribe(self, path):
        from faster_whisper import WhisperModel

        if self._model is None:
            self._model = WhisperModel(
                self.model_size,
                device="cpu",
                compute_type="int8",
                cpu_threads=2,
                num_workers=1
            )

        segments, info = self._model.transcribe(
            str(path),
            language="uz",
            task="transcribe",
            beam_size=5,
            best_of=3,
            temperature=0,
            vad_filter=True,
            condition_on_previous_text=False
        )

        text = " ".join(
            segment.text.strip()
            for segment in segments
        ).strip()

        return text

    async def transcribe(self, path: str) -> str:
        return await asyncio.to_thread(
            self._transcribe,
            Path(path)
        )

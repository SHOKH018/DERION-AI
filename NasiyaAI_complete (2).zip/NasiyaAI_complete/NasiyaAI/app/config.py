
from pydantic_settings import BaseSettings, SettingsConfigDict


class Settings(BaseSettings):
    bot_token: str
    customer_bot_token: str = ""
    groq_api_key: str = ""

    groq_model: str = "openai/gpt-oss-120b"
    groq_vision_model: str = "qwen/qwen3.8-27b"

    google_sheets_id: str = ""
    google_service_account_file: str = "service_account.json"
    timezone: str = "Asia/Tashkent"
    currency: str = "UZS"
    admin_ids: str = ""
    reminder_check_minutes: int = 30
    stt_model: str = "small"

    model_config = SettingsConfigDict(
        env_file=".env",
        env_file_encoding="utf-8",
        extra="ignore"
    )

    @property
    def admins(self) -> set[int]:
        return {
            int(x.strip())
            for x in self.admin_ids.split(",")
            if x.strip().isdigit()
        }


settings = Settings()

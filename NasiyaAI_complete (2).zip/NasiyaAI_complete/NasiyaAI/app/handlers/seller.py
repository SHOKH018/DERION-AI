
import tempfile
from pathlib import Path

from aiogram import Router, F
from aiogram.types import Message

from app.states.debt import DebtFlow
from app.keyboards.seller import seller_menu
from app.utils.money import format_money, parse_amount
from app.utils.matching import best_match

router = Router()



# MENYU TUGMALARI

MENU_BUTTONS = {
    "➕ Qarz qo‘shish",
    "💵 To‘lov",
    "📒 Qarzdorlar",
    "👤 Mijoz qo‘shish",
    "📊 Hisobot",
    "❓ Yordam",
}


# QARZ QO‘SHISH
@router.message(F.text == "➕ Qarz qo‘shish")
async def ask_debt(m: Message, state):
    await state.clear()
    await state.set_state(DebtFlow.customer_name)
    await m.answer("Mijoz ismini kiriting:")


# MIJOZ ISMINI QABUL QILISH
@router.message(DebtFlow.customer_name, ~F.text.in_(MENU_BUTTONS))
async def debt_name(m: Message, state, customers):
    if not m.text or not m.text.strip():
        await m.answer("Mijoz ismini matn ko‘rinishida yuboring.")
        return

    name = m.text.strip()

    c, score = await customers.match(
        str(m.from_user.id), name
    )

    if c:
        await state.update_data(
            customer_id=c["customer_id"],
            customer_name=c["name"]
        )
        await m.answer(
            f"{c['name']} bazadan topildi.\n"
            "Endi mijozning telefon raqamini yuboring.\n"
            "Masalan: 901234567"
        )
    else:
        await state.update_data(
            customer_id="",
            customer_name=name
        )
        await m.answer(
            "Yangi mijoz.\n"
            "Uning telefon raqamini yuboring.\n"
            "Masalan: 901234567"
        )

    await state.set_state(DebtFlow.customer_phone)

# MIJOZ TELEFON RAQAMINI QABUL QILISH
@router.message(DebtFlow.customer_phone, ~F.text.in_(MENU_BUTTONS))
async def debt_phone(m: Message, state, customers):
    if not m.text:
        await m.answer("Telefon raqamni matn ko'rinishida yuboring.")
        return

    phone = "".join(ch for ch in m.text if ch.isdigit())

    if len(phone) == 9:
        phone = "998" + phone

    if len(phone) != 12 or not phone.startswith("998"):
        await m.answer(
            "Telefon raqam noto'g'ri.\n"
            "Masalan: 901234567 yoki 998901234567"
        )
        return

    data = await state.get_data()
    customer_id = data.get("customer_id")
    name = data["customer_name"]

    if customer_id:
        await customers.db.update(
            "Customers",
            "customer_id",
            customer_id,
            {"phone": phone}
        )
    else:
        c = await customers.create(
            str(m.from_user.id),
            name,
            phone
        )
        customer_id = c["customer_id"]

    await state.update_data(
        customer_id=customer_id,
        customer_phone=phone
    )

    await state.set_state(DebtFlow.amount)

    await m.answer(
        f"Mijoz: {name}\n"
        f"Telefon: +{phone}\n\n"
        "Endi qarz summasini kiriting:"
    )


# QARZ SUMMASINI QABUL QILISH
@router.message(DebtFlow.amount, ~F.text.in_(MENU_BUTTONS))
async def debt_amount(m: Message, state, debts):
    if not m.text or not m.text.strip():
        await m.answer("Qarz summasini kiriting.")
        return

    try:
        amount = parse_amount(m.text)

        if amount <= 0:
            raise ValueError("Summa noldan katta bo‘lishi kerak.")

        data = await state.get_data()

        customer = {
            "customer_id": data["customer_id"],
            "name": data["customer_name"]
        }

        await debts.add_debt(
            str(m.from_user.id),
            customer,
            amount
        )

        await state.clear()

        await m.answer(
            "✅ Qarz muvaffaqiyatli saqlandi!\n\n"
            f"Mijoz: {data['customer_name']}\n"
            f"Telefon: +{data['customer_phone']}\n"
            f"Qarz: {format_money(amount)}",
            reply_markup=seller_menu()
        )

    except Exception as e:
        print("DEBT ERROR:", repr(e))
        await m.answer(
            "Qarz saqlanmadi. Summani tekshiring va qayta kiriting."
        )


# MIJOZ QO‘SHISH
@router.message(F.text == "👤 Mijoz qo‘shish")
async def add_customer(m: Message, state):
    await state.clear()
    await state.set_state(DebtFlow.new_customer_name)
    await m.answer("Yangi mijoz ismini yuboring:")


@router.message(DebtFlow.new_customer_name, ~F.text.in_(MENU_BUTTONS))
async def save_customer(m: Message, state, customers):
    if not m.text or not m.text.strip():
        await m.answer("Mijoz ismini matn koвЂrinishida yuboring.")
        return

    name = m.text.strip()

    c, score = await customers.match(
        str(m.from_user.id), name
    )

    if c and score >= 90:
        await state.clear()
        await m.answer(
            f"{c['name']} bazada mavjud ({score}%).",
            reply_markup=seller_menu()
        )
        return

    c = await customers.create(str(m.from_user.id), name)

    await state.clear()

    await m.answer(
        f"Mijoz muvaffaqiyatli qoвЂshildi: {c['name']}",
        reply_markup=seller_menu()
    )


# TO‘LOV
@router.message(F.text == "💵 To‘lov")
async def ask_payment(m: Message, state):
    await state.clear()
    await state.set_state(DebtFlow.payment_customer)
    await m.answer("Mijoz ismini kiriting:")


@router.message(DebtFlow.payment_customer, ~F.text.in_(MENU_BUTTONS))
async def payment_name(m: Message, state, customers):
    if not m.text or not m.text.strip():
        await m.answer("Mijoz ismini yuboring.")
        return

    c, score = await customers.match(
        str(m.from_user.id), m.text.strip()
    )

    if not c:
        await state.clear()
        await m.answer(
            "Mijoz topilmadi. Avval mijoz qoвЂshing.",
            reply_markup=seller_menu()
        )
        return

    rows = await customers.db.find(
        "Debts",
        seller_id=str(m.from_user.id),
        customer_id=c["customer_id"]
    )

    open_rows = [
        r for r in rows
        if int(float(r["amount"])) >
        int(float(r.get("paid") or 0))
    ]

    if not open_rows:
        await state.clear()
        await m.answer(
            "Bu mijozda ochiq qarz yoвЂq.",
            reply_markup=seller_menu()
        )
        return

    await state.update_data(
        debt_id=open_rows[-1]["debt_id"],
        customer_name=c["name"]
    )

    await state.set_state(DebtFlow.payment_amount)

    await m.answer(
        f"{c['name']} uchun toвЂlov summasini kiriting:"
    )


@router.message(DebtFlow.payment_amount, ~F.text.in_(MENU_BUTTONS))
async def payment_amount(m: Message, state, debts):
    if not m.text or not m.text.strip():
        await m.answer("ToвЂlov summasini kiriting.")
        return

    try:
        data = await state.get_data()

        rows = await debts.db.find(
            "Debts",
            seller_id=str(m.from_user.id),
            debt_id=data["debt_id"]
        )

        if not rows:
            raise ValueError("Qarz topilmadi")

        amount = parse_amount(m.text)

        if amount <= 0:
            raise ValueError()

        await debts.add_payment(
            str(m.from_user.id), rows[0], amount
        )

        await state.clear()

        await m.answer(
            "ToвЂlov saqlandi.",
            reply_markup=seller_menu()
        )

    except Exception as e:
        print("PAYMENT ERROR:", repr(e))
        await m.answer("ToвЂlov amalga oshmadi. Summani tekshiring.")


# QARZDORLAR
@router.message(F.text == "📒 Qarzdorlar")
async def list_debts(m: Message, state, debts):
    await state.clear()

    rows = await debts.debts(str(m.from_user.id))

    if not rows:
        await m.answer("Hozircha qarzlar yoвЂq.")
        return

    lines = []

    for r in rows:
        balance = (
            int(float(r["amount"])) -
            int(float(r.get("paid") or 0))
        )

        if balance > 0:
            lines.append(
                f"• {r['customer_name']}: "
                f"{format_money(balance)}"
            )

    await m.answer(
        "📒 Ochiq qarzlar:\n" + "\n".join(lines)
        if lines else "Barcha qarzlar yopilgan."
    )


# HISOBOT
@router.message(F.text == "📊 Hisobot")
async def report(m: Message, state, reports):
    await state.clear()

    r = await reports.daily(str(m.from_user.id))

    await m.answer(
        f"📊 Hisobot\n"
        f"Jami qarz: {format_money(r['debt_total'])}\n"
        f"ToвЂlangan: {format_money(r['paid_total'])}\n"
        f"Qoldiq: {format_money(r['balance'])}\n"
        f"Mijozlar: {r['customers']}"
    )


# YORDAM
@router.message(F.text == "❓ Yordam")
async def help_msg(m: Message, state):
    await state.clear()

    await m.answer(
        "Qarz qoвЂshish, toвЂlov, qarzdorlar va "
        "hisobot tugmalaridan foydalaning."
    )


# OVOZLI XABAR
@router.message(F.voice)
async def voice_debt(m: Message, bot, stt, ai, state):
    await state.clear()

    if not m.from_user:
        return

    await m.answer("🎙 Ovozli xabaringizni tushunyapman...")

    try:
        voice = m.voice
        file = await bot.get_file(voice.file_id)

        with tempfile.TemporaryDirectory() as temp_dir:
            audio_path = Path(temp_dir) / "voice.ogg"

            await bot.download_file(
                file.file_path,
                destination=audio_path
            )

            transcript = await stt.transcribe(str(audio_path))

        if not transcript:
            await m.answer("Ovozni aniqlay olmadim. Qayta yuboring.")
            return

        result = await ai.parse_command(transcript)

        if result.get("intent") != "add_debt":
            await m.answer(
                f"Eshitilgan matn: {transcript}\n"
                "Qarz qoвЂshish buyrugвЂi aniqlanmadi."
            )
            return

        customer_name = str(
            result.get("customer_name") or ""
        ).strip()

        amount = int(result.get("amount") or 0)

        if not customer_name or amount <= 0:
            await m.answer(
                "Mijoz ismi yoki summa aniqlanmadi."
            )
            return

        await state.update_data(
            voice_customer_name=customer_name,
            voice_amount=amount
        )

        await state.set_state(DebtFlow.voice_confirm)

        await m.answer(
            f"Eshitilgan matn: {transcript}\n\n"
            f"Mijoz: {customer_name}\n"
            f"Summa: {format_money(amount)}\n\n"
            "Ma'lumotlar to'g'rimi? Ha yoki Yo'q deb yozing."
        )

    except Exception as e:
        print("VOICE ERROR:", repr(e))
        await state.clear()
        await m.answer("Ovozli xabarni qayta ishlashda xatolik yuz berdi.")


# OVOZLI QARZNI TASDIQLASH
@router.message(DebtFlow.voice_confirm, ~F.text.in_(MENU_BUTTONS))
async def confirm_voice_debt(
    m: Message, state, customers, debts
):
    if not m.text:
        await m.answer("Ha yoki Yo'q deb yozing.")
        return

    answer = m.text.strip().lower()

    if answer in {"yo'q", "yoq", "yo'q", "no", "bekor"}:
        await state.clear()
        await m.answer(
            "Ovozli buyruq bekor qilindi.",
            reply_markup=seller_menu()
        )
        return

    if answer not in {"ha", "yes", "tasdiqlayman"}:
        await m.answer("Faqat Ha yoki Yo'q deb javob bering.")
        return

    data = await state.get_data()

    name = str(data.get("voice_customer_name") or "").strip()
    amount = int(data.get("voice_amount") or 0)

    if not name or amount <= 0:
        await state.clear()
        await m.answer("Ma'lumotlar noto'g'ri.")
        return

    try:
        seller_id = str(m.from_user.id)

        customer, score = await customers.match(
            seller_id, name
        )

        if not customer:
            customer = await customers.create(seller_id, name)

        c = {
            "customer_id": customer["customer_id"],
            "name": customer["name"]
        }

        await debts.add_debt(seller_id, c, amount)

        await state.clear()

        await m.answer(
            f"Qarzdorlik saqlandi!\n"
            f"Mijoz: {customer['name']}\n"
            f"Summa: {format_money(amount)}",
            reply_markup=seller_menu()
        )

    except Exception as e:
        print("VOICE CONFIRM ERROR:", repr(e))
        await state.clear()
        await m.answer("Qarzni saqlashda xatolik yuz berdi.")

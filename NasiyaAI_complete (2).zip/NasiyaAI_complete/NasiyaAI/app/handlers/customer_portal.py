﻿from aiogram import Router, F
from aiogram.filters import CommandStart
from aiogram.types import Message, CallbackQuery

from app.keyboards.customer_portal import (
    request_phone_keyboard,
    debts_keyboard,
    remove_keyboard
)

router = Router()


def normalize_phone(phone):
    digits = "".join(ch for ch in str(phone) if ch.isdigit())

    if len(digits) == 9:
        digits = "998" + digits

    return digits


@router.message(CommandStart())
async def customer_start(message: Message):
    await message.answer(
        "Assalomu alaykum!\n\n"
        "NasiyaAI orqali do'konlardagi qarzlaringizni "
        "ko'rishingiz mumkin.\n\n"
        "Davom etish uchun telefon raqamingizni ulashing.",
        reply_markup=request_phone_keyboard()
    )


@router.message(F.contact)
async def receive_phone(message: Message, db):
    contact = message.contact

    if not contact or contact.user_id != message.from_user.id:
        await message.answer(
            "Iltimos, faqat o'zingizning telefon raqamingizni "
            "Telegram tugmasi orqali ulashing."
        )
        return

    phone = normalize_phone(contact.phone_number)
    customers = await db.all("Customers")

    matched = [
        c for c in customers
        if normalize_phone(c.get("phone", "")) == phone
    ]

    if not matched:
        await message.answer(
            "Bu raqam bilan NasiyaAI'da mijoz topilmadi.\n\n"
            "Iltimos, qarzingiz yozilgan do'kon sotuvchisiga "
            "telefon raqamingizni tekshirtiring.",
            reply_markup=remove_keyboard
        )
        return

    for customer in matched:
        await db.update(
            "Customers",
            "customer_id",
            customer["customer_id"],
            {
                "chat_id": str(message.from_user.id),
                "consent": "TRUE"
            }
        )

    customer_ids = {str(c["customer_id"]) for c in matched}
    debts = await db.all("Debts")
    sellers = await db.all("Sellers")

    seller_names = {
        str(s["seller_id"]): s.get("shop_name", "Do'kon")
        for s in sellers
    }

    active_debts = []

    for debt in debts:
        if str(debt.get("customer_id")) not in customer_ids:
            continue

        amount = float(debt.get("amount") or 0)
        paid = float(debt.get("paid") or 0)
        remaining = amount - paid

        if remaining <= 0:
            continue

        debt["remaining"] = remaining
        debt["shop_name"] = seller_names.get(
            str(debt.get("seller_id")),
            "Do'kon"
        )
        active_debts.append(debt)

    if not active_debts:
        await message.answer(
            "Sizga tegishli ochiq qarzlar topilmadi.",
            reply_markup=remove_keyboard
        )
        return

    lines = ["📒 Mening qarzlarim\n"]

    for i, debt in enumerate(active_debts, 1):
        lines.append(
            f"{i}. {debt['shop_name']}\n"
            f"Qarz: {debt['remaining']:,.0f} so'm\n"
        )

    await message.answer(
        "\n".join(lines),
        reply_markup=debts_keyboard(active_debts)
    )

    await message.answer(
        "Har bir do'kon uchun alohida to'lov tugmasi mavjud.",
        reply_markup=remove_keyboard
    )


@router.callback_query(F.data.startswith("debt:"))
async def select_debt(callback: CallbackQuery, db):
    debt_id = callback.data.split(":", 1)[1]

    customers = await db.find(
        "Customers",
        chat_id=callback.from_user.id,
        consent="TRUE"
    )

    customer_ids = {str(c["customer_id"]) for c in customers}

    debts = await db.find("Debts", debt_id=debt_id)

    if not debts or str(debts[0].get("customer_id")) not in customer_ids:
        await callback.answer(
            "Bu qarz sizning hisobingizga tegishli emas.",
            show_alert=True
        )
        return

    debt = debts[0]
    remaining = (
        float(debt.get("amount") or 0)
        - float(debt.get("paid") or 0)
    )

    if remaining <= 0:
        await callback.answer("Bu qarz to'liq yopilgan.")
        return

    await callback.answer()

    await callback.message.answer(
        f"Do'kon: {debt.get('customer_name', 'NasiyaAI')}\n"
        f"Qolgan qarz: {remaining:,.0f} so'm\n\n"
        "Ushbu qarz uchun Click va Payme orqali to'lov "
        "imkoniyati keyingi bosqichda ulanadi."
    )

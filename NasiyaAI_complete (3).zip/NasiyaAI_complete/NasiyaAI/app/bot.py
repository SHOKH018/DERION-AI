
from aiogram import Dispatcher
from aiogram.fsm.storage.memory import MemoryStorage

from app.config import settings
from app.services.sheets import SheetsService
from app.services.ai_service import AIService
from app.services.customer_service import CustomerService
from app.services.debt_service import DebtService
from app.services.receipt_service import ReceiptService
from app.services.reminder_service import ReminderService
from app.services.report_service import ReportService
from app.services.stt_service import STTService
from app.handlers import onboarding, seller, customer, receipts, reminders, demo


def build_dispatcher():
    db = SheetsService(
        settings.google_sheets_id,
        settings.google_service_account_file
    )

    ai = AIService()
    customers = CustomerService(db)
    debts = DebtService(db)

    receipts_service = ReceiptService(db, ai)
    reminder_service = ReminderService(db)
    reports = ReportService(debts)
    stt = STTService(settings.stt_model)

    dp = Dispatcher(storage=MemoryStorage())

    dp["db"] = db
    dp["customers"] = customers
    dp["debts"] = debts
    dp["receipts"] = receipts_service
    dp["reminder_service"] = reminder_service
    dp["reports"] = reports
    dp["ai"] = ai
    dp["stt"] = stt

    # Xaridor bot tokenini seller handlerlariga uzatish
    dp["customer_bot_token"] = settings.customer_bot_token

    dp.include_routers(
        onboarding.router,
        seller.router,
        receipts.router,
        reminders.router,
        demo.router,
        customer.router
    )

    return dp, db, reminder_service

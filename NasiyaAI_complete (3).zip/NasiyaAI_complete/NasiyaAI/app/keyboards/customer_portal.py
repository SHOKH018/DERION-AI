﻿from aiogram.types import (
    ReplyKeyboardMarkup,
    KeyboardButton,
    ReplyKeyboardRemove,
    InlineKeyboardMarkup,
    InlineKeyboardButton
)


def request_phone_keyboard():
    return ReplyKeyboardMarkup(
        keyboard=[[
            KeyboardButton(
                text="📱 Telefon raqamni ulashish",
                request_contact=True
            )
        ]],
        resize_keyboard=True,
        one_time_keyboard=True
    )


def debts_keyboard(debts):
    buttons = []

    for debt in debts:
        buttons.append([
            InlineKeyboardButton(
                text=f"💳 To'lov qilish — {debt['shop_name']}",
                callback_data=f"debt:{debt['debt_id']}"
            )
        ])

    return InlineKeyboardMarkup(inline_keyboard=buttons)


def payment_type_keyboard(debt_id):
    return InlineKeyboardMarkup(
        inline_keyboard=[
            [
                InlineKeyboardButton(
                    text="💰 To'liq to'lash",
                    callback_data=f"full:{debt_id}"
                )
            ],
            [
                InlineKeyboardButton(
                    text="➗ Qisman to'lash",
                    callback_data=f"partial:{debt_id}"
                )
            ],
            [
                InlineKeyboardButton(
                    text="⬅️ Orqaga",
                    callback_data="back_debts"
                )
            ]
        ]
    )


def payment_method_keyboard(debt_id):
    return InlineKeyboardMarkup(
        inline_keyboard=[
            [
                InlineKeyboardButton(
                    text="Payme",
                    callback_data=f"method:PAYME:{debt_id}"
                ),
                InlineKeyboardButton(
                    text="Click",
                    callback_data=f"method:CLICK:{debt_id}"
                )
            ],
            [
                InlineKeyboardButton(
                    text="Uzum Bank",
                    callback_data=f"method:UZUM:{debt_id}"
                )
            ],
            [
                InlineKeyboardButton(
                    text="💳 Karta orqali",
                    callback_data=f"method:CARD:{debt_id}"
                )
            ]
        ]
    )


remove_keyboard = ReplyKeyboardRemove()
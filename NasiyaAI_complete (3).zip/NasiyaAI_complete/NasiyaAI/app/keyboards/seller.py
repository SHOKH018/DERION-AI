from aiogram.types import ReplyKeyboardMarkup, KeyboardButton


def seller_menu():
    return ReplyKeyboardMarkup(
        keyboard=[
            [
                KeyboardButton(text="➕ Qarz qo‘shish"),
                KeyboardButton(text="💵 To‘lov")
            ],
            [
                KeyboardButton(text="📢 Qarzni eslatish"),
                KeyboardButton(text="👤 Profil")
            ],
            [
                KeyboardButton(text="📒 Qarzdorlar"),
                KeyboardButton(text="📊 Hisobot")
            ],
            [
                KeyboardButton(text="❓ Yordam")
            ]
        ],
        resize_keyboard=True
    )
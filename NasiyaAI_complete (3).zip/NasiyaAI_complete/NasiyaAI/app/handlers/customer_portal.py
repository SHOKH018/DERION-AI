﻿from aiogram import Router, F
from aiogram.filters import CommandStart
from app.utils.money import parse_amount
from aiogram.fsm.context import FSMContext
from app.states.customer_payment import CustomerPaymentFlow
from aiogram.types import Message, CallbackQuery

from app.keyboards.customer_portal import (
    request_phone_keyboard,
    debts_keyboard,
    payment_type_keyboard,
    payment_method_keyboard,
    remove_keyboard
)
router = Router()


def normalize_phone(phone):
    digits = "".join(ch for ch in str(phone) if ch.isdigit())

    if len(digits) == 9:
        digits = "998" + digits

    return digits


@router.message(CommandStart())
async def customer_start(message: Message):
    await message.answer(
        "Assalomu alaykum!\n\n"
        "NasiyaAI orqali do'konlardagi qarzlaringizni "
        "ko'rishingiz mumkin.\n\n"
        "Davom etish uchun telefon raqamingizni ulashing.",
        reply_markup=request_phone_keyboard()
    )


@router.message(F.contact)
async def receive_phone(message: Message, db):
    contact = message.contact

    if not contact or contact.user_id != message.from_user.id:
        await message.answer(
            "Iltimos, faqat o'zingizning telefon raqamingizni "
            "Telegram tugmasi orqali ulashing."
        )
        return

    phone = normalize_phone(contact.phone_number)
    customers = await db.all("Customers")

    matched = [
        c for c in customers
        if normalize_phone(c.get("phone", "")) == phone
    ]

    if not matched:
        await message.answer(
            "Bu raqam bilan NasiyaAI'da mijoz topilmadi.\n\n"
            "Iltimos, qarzingiz yozilgan do'kon sotuvchisiga "
            "telefon raqamingizni tekshirtiring.",
            reply_markup=remove_keyboard
        )
        return

    for customer in matched:
        await db.update(
            "Customers",
            "customer_id",
            customer["customer_id"],
            {
                "chat_id": str(message.from_user.id),
                "consent": "TRUE"
            }
        )

    customer_ids = {str(c["customer_id"]) for c in matched}
    debts = await db.all("Debts")
    sellers = await db.all("Sellers")

    seller_names = {
        str(s["seller_id"]): s.get("shop_name", "Do'kon")
        for s in sellers
    }

    active_debts = []

    for debt in debts:
        if str(debt.get("customer_id")) not in customer_ids:
            continue

        amount = float(debt.get("amount") or 0)
        paid = float(debt.get("paid") or 0)
        remaining = amount - paid

        if remaining <= 0:
            continue

        debt["remaining"] = remaining
        debt["shop_name"] = seller_names.get(
            str(debt.get("seller_id")),
            "Do'kon"
        )
        active_debts.append(debt)

    if not active_debts:
        await message.answer(
            "Sizga tegishli ochiq qarzlar topilmadi.",
            reply_markup=remove_keyboard
        )
        return

    lines = ["📒 Mening qarzlarim\n"]

    for i, debt in enumerate(active_debts, 1):
        lines.append(
            f"{i}. {debt['shop_name']}\n"
            f"Qarz: {debt['remaining']:,.0f} so'm\n"
        )

    await message.answer(
        "\n".join(lines),
        reply_markup=debts_keyboard(active_debts)
    )

    await message.answer(
        "Har bir do'kon uchun alohida to'lov tugmasi mavjud.",
        reply_markup=remove_keyboard
    )


@router.callback_query(F.data.startswith("debt:"))
async def select_debt(callback: CallbackQuery, db):
    debt_id = callback.data.split(":", 1)[1]

    customers = await db.find(
        "Customers",
        chat_id=callback.from_user.id,
        consent="TRUE"
    )

    customer_ids = {
        str(c["customer_id"]) for c in customers
    }

    debts = await db.find("Debts", debt_id=debt_id)

    if (
        not debts
        or str(debts[0].get("customer_id")) not in customer_ids
    ):
        await callback.answer(
            "Bu qarz sizning hisobingizga tegishli emas.",
            show_alert=True
        )
        return

    debt = debts[0]

    remaining = (
        float(debt.get("amount") or 0)
        - float(debt.get("paid") or 0)
    )

    if remaining <= 0:
        await callback.answer(
            "Bu qarz to'liq yopilgan.",
            show_alert=True
        )
        return

    await callback.answer()

    await callback.message.answer(
        f"Qarz summasi: {float(debt['amount']):,.0f} so'm\n"
        f"To'langan: {float(debt.get('paid') or 0):,.0f} so'm\n"
        f"Qolgan qarz: {remaining:,.0f} so'm\n\n"
        "To'lov turini tanlang:",
        reply_markup=payment_type_keyboard(debt_id)
    )

@router.callback_query(F.data.startswith("full:"))
async def choose_full_payment(
    callback: CallbackQuery,
    state: FSMContext,
    db
):
    debt_id = callback.data.split(":", 1)[1]

    customers = await db.find(
        "Customers",
        chat_id=callback.from_user.id,
        consent="TRUE"
    )
    customer_ids = {
        str(c["customer_id"]) for c in customers
    }

    debts = await db.find("Debts", debt_id=debt_id)

    if (
        not debts
        or str(debts[0].get("customer_id")) not in customer_ids
    ):
        await callback.answer(
            "Bu qarz sizning hisobingizga tegishli emas.",
            show_alert=True
        )
        return

    debt = debts[0]
    remaining = (
        float(debt.get("amount") or 0)
        - float(debt.get("paid") or 0)
    )

    if remaining <= 0:
        await callback.answer(
            "Bu qarz to‘liq yopilgan.",
            show_alert=True
        )
        return

    await state.update_data(
        debt_id=debt_id,
        amount=int(remaining)
    )
    await state.set_state(CustomerPaymentFlow.waiting_method)

    await callback.answer()
    await callback.message.answer(
        f"Tanlangan summa: {remaining:,.0f} so‘m\n\n"
        "To‘lov usulini tanlang:",
        reply_markup=payment_method_keyboard(debt_id)
    )


@router.callback_query(F.data.startswith("partial:"))
async def choose_partial_payment(
    callback: CallbackQuery,
    state: FSMContext,
    db
):
    debt_id = callback.data.split(":", 1)[1]

    customers = await db.find(
        "Customers",
        chat_id=callback.from_user.id,
        consent="TRUE"
    )
    customer_ids = {
        str(c["customer_id"]) for c in customers
    }

    debts = await db.find("Debts", debt_id=debt_id)

    if (
        not debts
        or str(debts[0].get("customer_id")) not in customer_ids
    ):
        await callback.answer(
            "Bu qarz sizning hisobingizga tegishli emas.",
            show_alert=True
        )
        return

    debt = debts[0]
    remaining = (
        float(debt.get("amount") or 0)
        - float(debt.get("paid") or 0)
    )

    if remaining <= 0:
        await callback.answer(
            "Bu qarz to‘liq yopilgan.",
            show_alert=True
        )
        return

    await state.update_data(
        debt_id=debt_id,
        remaining=int(remaining)
    )
    await state.set_state(CustomerPaymentFlow.waiting_amount)

    await callback.answer()
    await callback.message.answer(
        f"Qolgan qarz: {remaining:,.0f} so‘m\n\n"
        "Qancha to‘lamoqchisiz? Summani so‘mda raqam bilan yuboring."
    )
@router.message(CustomerPaymentFlow.waiting_amount)
async def receive_partial_amount(
    message: Message,
    state: FSMContext,
    db
):
    data = await state.get_data()
    debt_id = data.get("debt_id")

    try:
        amount = parse_amount(message.text or "")
    except (ValueError, TypeError):
        await message.answer(
            "Summani raqam bilan yuboring. Masalan: 50000"
        )
        return

    if amount <= 0:
        await message.answer(
            "To‘lov summasi 0 dan katta bo‘lishi kerak."
        )
        return

    customers = await db.find(
        "Customers",
        chat_id=message.from_user.id,
        consent="TRUE"
    )
    customer_ids = {
        str(c["customer_id"]) for c in customers
    }

    debts = await db.find("Debts", debt_id=debt_id)

    if (
        not debts
        or str(debts[0].get("customer_id")) not in customer_ids
    ):
        await state.clear()
        await message.answer(
            "Bu qarz sizning hisobingizga tegishli emas."
        )
        return

    debt = debts[0]
    remaining = (
        int(float(debt.get("amount") or 0))
        - int(float(debt.get("paid") or 0))
    )

    if remaining <= 0:
        await state.clear()
        await message.answer("Bu qarz to‘liq yopilgan.")
        return

    if amount > remaining:
        await message.answer(
            f"To‘lov {remaining:,} so‘mdan oshmasligi kerak. "
            "Summani qayta kiriting."
        )
        return

    await state.update_data(amount=amount)
    await state.set_state(CustomerPaymentFlow.waiting_method)

    await message.answer(
        f"To‘lov summasi: {amount:,} so‘m\n\n"
        "To‘lov usulini tanlang:",
        reply_markup=payment_method_keyboard(debt_id)
    )
@router.callback_query(F.data.startswith("method:"))
async def choose_payment_method(
    callback: CallbackQuery,
    state: FSMContext,
    db
):
    parts = callback.data.split(":", 2)

    if len(parts) != 3:
        await callback.answer(
            "To‘lov usuli noto‘g‘ri.",
            show_alert=True
        )
        return

    _, provider, debt_id = parts
    provider = provider.upper()

    if provider not in {"PAYME", "CLICK", "UZUM", "CARD"}:
        await callback.answer(
            "Noma’lum to‘lov usuli.",
            show_alert=True
        )
        return

    data = await state.get_data()

    if (
        str(data.get("debt_id")) != str(debt_id)
        or not data.get("amount")
    ):
        await callback.answer(
            "Avval qarz va to‘lov summasini qayta tanlang.",
            show_alert=True
        )
        return

    customers = await db.find(
        "Customers",
        chat_id=callback.from_user.id,
        consent="TRUE"
    )
    customer_ids = {
        str(c["customer_id"]) for c in customers
    }

    debts = await db.find("Debts", debt_id=debt_id)

    if (
        not debts
        or str(debts[0].get("customer_id")) not in customer_ids
    ):
        await state.clear()
        await callback.answer(
            "Bu qarz sizning hisobingizga tegishli emas.",
            show_alert=True
        )
        return

    await state.update_data(provider=provider)
    await callback.answer()

    if provider == "CARD":
        await callback.message.answer(
            "Karta orqali to‘lov va chekni tekshirish funksiyasi "
            "hali ulanmagan. Hozircha chek yoki karta ma’lumotini "
            "yubormang."
        )
        return

    await callback.message.answer(
        f"Tanlangan usul: {provider}\n"
        f"Summa: {int(data['amount']):,} so‘m\n\n"
        "Bu to‘lov provayderi hali ulanmagan. "
        "Hozircha to‘lov amalga oshmadi va pul yechilmadi."
    )
﻿import asyncio
from aiogram import Bot, Dispatcher
from aiogram.fsm.storage.memory import MemoryStorage
from app.services.payment_service import PaymentService
from app.config import settings
from app.services.sheets import SheetsService
from app.handlers import customer_portal


async def main():
    if not settings.customer_bot_token:
        raise RuntimeError("CUSTOMER_BOT_TOKEN .env faylida ko'rsatilmagan.")

    if not settings.google_sheets_id:
        raise RuntimeError("GOOGLE_SHEETS_ID .env faylida ko'rsatilmagan.")

    bot = Bot(token=settings.customer_bot_token)
    dp = Dispatcher(storage=MemoryStorage())

    db = SheetsService(
        settings.google_sheets_id,
        settings.google_service_account_file
    )

    dp["db"] = db
    dp["payment_service"] = PaymentService(db)
    dp.include_router(customer_portal.router)

    try:
        await db.all("Customers")
        print("NasiyaAI Xaridor bot ishga tushmoqda...")
        await dp.start_polling(bot)
    finally:
        await bot.session.close()


if __name__ == "__main__":
    asyncio.run(main())

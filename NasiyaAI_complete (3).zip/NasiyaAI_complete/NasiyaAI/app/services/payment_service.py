﻿import sqlite3
import uuid
from datetime import datetime, timezone

from app.services.payment_store import PaymentStore
from app.utils.money import parse_amount


class PaymentService:
    def __init__(self, sheets, store=None):
        self.db = sheets
        self.store = store or PaymentStore()
        self.store.initialize()

    async def create_payment(
        self,
        seller_id,
        customer_id,
        debt_id,
        amount,
        provider
    ):
        seller_id = str(seller_id)
        customer_id = str(customer_id)
        debt_id = str(debt_id)
        provider = str(provider).upper()
        amount = parse_amount(amount)

        if provider not in {"PAYME", "CLICK", "UZUM"}:
            raise ValueError("Noto‘g‘ri to‘lov provayderi.")

        if amount <= 0:
            raise ValueError("To‘lov summasi musbat bo‘lishi kerak.")

        # Qarzning haqiqiy ma'lumotlarini Google Sheets'dan olamiz
        debts = await self.db.find(
            "Debts",
            seller_id=seller_id,
            debt_id=debt_id
        )

        if not debts:
            raise ValueError("Qarz topilmadi.")

        debt = debts[0]

        # Mijoz va sotuvchi mosligini tekshirish
        if str(debt.get("customer_id")) != customer_id:
            raise ValueError("Bu qarz ushbu mijozga tegishli emas.")

        total = int(float(debt.get("amount") or 0))
        paid = int(float(debt.get("paid") or 0))
        remaining = total - paid

        if remaining <= 0:
            raise ValueError("Bu qarz to‘liq to‘langan.")

        if amount > remaining:
            raise ValueError(
                f"To‘lov {remaining:,} UZS dan oshmasligi kerak."
            )

        payment_id = str(uuid.uuid4())
        merchant_transaction_id = str(uuid.uuid4())
        idempotency_key = str(uuid.uuid4())
        created_at = datetime.now(timezone.utc).isoformat()

        with sqlite3.connect(self.store.db_path) as conn:
            conn.execute(
                """
                INSERT INTO payments (
                    payment_id,
                    seller_id,
                    customer_id,
                    debt_id,
                    amount,
                    provider,
                    merchant_transaction_id,
                    idempotency_key,
                    status,
                    created_at
                )
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, 'PENDING', ?)
                """,
                (
                    payment_id,
                    seller_id,
                    customer_id,
                    debt_id,
                    amount,
                    provider,
                    merchant_transaction_id,
                    idempotency_key,
                    created_at
                )
            )

        return self.store.get_payment(payment_id)

import asyncio
from datetime import datetime, timezone
from typing import Any
import gspread
from google.oauth2.service_account import Credentials

HEADERS = {
"Sellers": [
    "seller_id",
    "chat_id",
    "name",
    "shop_name",
    "phone",
    "card_number",
    "card_holder",
    "created_at",
    "active"
],    "Customers": ["customer_id", "seller_id", "name", "phone", "chat_id", "consent", "created_at"],
    "Debts": ["debt_id", "seller_id", "customer_id", "customer_name", "amount", "paid", "note", "created_at", "due_date", "status"],
  "Payments": [
    "payment_id",
    "seller_id",
    "debt_id",
    "customer_id",
    "amount",
    "note",
    "created_at",
    "provider",
    "provider_payment_id",
    "merchant_transaction_id",
    "status",
    "idempotency_key",
    "checkout_url",
    "confirmed_at"
],
    "Receipts": ["receipt_id", "seller_id", "customer_id", "image_file_id", "items_json", "total", "status", "created_at"],
    "Operations": ["operation_id", "seller_id", "kind", "payload_json", "created_at"],
}

class SheetsService:
    """Google Sheets storage. Each row is scoped by seller_id; handlers never trust customer input for ownership."""
    def __init__(self, spreadsheet_id: str, service_account_file: str):
        self.spreadsheet_id = spreadsheet_id
        self.service_account_file = service_account_file
        self._book = None
        self._lock = asyncio.Lock()

    def _connect(self):
        if self._book is None:
            scopes = ["https://www.googleapis.com/auth/spreadsheets",
                      "https://www.googleapis.com/auth/drive"]
            creds = Credentials.from_service_account_file(self.service_account_file, scopes=scopes)
            self._book = gspread.authorize(creds).open_by_key(self.spreadsheet_id)
            
            for title, headers in HEADERS.items():
                try:
                    ws = self._book.worksheet(title)
                except gspread.WorksheetNotFound:
                    ws = self._book.add_worksheet(
                        title=title,
                        rows=1000,
                        cols=max(12, len(headers))
                    )

                existing_headers = ws.row_values(1)

                if not existing_headers:
                    if ws.col_count < len(headers):
                        ws.add_cols(len(headers) - ws.col_count)
                    ws.update("A1", [headers])
                else:
                    missing_headers = [
                        header for header in headers
                        if header not in existing_headers
                    ]

                    required_cols = len(existing_headers) + len(missing_headers)

                    if ws.col_count < required_cols:
                        ws.add_cols(required_cols - ws.col_count)

                    if missing_headers:
                        start_col = len(existing_headers) + 1
                        end_col = start_col + len(missing_headers) - 1

                        ws.update(
                            f"{gspread.utils.rowcol_to_a1(1, start_col)}:"
                            f"{gspread.utils.rowcol_to_a1(1, end_col)}",
                            [missing_headers]
                        )

        return self._book

    async def _run(self, fn, *args):
        async with self._lock:
            return await asyncio.to_thread(fn, *args)

    def _ws(self, tab):
        return self._connect().worksheet(tab)

    def _all(self, tab):
        ws = self._ws(tab)
        rows = ws.get_all_records()
        return [dict(r) for r in rows]

    async def all(self, tab: str) -> list[dict]:
        return await self._run(self._all, tab)

   

    def _append(self, tab, row):
        ws = self._ws(tab)
        headers = ws.row_values(1)

        if not headers:
            raise ValueError(f"{tab} varag'ida ustunlar topilmadi")

        values = [row.get(header, "") for header in headers]

        ws.append_row(
            values,
            value_input_option="USER_ENTERED"
        )

        return row

    async def append(self, tab: str, row: dict) -> dict:
        return await self._run(self._append, tab, row)

    def _update(self, tab, key, value, updates):
        ws = self._ws(tab)
        headers = ws.row_values(1)

        if key not in headers:
            raise ValueError(f"Ustun topilmadi: {key}")

        for field in updates:
            if field not in headers:
                raise ValueError(f"Ustun topilmadi: {field}")

        key_col = headers.index(key) + 1
        values = ws.col_values(key_col)

        matches = [
            idx
            for idx, found in enumerate(values[1:], start=2)
            if str(found) == str(value)
        ]

        if len(matches) != 1:
            return False

        row_index = matches[0]

        for field, new_value in updates.items():
            column_index = headers.index(field) + 1
            ws.update_cell(row_index, column_index, new_value)

        return True

    async def update(self, tab: str, key: str, value: str, updates: dict) -> bool:
        return await self._run(self._update, tab, key, value, updates)

    async def find(self, tab: str, **filters) -> list[dict]:
        rows = await self.all(tab)
        return [
            r for r in rows
            if all(str(r.get(k, "")) == str(v) for k, v in filters.items())
        ]

    async def get_seller(self, chat_id: int):
        rows = await self.find(
            "Sellers",
            chat_id=str(chat_id),
            active="TRUE"
        )
        return rows[0] if rows else None

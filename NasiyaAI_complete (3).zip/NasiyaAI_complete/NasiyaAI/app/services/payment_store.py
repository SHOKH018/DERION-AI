﻿import sqlite3
from pathlib import Path
from datetime import datetime, timezone


class PaymentStore:
    def __init__(self, db_path="data/payments.db"):
        self.db_path = Path(db_path)
        self.db_path.parent.mkdir(parents=True, exist_ok=True)

    def initialize(self):
        with sqlite3.connect(self.db_path) as conn:
            conn.execute("""
                CREATE TABLE IF NOT EXISTS payments (
                    payment_id TEXT PRIMARY KEY,
                    seller_id TEXT NOT NULL,
                    customer_id TEXT NOT NULL,
                    debt_id TEXT NOT NULL,
                    amount INTEGER NOT NULL CHECK(amount > 0),
                    provider TEXT NOT NULL
                        CHECK(provider IN ('PAYME', 'CLICK', 'UZUM')),
                    provider_payment_id TEXT,
                    merchant_transaction_id TEXT NOT NULL UNIQUE,
                    idempotency_key TEXT NOT NULL UNIQUE,
                    status TEXT NOT NULL DEFAULT 'PENDING'
                        CHECK(status IN (
                            'PENDING', 'PAID', 'FAILED', 'CANCELLED'
                        )),
                    checkout_url TEXT,
                    created_at TEXT NOT NULL,
                    confirmed_at TEXT,
                    UNIQUE(provider, provider_payment_id)
                )
            """)

            conn.execute("""
                CREATE INDEX IF NOT EXISTS idx_payments_debt
                ON payments(debt_id)
            """)

            conn.execute("""
                CREATE INDEX IF NOT EXISTS idx_payments_status
                ON payments(status)
            """)

            conn.commit()

        return True

    def get_payment(self, payment_id):
        with sqlite3.connect(self.db_path) as conn:
            conn.row_factory = sqlite3.Row
            row = conn.execute(
                "SELECT * FROM payments WHERE payment_id = ?",
                (str(payment_id),)
            ).fetchone()

            return dict(row) if row else None

    def confirm_payment(
        self,
        payment_id,
        provider,
        provider_payment_id
    ):
        provider = str(provider).upper()
        provider_payment_id = str(provider_payment_id).strip()

        if provider not in {"PAYME", "CLICK", "UZUM"}:
            raise ValueError("Noto‘g‘ri provayder.")

        if not provider_payment_id:
            raise ValueError("Provayder tranzaksiya ID si bo‘sh.")

        confirmed_at = datetime.now(timezone.utc).isoformat()

        with sqlite3.connect(self.db_path, timeout=15) as conn:
            conn.execute("BEGIN IMMEDIATE")

            payment = conn.execute(
                """
                SELECT provider, status
                FROM payments
                WHERE payment_id = ?
                """,
                (str(payment_id),)
            ).fetchone()

            if not payment:
                conn.rollback()
                return False

            if payment[0] != provider:
                conn.rollback()
                raise ValueError("Provayder mos kelmadi.")

            if payment[1] != "PENDING":
                conn.rollback()
                return False

            cursor = conn.execute(
                """
                UPDATE payments
                SET status = 'PAID',
                    provider_payment_id = ?,
                    confirmed_at = ?
                WHERE payment_id = ?
                  AND provider = ?
                  AND status = 'PENDING'
                """,
                (
                    provider_payment_id,
                    confirmed_at,
                    str(payment_id),
                    provider
                )
            )

            if cursor.rowcount != 1:
                conn.rollback()
                return False

            conn.commit()
            return True

from uuid import uuid4
from datetime import datetime, date
from app.utils.money import parse_amount

class DebtService:
    def __init__(self, sheets): self.db=sheets

    
    async def add_debt(self, seller_id, customer, amount, note="", due_date=""):
        seller_id = str(seller_id)
        customer_id = str(customer.get("customer_id", ""))

        # Mijoz ushbu sotuvchiga tegishli ekanini tekshirish
        customers = await self.db.find(
            "Customers",
            seller_id=seller_id,
            customer_id=customer_id
        )

        if not customers:
            raise ValueError("Mijoz topilmadi yoki sizga tegishli emas.")

        customer = customers[0]

        amount = parse_amount(amount)
        if amount <= 0:
            raise ValueError("Qarz summasi noldan katta bo‘lishi kerak.")

        row = {
            "debt_id": str(uuid4()),
            "seller_id": seller_id,
            "customer_id": customer_id,
            "customer_name": customer["name"],
            "amount": amount,
            "paid": 0,
            "note": note,
            "created_at": datetime.now().isoformat(timespec="seconds"),
            "due_date": due_date,
            "status": "OPEN"
        }

        await self.db.append("Debts", row)
        return row

    
    async def add_payment(self, seller_id, debt, amount, note=""):
        seller_id = str(seller_id)
        debt_id = str(debt.get("debt_id", ""))

        # Qarz aynan shu sotuvchiga tegishli ekanini tekshirish
        rows = await self.db.find(
            "Debts",
            seller_id=seller_id,
            debt_id=debt_id
        )

        if not rows:
            raise ValueError("Qarz topilmadi yoki sizga tegishli emas.")

        # Eski ma'lumotga emas, bazadagi yangi ma'lumotga tayanish
        debt = rows[0]

        amount = parse_amount(amount)
        remaining = int(float(debt["amount"])) - int(float(debt.get("paid") or 0))

        if amount <= 0 or amount > remaining:
            raise ValueError(
                f"To‘lov 1 dan {remaining:,} UZS gacha bo‘lishi kerak."
            )

        row = {
            "payment_id": str(uuid4()),
            "seller_id": seller_id,
            "debt_id": debt_id,
            "customer_id": debt["customer_id"],
            "amount": amount,
            "note": note,
            "created_at": datetime.now().isoformat(timespec="seconds")
        }

        await self.db.append("Payments", row)

        paid = int(float(debt.get("paid") or 0)) + amount

        await self.db.update(
            "Debts",
            "debt_id",
            debt_id,
            {
                "paid": paid,
                "status": "PAID" if paid >= int(float(debt["amount"])) else "OPEN"
            }
        )

        return row

    async def debts(self, seller_id, customer_id=None):
        rows=await self.db.find("Debts",seller_id=seller_id)
        if customer_id: rows=[r for r in rows if str(r["customer_id"])==str(customer_id)]
        return rows

    async def balance(self, seller_id, customer_id):
        rows=await self.debts(seller_id,customer_id)
        return sum(int(float(r["amount"]))-int(float(r.get("paid") or 0)) for r in rows)

    
    async def undo_last_payment(self, seller_id, payment_id):
        seller_id = str(seller_id)
        payment_id = str(payment_id)

        # To‘lov aynan shu sotuvchiga tegishli ekanini tekshirish
        payments = await self.db.find(
            "Payments",
            seller_id=seller_id,
            payment_id=payment_id
        )

        if not payments:
            return False

        # Oldin bekor qilinganmi?
        operations = await self.db.find(
            "Operations",
            seller_id=seller_id,
            kind="PAYMENT_REVERSED",
            payload_json=payment_id
        )

        if operations:
            return False

        payment = payments[0]

        debts = await self.db.find(
            "Debts",
            seller_id=seller_id,
            debt_id=payment["debt_id"]
        )

        if not debts:
            return False

        debt = debts[0]
        paid = int(float(debt.get("paid") or 0))
        amount = int(float(payment["amount"]))

        if amount > paid:
            return False

        new_paid = paid - amount

        await self.db.update(
            "Debts",
            "debt_id",
            debt["debt_id"],
            {
                "paid": new_paid,
                "status": "PAID" if new_paid >= int(float(debt["amount"])) else "OPEN"
            }
        )

        await self.db.append(
            "Operations",
            {
                "operation_id": str(uuid4()),
                "seller_id": seller_id,
                "kind": "PAYMENT_REVERSED",
                "payload_json": payment_id,
                "created_at": datetime.now().isoformat(timespec="seconds")
            }
        )

        return True

      
from aiogram.fsm.state import State, StatesGroup


class CustomerPaymentFlow(StatesGroup):
    waiting_amount = State()
    waiting_method = State()
    waiting_receipt = State()
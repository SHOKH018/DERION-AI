
from aiogram.fsm.state import State, StatesGroup


class DebtFlow(StatesGroup):
    customer_name = State()
    customer_phone = State()
    amount = State()
    note = State()
    new_customer_name = State()
    payment_customer = State()
    payment_debt = State()
    payment_amount = State()
    voice_confirm = State()

    # PROFIL
    profile_shop_name = State()
    profile_seller_name = State()
    profile_phone = State()

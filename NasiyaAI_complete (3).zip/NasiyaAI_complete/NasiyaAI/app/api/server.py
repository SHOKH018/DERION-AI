﻿from fastapi import FastAPI, HTTPException
from app.services.payment_store import PaymentStore

app = FastAPI(
    title="NasiyaAI Payment API",
    version="1.0.0"
)

payment_store = PaymentStore()
payment_store.initialize()


@app.get("/")
async def home():
    return {
        "app": "NasiyaAI",
        "status": "running"
    }


@app.get("/health")
async def health():
    return {
        "status": "healthy"
    }


@app.get("/payments/{payment_id}")
async def get_payment(payment_id: str):
    payment = payment_store.get_payment(payment_id)

    if not payment:
        raise HTTPException(
            status_code=404,
            detail="To‘lov topilmadi"
        )

    return {
        "payment_id": payment["payment_id"],
        "amount": payment["amount"],
        "provider": payment["provider"],
        "status": payment["status"],
        "created_at": payment["created_at"],
        "confirmed_at": payment["confirmed_at"]
    }

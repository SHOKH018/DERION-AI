import pytest
from app.services.debt_service import DebtService
class FakeDB:
    def __init__(self): self.rows={"Debts":[],"Payments":[],"Operations":[]}
    async def append(self,t,r): self.rows[t].append(r)
    async def update(self,t,k,v,u):
        for r in self.rows[t]:
            if str(r[k])==str(v): r.update(u); return True
        return False
    async def find(self,t,**f): return [r for r in self.rows[t] if all(str(r.get(k))==str(v) for k,v in f.items())]
@pytest.mark.asyncio
async def test_add_debt():
    db=FakeDB(); svc=DebtService(db)
    row=await svc.add_debt("1",{"customer_id":"c","name":"Ali"},50000)
    assert row["amount"]==50000

from app.utils.matching import best_match
def test_match():
    c,score=best_match("Al", [{"name":"Ali","customer_id":"1"}],threshold=50)
    assert c["customer_id"]=="1"

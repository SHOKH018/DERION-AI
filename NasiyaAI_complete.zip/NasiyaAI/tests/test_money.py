from app.utils.money import parse_amount,format_money
def test_parse_plain(): assert parse_amount("50000")==50000
def test_parse_ming(): assert parse_amount("50 ming")==50000
def test_format(): assert format_money(150000)=="150 000 UZS"

def test_receipt_payload_is_json_serializable():
    import json
    json.dumps({"items":[{"name":"Non","qty":"1","price":10000}],"total":10000})

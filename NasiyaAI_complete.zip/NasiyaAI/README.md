# NasiyaAI — Telegram AI qarz daftari

Python 3.11+, aiogram 3, Claude API, Google Sheets va lokal ishga tushirish uchun.

## 1. Talablar
- Python 3.11 yoki 3.12
- Telegram bot tokeni (@BotFather)
- Claude API key (chek rasmini va tabiiy til buyruqlarini tahlil qilish uchun)
- Google Cloud service account JSON va Google Sheets ID

## 2. Google Sheets sozlash
1. Google Cloud Console'da project oching.
2. Google Sheets API va Google Drive API'ni yoqing.
3. Service Account yarating va JSON kalitini yuklab oling.
4. JSON faylni loyiha ildiziga `service_account.json` nomi bilan qo'ying.
5. Spreadsheet yarating va service account email manziliga Editor huquqini bering.
6. Spreadsheet URL ichidagi `/d/` va `/edit` orasidagi qiymatni `GOOGLE_SHEETS_ID` ga yozing.
   Bot birinchi ishga tushganda kerakli varaqlar va ustunlarni o'zi yaratadi.

## 3. O'rnatish
```bash
python -m venv .venv
# Windows:
.venv\\Scripts\\activate
# macOS/Linux:
source .venv/bin/activate
pip install -r requirements.txt
```

## 4. Konfiguratsiya
```bash
copy .env.example .env
```
Windows PowerShell'da `Copy-Item .env.example .env` ham ishlaydi.
`.env` ichiga BOT_TOKEN, ANTHROPIC_API_KEY va GOOGLE_SHEETS_ID ni kiriting.

## 5. Ishga tushirish
```bash
python run.py
```
Telegram'da botga `/start` yuboring va do'kon nomini kiriting.

## Buyruqlar
- `/start` — sotuvchini ro'yxatdan o'tkazish
- `/demo` — demo qarz va mijoz qo'shish
- `/eslatmalar` — muddati o'tgan qarzlar

Menyu: qarz qo'shish, to'lov, qarzdorlar, mijoz qo'shish, hisobot.

## Ovozli xabar (STT)
Ovoz transkripsiyasi `faster-whisper` orqali lokal kompyuterda bajarilishi uchun STT servisi ajratilgan. Model birinchi ishlatilganda yuklanadi. Hozirgi MVP'da ovozli xabarni handlerga ulash keyingi iteratsiya vazifasi.

## Xavfsizlik
- Google service account JSON va `.env` Git'ga qo'shilmaydi.
- Har bir qarz/mijoz yozuvi seller_id bilan chegaralangan.
- Mijoz chatiga sotuvchining daftar ma'lumotlari yuborilmaydi.
- Chek tahlili tasdiqlash talab qiladi; AI natijasi avtomatik qarzga yozilmaydi.
- Google Sheets oddiy jadval bo'lgani uchun yuqori yuklamali production tizimida tranzaksion DB'ga o'tish tavsiya etiladi.

## MVP cheklovlari
- Hozircha mijozga Telegram orqali hisob ko'rish uchun alohida OTP/consent linking oqimi yo'q.
- To'lovni bekor qilish servisi mavjud, ammo foydalanuvchi interfeysi keyingi bosqichda ulanadi.
- Claude API model nomlari va hisobingizdagi mavjudlikni tekshirib boring.

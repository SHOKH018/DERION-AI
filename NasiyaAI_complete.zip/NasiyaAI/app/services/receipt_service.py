import json
from uuid import uuid4
from datetime import datetime

class ReceiptService:
    def __init__(self, sheets, ai): self.db=sheets; self.ai=ai
    async def analyze(self, seller_id, file_id, image_bytes, media_type):
        parsed=await self.ai.read_receipt(image_bytes,media_type)
        row={"receipt_id":str(uuid4()),"seller_id":str(seller_id),"customer_id":"",
             "image_file_id":file_id,"items_json":json.dumps(parsed.get("items",[]),ensure_ascii=False),
             "total":parsed.get("total",0),"status":"PENDING_CONFIRMATION",
             "created_at":datetime.now().isoformat(timespec="seconds")}
        await self.db.append("Receipts",row)
        return row,parsed
    async def confirm(self,seller_id,receipt_id,customer_id):
        rows=await self.db.find("Receipts",seller_id=seller_id,receipt_id=receipt_id)
        if not rows or rows[0]["status"]!="PENDING_CONFIRMATION": return False
        return await self.db.update("Receipts","receipt_id",receipt_id,
                                    {"customer_id":customer_id,"status":"CONFIRMED"})

class ReportService:
    def __init__(self,debt_service): self.debts=debt_service
    async def daily(self,seller_id):
        rows=await self.debts.debts(seller_id)
        total=sum(int(float(x["amount"])) for x in rows)
        paid=sum(int(float(x.get("paid") or 0)) for x in rows)
        return {"customers":len({x["customer_id"] for x in rows}),"debt_total":total,
                "paid_total":paid,"balance":total-paid,"open_debts":sum(1 for x in rows if total>paid)}

from uuid import uuid4
from datetime import datetime
from app.utils.matching import best_match

class CustomerService:
    def __init__(self, sheets): self.db = sheets

    async def create(self, seller_id, name, phone=""):
        row = {"customer_id":str(uuid4()),"seller_id":str(seller_id),"name":name.strip(),
               "phone":phone,"chat_id":"","consent":"FALSE","created_at":datetime.now().isoformat(timespec="seconds")}
        await self.db.append("Customers", row)
        return row

    async def list(self, seller_id):
        return await self.db.find("Customers", seller_id=seller_id)

    async def match(self, seller_id, name):
        return best_match(name, await self.list(seller_id))

    async def link_chat(self, customer_id, chat_id, consent):
        return await self.db.update("Customers","customer_id",customer_id,
                                    {"chat_id":str(chat_id),"consent":"TRUE" if consent else "FALSE"})

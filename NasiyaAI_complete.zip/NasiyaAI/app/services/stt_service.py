"""Optional local speech-to-text using faster-whisper; no audio is sent to a third party."""
import asyncio
from pathlib import Path

class STTService:
    def __init__(self, model_size="small"):
        self.model_size = model_size
        self._model = None

    def _transcribe(self, path):
        from faster_whisper import WhisperModel
        if self._model is None:
            self._model = WhisperModel(self.model_size, device="cpu", compute_type="int8")
        segments, _ = self._model.transcribe(str(path), language="uz", vad_filter=True)
        return " ".join(s.text.strip() for s in segments).strip()

    async def transcribe(self, path: str) -> str:
        return await asyncio.to_thread(self._transcribe, Path(path))

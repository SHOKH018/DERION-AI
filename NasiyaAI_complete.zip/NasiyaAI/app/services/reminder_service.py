from datetime import date
class ReminderService:
    def __init__(self,sheets): self.db=sheets
    async def overdue(self,seller_id):
        rows=await self.db.find("Debts",seller_id=seller_id)
        today=date.today().isoformat()
        return [r for r in rows if r.get("due_date") and str(r["due_date"])<today and
                int(float(r["amount"]))>int(float(r.get("paid") or 0))]

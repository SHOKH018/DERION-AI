import asyncio
from aiogram import Bot
from app.config import settings
from app.bot import build_dispatcher
from app.scheduler import build_scheduler

async def main():
    if not settings.bot_token: raise RuntimeError("BOT_TOKEN .env faylida ko‘rsatilmagan.")
    if not settings.google_sheets_id: raise RuntimeError("GOOGLE_SHEETS_ID .env faylida ko‘rsatilmagan.")
    bot=Bot(token=settings.bot_token)
    dp,db,reminders=build_dispatcher()
    # Validate Sheets credentials/connectivity before polling.
    await db.all("Sellers")
    scheduler=build_scheduler(bot,db,reminders,settings.reminder_check_minutes)
    scheduler.start()
    try:
        await dp.start_polling(bot)
    finally:
        scheduler.shutdown(wait=False)
        await bot.session.close()

if __name__=="__main__":
    asyncio.run(main())

from apscheduler.schedulers.asyncio import AsyncIOScheduler
from apscheduler.triggers.interval import IntervalTrigger
from app.utils.money import format_money

def build_scheduler(bot, db, reminder_service, minutes=30):
    scheduler=AsyncIOScheduler(timezone="Asia/Tashkent")
    async def send_overdue():
        sellers=await db.all("Sellers")
        for s in sellers:
            if str(s.get("active")).upper()!="TRUE": continue
            try:
                rows=await reminder_service.overdue(s["seller_id"])
                if rows:
                    await bot.send_message(int(s["chat_id"]),"⏰ Muddati o‘tgan qarzlar: "+str(len(rows))+" ta. /eslatmalar")
            except Exception:
                continue
    scheduler.add_job(send_overdue,IntervalTrigger(minutes=minutes),id="overdue_reminders",replace_existing=True)
    return scheduler

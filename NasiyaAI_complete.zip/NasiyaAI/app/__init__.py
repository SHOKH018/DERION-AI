"""NasiyaAI Telegram bot package."""

import re
def parse_amount(value) -> int:
    if isinstance(value,(int,float)): return int(value)
    s=str(value).lower().replace("so‘m","").replace("som","").replace("uzs","").replace(" ","")
    multiplier=1
    if "mln" in s or "million" in s: multiplier=1_000_000; s=s.replace("million","").replace("mln","")
    elif "ming" in s or "тыс" in s: multiplier=1_000; s=s.replace("ming","").replace("тыс","")
    s=s.replace(",","").replace(".","")
    digits=re.sub(r"[^0-9-]","",s)
    return int(digits or 0)*multiplier
def format_money(value): return f"{int(float(value)):,}".replace(","," ")+" UZS"

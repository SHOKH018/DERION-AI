from app.utils.money import format_money
def debt_line(row):
    balance=int(float(row["amount"]))-int(float(row.get("paid") or 0))
    return f"• {row['customer_name']}: {format_money(balance)}"

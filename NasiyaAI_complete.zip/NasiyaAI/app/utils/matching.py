from rapidfuzz import process, fuzz
def best_match(name, customers, threshold=72):
    if not customers: return None, 0
    names=[str(c.get("name","")) for c in customers]
    found=process.extractOne(name,names,scorer=fuzz.WRatio)
    if not found or found[1] < threshold: return None, found[1] if found else 0
    return customers[found[2]], found[1]

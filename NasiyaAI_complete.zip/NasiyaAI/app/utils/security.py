def owns_seller(row, seller_id):
    return bool(row) and str(row.get("seller_id")) == str(seller_id)
def safe_text(value, limit=500):
    return str(value or "").strip()[:limit]

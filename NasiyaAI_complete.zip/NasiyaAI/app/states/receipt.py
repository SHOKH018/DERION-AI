from aiogram.fsm.state import State, StatesGroup
class ReceiptFlow(StatesGroup):
    waiting_customer=State()

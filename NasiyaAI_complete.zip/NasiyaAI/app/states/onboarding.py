from aiogram.fsm.state import State, StatesGroup
class Onboarding(StatesGroup):
    shop_name=State()

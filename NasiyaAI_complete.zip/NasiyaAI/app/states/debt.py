from aiogram.fsm.state import State, StatesGroup
class DebtFlow(StatesGroup):
    customer_name=State()
    amount=State()
    note=State()
    payment_customer=State()
    payment_amount=State()

from aiogram.types import InlineKeyboardMarkup, InlineKeyboardButton
def receipt_confirm(receipt_id):
    return InlineKeyboardMarkup(inline_keyboard=[[
        InlineKeyboardButton(text="✅ Tasdiqlash",callback_data=f"receipt_ok:{receipt_id}"),
        InlineKeyboardButton(text="❌ Bekor qilish",callback_data=f"receipt_no:{receipt_id}")
    ]])

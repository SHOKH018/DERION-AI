from aiogram.types import ReplyKeyboardMarkup, KeyboardButton
def seller_menu():
    return ReplyKeyboardMarkup(keyboard=[
        [KeyboardButton(text="➕ Qarz qo‘shish"),KeyboardButton(text="💵 To‘lov")],
        [KeyboardButton(text="📒 Qarzdorlar"),KeyboardButton(text="👤 Mijoz qo‘shish")],
        [KeyboardButton(text="📊 Hisobot"),KeyboardButton(text="❓ Yordam")]
    ],resize_keyboard=True)

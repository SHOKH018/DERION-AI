from aiogram.types import InlineKeyboardMarkup, InlineKeyboardButton
def customer_choices(customers):
    return InlineKeyboardMarkup(inline_keyboard=[[InlineKeyboardButton(
        text=c["name"],callback_data=f"customer:{c['customer_id']}")] for c in customers[:20]])

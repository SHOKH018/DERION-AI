from aiogram import Router,F
from aiogram.types import Message,CallbackQuery
from app.keyboards.receipts import receipt_confirm
router=Router()
@router.message(F.photo)
async def receipt_photo(m:Message,bot,receipts):
    seller_id=str(m.from_user.id)
    file=await bot.get_file(m.photo[-1].file_id)
    data=await bot.download_file(file.file_path)
    raw=data.read()
    row,parsed=await receipts.analyze(seller_id,m.photo[-1].file_id,raw,"image/jpeg")
    if parsed.get("error"): await m.answer(parsed["error"]); return
    items=parsed.get("items",[])
    detail="\n".join(f"• {x.get('name','?')}: {x.get('qty','')} × {x.get('price',0)}" for x in items)
    await m.answer(f"🧾 Chek tahlili\n{detail}\nJami: {parsed.get('total',0)} UZS\n\nNatijani tasdiqlash uchun avval mijozni tanlash keyingi bosqichda qo‘shiladi.",reply_markup=receipt_confirm(row["receipt_id"]))
@router.callback_query(F.data.startswith("receipt_no:"))
async def cancel_receipt(c:CallbackQuery,db):
    rid=c.data.split(":",1)[1]
    await db.update("Receipts","receipt_id",rid,{"status":"CANCELLED"})
    await c.message.edit_text("Chek bekor qilindi."); await c.answer()
@router.callback_query(F.data.startswith("receipt_ok:"))
async def confirm_receipt(c:CallbackQuery,db):
    rid=c.data.split(":",1)[1]
    rows=await db.find("Receipts",seller_id=str(c.from_user.id),receipt_id=rid)
    if not rows or rows[0]["status"]!="PENDING_CONFIRMATION":
        await c.answer("Chek topilmadi yoki oldin ko‘rib chiqilgan.",show_alert=True); return
    await db.update("Receipts","receipt_id",rid,{"status":"REVIEWED"})
    await c.message.edit_text("Chek tahlili ko‘rib chiqildi. Qarzga yozishdan oldin mijoz va summani alohida tasdiqlang.")
    await c.answer()

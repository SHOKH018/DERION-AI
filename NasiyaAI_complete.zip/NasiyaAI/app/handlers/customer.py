from aiogram import Router
from aiogram.types import Message
router=Router()
@router.message()
async def customer_private_message(m:Message):
    # Customer chat access is opt-in only; never expose seller ledger data here.
    await m.answer("Bu NasiyaAI sotuvchi botidir. Qarz ma’lumotlari faqat sotuvchining shaxsiy kabinetida ko‘rsatiladi.")

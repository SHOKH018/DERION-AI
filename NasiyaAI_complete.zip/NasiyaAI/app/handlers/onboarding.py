from datetime import datetime
from aiogram import Router
from aiogram.filters import CommandStart
from aiogram.types import Message
from app.states.onboarding import Onboarding
from app.keyboards.seller import seller_menu
router=Router()
@router.message(CommandStart())
async def start(m:Message, state, db):
    seller=await db.get_seller(m.from_user.id)
    if seller:
        await m.answer(f"Assalomu alaykum, {seller['name']}! NasiyaAI tayyor.",reply_markup=seller_menu())
    else:
        await state.set_state(Onboarding.shop_name)
        await m.answer("NasiyaAI'ga xush kelibsiz! Do‘koningiz nomini yuboring:")
@router.message(Onboarding.shop_name)
async def save_shop(m:Message,state,db):
    row={"seller_id":str(m.from_user.id),"chat_id":str(m.from_user.id),"name":m.from_user.full_name,
         "shop_name":m.text[:100],"created_at":datetime.now().isoformat(timespec="seconds"),"active":"TRUE"}
    await db.append("Sellers",row)
    await state.clear()
    await m.answer("Ro‘yxatdan o‘tish yakunlandi. Menyudan foydalaning.",reply_markup=seller_menu())

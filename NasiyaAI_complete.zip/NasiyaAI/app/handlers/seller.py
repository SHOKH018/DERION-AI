from aiogram import Router,F
from aiogram.types import Message
from app.states.debt import DebtFlow
from app.keyboards.seller import seller_menu
from app.utils.money import format_money
from app.utils.matching import best_match
router=Router()
@router.message(F.text=="➕ Qarz qo‘shish")
async def ask_debt(m,state): await state.set_state(DebtFlow.customer_name); await m.answer("Mijoz ismini kiriting:")
@router.message(DebtFlow.customer_name)
async def debt_name(m,state,customers):
    c,score=await customers.match(str(m.from_user.id),m.text.strip())
    if c:
        await state.update_data(customer_id=c["customer_id"],customer_name=c["name"])
        await state.set_state(DebtFlow.amount); await m.answer(f"{c['name']} topildi ({score}%). Qarz summasini kiriting:")
    else:
        c=await customers.create(str(m.from_user.id),m.text.strip())
        await state.update_data(customer_id=c["customer_id"],customer_name=c["name"])
        await state.set_state(DebtFlow.amount); await m.answer("Yangi mijoz yaratildi. Qarz summasini kiriting:")
@router.message(DebtFlow.amount)
async def debt_amount(m,state,debts):
    from app.utils.money import parse_amount
    try:
        amount=parse_amount(m.text)
        if amount<=0: raise ValueError()
        data=await state.get_data()
        c={"customer_id":data["customer_id"],"name":data["customer_name"]}
        row=await debts.add_debt(str(m.from_user.id),c,amount)
        await state.clear(); await m.answer(f"✅ {c['name']} uchun {format_money(amount)} qarz yozildi.",reply_markup=seller_menu())
    except ValueError: await m.answer("Summani to‘g‘ri kiriting. Masalan: 50000 yoki 50 ming.")
@router.message(F.text=="💵 To‘lov")
async def ask_payment(m,state): await state.set_state(DebtFlow.payment_customer); await m.answer("Mijoz ismini kiriting:")
@router.message(DebtFlow.payment_customer)
async def payment_name(m,state,customers):
    c,score=await customers.match(str(m.from_user.id),m.text.strip())
    if not c: await m.answer("Mijoz topilmadi. Avval mijoz qo‘shing."); await state.clear(); return
    rows=await customers.db.find("Debts",seller_id=str(m.from_user.id),customer_id=c["customer_id"])
    open_rows=[r for r in rows if int(float(r["amount"]))>int(float(r.get("paid") or 0))]
    if not open_rows: await m.answer("Bu mijozda ochiq qarz yo‘q."); await state.clear(); return
    await state.update_data(debt_id=open_rows[-1]["debt_id"],customer_name=c["name"])
    await state.set_state(DebtFlow.payment_amount); await m.answer(f"{c['name']} uchun to‘lov summasini kiriting:")
@router.message(DebtFlow.payment_amount)
async def payment_amount(m,state,debts):
    from app.utils.money import parse_amount
    try:
        data=await state.get_data()
        rows=await debts.db.find("Debts",seller_id=str(m.from_user.id),debt_id=data["debt_id"])
        await debts.add_payment(str(m.from_user.id),rows[0],parse_amount(m.text))
        await state.clear(); await m.answer("✅ To‘lov saqlandi.",reply_markup=seller_menu())
    except Exception as e: await m.answer(f"To‘lov amalga oshmadi: {e}")
@router.message(F.text=="📒 Qarzdorlar")
async def list_debts(m,debts):
    rows=await debts.debts(str(m.from_user.id))
    if not rows: await m.answer("Hozircha qarzlar yo‘q."); return
    lines=[]
    for r in rows:
        bal=int(float(r["amount"]))-int(float(r.get("paid") or 0))
        if bal>0: lines.append(f"• {r['customer_name']}: {format_money(bal)}")
    await m.answer("📒 Ochiq qarzlar:\n"+"\n".join(lines) if lines else "Barcha qarzlar yopilgan.")
@router.message(F.text=="📊 Hisobot")
async def report(m,reports):
    r=await reports.daily(str(m.from_user.id))
    await m.answer(f"📊 Hisobot\nJami qarz: {format_money(r['debt_total'])}\nTo‘langan: {format_money(r['paid_total'])}\nQoldiq: {format_money(r['balance'])}\nMijozlar: {r['customers']}")
@router.message(F.text=="👤 Mijoz qo‘shish")
async def add_customer(m,state): await state.set_state(DebtFlow.customer_name); await m.answer("Yangi mijoz ismini yuboring. Keyin qarz summasi so‘raladi.")
@router.message(F.text=="❓ Yordam")
async def help_msg(m): await m.answer("Qarz qo‘shish, to‘lov, qarzdorlar va hisobot tugmalaridan foydalaning. Matn yoki ovozli xabar orqali ham buyruq yuborishingiz mumkin.")

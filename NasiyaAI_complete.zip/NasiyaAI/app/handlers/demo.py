from aiogram import Router
from aiogram.filters import Command
from aiogram.types import Message
from datetime import datetime
from uuid import uuid4
router=Router()
@router.message(Command("demo"))
async def demo(m,db):
    sid=str(m.from_user.id)
    if not await db.get_seller(m.from_user.id):
        await m.answer("Avval /start orqali do‘konni ro‘yxatdan o‘tkazing."); return
    cid=str(uuid4())
    await db.append("Customers",{"customer_id":cid,"seller_id":sid,"name":"Demo Ali","phone":"","chat_id":"","consent":"FALSE","created_at":datetime.now().isoformat()})
    await db.append("Debts",{"debt_id":str(uuid4()),"seller_id":sid,"customer_id":cid,"customer_name":"Demo Ali","amount":150000,"paid":50000,"note":"Demo","created_at":datetime.now().isoformat(),"due_date":"","status":"OPEN"})
    await m.answer("Demo ma’lumotlari qo‘shildi.")

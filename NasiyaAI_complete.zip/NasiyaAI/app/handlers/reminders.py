from aiogram import Router
from aiogram.filters import Command
from aiogram.types import Message
from app.utils.money import format_money
router=Router()
@router.message(Command("eslatmalar"))
async def reminders(m,reminder_service):
    rows=await reminder_service.overdue(str(m.from_user.id))
    if not rows: await m.answer("Muddati o‘tgan qarzlar yo‘q."); return
    await m.answer("⏰ Muddati o‘tgan qarzlar:\n"+"\n".join(f"• {r['customer_name']}: {format_money(int(float(r['amount']))-int(float(r.get('paid') or 0)))}" for r in rows))

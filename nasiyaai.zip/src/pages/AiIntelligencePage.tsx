import React, { useMemo, useState } from 'react';
import {
  Activity,
  AlertTriangle,
  Bot,
  CheckCircle2,
  Send,
  ShieldAlert,
  TrendingUp,
} from 'lucide-react';
import { useApp } from '../context/AppContext.tsx';
import { formatUZS, resolveDebtStatus } from '../lib/accounting.ts';
import { apiClient } from '../services/apiClient.ts';
import type { AIChatMessage, AIActionSuggestion, AIForecastItem } from '../types/domain.ts';
import { Button, Card, ConfirmDialog, Input, StatusText } from '../components/ui/Primitives.tsx';

const PRESET_QUESTIONS = [
  'Bu oy qancha foyda qildim?',
  'Qaysi mijozlar eng ko‘p qarzdor?',
  'Qancha qarzni undirishim kerak?',
  'Qaysi mahsulotlar yaxshi sotilyapti?',
];

export function AiIntelligencePage() {
  const {
    mode,
    dataset,
    summary,
    healthAssessment,
    approveAiAction,
    can,
    setActivePage,
  } = useApp();

  const [messages, setMessages] = useState<AIChatMessage[]>([
    {
      id: 'ai-welcome',
      role: 'assistant',
      text: 'Assalomu alaykum! Men NasiyaAI biznes tahlilchisiman. Savdo, sof foyda, qarzdorlar va ombor qoldiqlari bo‘yicha o‘zbek tilida savol bering.',
      createdAt: new Date().toISOString(),
      dateRangeUsed: 'Joriy davr',
      basis: 'Deterministik moliyaviy registrlar',
      isEstimate: false,
    },
  ]);
  const [question, setQuestion] = useState('');
  const [chatLoading, setChatLoading] = useState(false);
  const [chatError, setChatError] = useState<string | null>(null);
  const [confirmAction, setConfirmAction] = useState<AIActionSuggestion | null>(null);
  const [approving, setApproving] = useState(false);

  const lowStockProducts = useMemo(
    () => dataset.products.filter((p) => p.quantity <= p.minStockLevel),
    [dataset.products]
  );

  const overdueDebts = useMemo(
    () =>
      dataset.debts.filter(
        (d) =>
          d.remainingAmount > 0 &&
          resolveDebtStatus(d.remainingAmount, d.paidAmount, d.dueDate) === 'Muddati o‘tgan'
      ),
    [dataset.debts]
  );

  const anomalies = useMemo(() => {
    const list: Array<{
      id: string;
      severity: 'warning' | 'critical' | 'info';
      title: string;
      detail: string;
    }> = [];
    if (overdueDebts.length > 0) {
      list.push({
        id: 'anom-overdue',
        severity: 'critical',
        title: `Muddati o‘tgan qarzlar ko‘paygan (${overdueDebts.length} ta)`,
        detail: `Jami ${formatUZS(
          summary.overdueDebt
        )} mablag‘ belgilangan muddatdan kechikmoqda. Eslatma yuborish va to‘lov jadvalini aniqlashtirish tavsiya etiladi.`,
      });
    }
    if (lowStockProducts.length > 0) {
      list.push({
        id: 'anom-stock',
        severity: 'warning',
        title: `Ombor qoldig‘i minimal me’yordan past (${lowStockProducts.length} ta tovar)`,
        detail: `${lowStockProducts.map((p) => p.name).join(', ')} mahsulotlari tugash arafasida.`,
      });
    }
    const maxExpense = dataset.transactions
      .filter((t) => t.type === 'Xarajat')
      .sort((a, b) => b.amount - a.amount)[0];
    if (maxExpense && maxExpense.amount > 2_000_000) {
      list.push({
        id: 'anom-expense',
        severity: 'info',
        title: `Yirik xarajat qayd etilgan: ${maxExpense.category}`,
        detail: `${maxExpense.description} — ${formatUZS(
          maxExpense.amount
        )}. Hujjatlar va cheklarni tekshirib qo‘yish tavsiya etiladi (avtomatik ayblov qo‘yilmaydi).`,
      });
    }
    return list;
  }, [overdueDebts, lowStockProducts, dataset.transactions, summary.overdueDebt]);

  const forecasts: AIForecastItem[] = useMemo(() => {
    const baseSales = summary.totalSalesRevenue || 0;
    const baseExp = summary.operatingExpenses || 0;
    const baseDebt = summary.outstandingDebt || 0;
    return [
      {
        id: 'fc-1',
        metricLabel: 'Kutilayotgan 30 kunlik savdo',
        horizon: 'Kelgusi 30 kun',
        projectedValueUzs: Math.round(baseSales * 1.08),
        confidenceLabel: dataset.sales.length >= 4 ? 'O‘rta' : 'Past',
        historicalPeriodUsed: 'Oxirgi 30 kunlik savdo tarixi',
        assumptions:
          'Taxminiy prognoz (kafolatlanmagan): joriy talab va mavsumiy 8% o‘sish sur’ati saqlanishi faraz qilingan.',
      },
      {
        id: 'fc-2',
        metricLabel: 'Kutilayotgan qarz undiruvi',
        horizon: 'Kelgusi 30 kun',
        projectedValueUzs: Math.round(baseDebt * 0.6),
        confidenceLabel: 'O‘rta',
        historicalPeriodUsed: 'Aktiv qarz shartnomalari muddati',
        assumptions:
          'Taxminiy prognoz: aktiv qarz portfelining 60% qismi muddatida qaytarilishi faraz qilingan.',
      },
      {
        id: 'fc-3',
        metricLabel: 'Kutilayotgan xarajatlar',
        horizon: 'Kelgusi 30 kun',
        projectedValueUzs: Math.round(baseExp * 1.03),
        confidenceLabel: 'Yuqori',
        historicalPeriodUsed: 'Doimiy ijara va operatsion xarajatlar',
        assumptions:
          'Taxminiy prognoz: doimiy xarajatlar 3% inflyatsiya tuzatishi bilan hisoblandi.',
      },
      {
        id: 'fc-4',
        metricLabel: 'Sof pul oqimi prognozi',
        horizon: 'Kelgusi 30 kun',
        projectedValueUzs: Math.round(baseSales * 0.65 + baseDebt * 0.6 - baseExp * 1.03),
        confidenceLabel: 'O‘rta',
        historicalPeriodUsed: 'Tushum va xarajat nisbati',
        assumptions:
          'Taxminiy prognoz: savdolarning 65% naqd/karta tushumi va 60% qarz undiruvi asosida.',
      },
    ];
  }, [summary, dataset.sales.length]);

  const buildDeterministicDemoReply = (q: string): AIChatMessage => {
    const lower = q.toLowerCase();
    const topDebtors = dataset.debts
      .filter((d) => d.remainingAmount > 0)
      .sort((a, b) => b.remainingAmount - a.remainingAmount)
      .slice(0, 3);

    const productSalesMap = new Map<string, number>();
    for (const s of dataset.sales) {
      for (const item of s.items) {
        productSalesMap.set(
          item.productName,
          (productSalesMap.get(item.productName) || 0) + item.lineTotal
        );
      }
    }
    const topProducts = Array.from(productSalesMap.entries())
      .sort((a, b) => b[1] - a[1])
      .slice(0, 3);

    let text = `Joriy davr bo‘yicha jami savdo ${formatUZS(
      summary.totalSalesRevenue
    )}, tannarx va xarajatlar chegirilgan sof foyda ${formatUZS(
      summary.netProfit
    )}, qolgan umumiy qarz esa ${formatUZS(summary.outstandingDebt)} ni tashkil etadi.`;
    let isEstimate = false;
    const recommendations: string[] = [];

    if (lower.includes('foyda')) {
      text = `Tanlangan davrda sof foyda ${formatUZS(
        summary.netProfit
      )} ni tashkil etdi. Bu ko‘rsatkich ${formatUZS(
        summary.totalSalesRevenue
      )} savdo daromadidan ${formatUZS(summary.totalCOGS)} mahsulot tannarxi va ${formatUZS(
        summary.operatingExpenses
      )} operatsion xarajatlar ayirilgan holda hisoblandi.`;
      recommendations.push('Nasiya savdo ulushini kuzatib, yuqori marjali mahsulotlarni ko‘paytiring.');
    } else if (lower.includes('qarzdor') || lower.includes('undir')) {
      text =
        topDebtors.length > 0
          ? `Eng ko‘p qarzdorlar: ${topDebtors
              .map((d) => `${d.customerName} (${formatUZS(d.remainingAmount)})`)
              .join(', ')}. Jami undirilishi kerak bo‘lgan qarz: ${formatUZS(
              summary.outstandingDebt
            )}, shundan ${formatUZS(summary.overdueDebt)} muddati o‘tgan.`
          : 'Hozirda aktiv qarzdorlik mavjud emas.';
      recommendations.push('Muddati o‘tgan qarzdorlarga tasdiq orqali Telegram eslatmasi yuboring.');
    } else if (lower.includes('mahsulot') || lower.includes('sotilyapti')) {
      text =
        topProducts.length > 0
          ? `Eng ko‘p daromad keltirgan mahsulotlar: ${topProducts
              .map(([name, val]) => `${name} (${formatUZS(val)})`)
              .join(', ')}.`
          : 'Savdo yozuvlari hali kiritilmagan.';
      recommendations.push('Kam qolgan tovarlar qoldig‘ini Ombor bo‘limida tekshiring.');
    } else if (lower.includes('taqqos') || lower.includes('prognoz')) {
      isEstimate = true;
      text = `Joriy davrda savdo ${formatUZS(
        summary.totalSalesRevenue
      )} bo‘ldi. Taxminiy bahoga ko‘ra, kelgusi 30 kunda savdo ${formatUZS(
        Math.round(summary.totalSalesRevenue * 1.08)
      )} atrofida bo‘lishi kutilmoqda (o‘tgan oy to‘liq ma’lumoti bazada qisman mavjud).`;
      recommendations.push('Aniqroq taqqoslash uchun kamida 60 kunlik savdo tarixini jamlang.');
    }

    return {
      id: `ai-${Date.now()}`,
      role: 'assistant',
      text,
      createdAt: new Date().toISOString(),
      dateRangeUsed: 'Tanlangan davr (Asia/Tashkent)',
      basis:
        mode === 'demo'
          ? 'Demo rejim deterministik hisob-kitobi (namuna ma’lumotlar)'
          : 'Backend deterministik registri',
      isEstimate,
      recommendations,
      missingData:
        dataset.sales.length < 5
          ? 'To‘liq mavsumiy trend uchun kamida 30 kunlik qo‘shimcha savdo yozuvlari tavsiya etiladi.'
          : undefined,
    };
  };

  const handleSendQuestion = async (promptText?: string) => {
    const q = (promptText ?? question).trim();
    if (!q || chatLoading) return;
    setChatError(null);
    const userMsg: AIChatMessage = {
      id: `usr-${Date.now()}`,
      role: 'user',
      text: q,
      createdAt: new Date().toISOString(),
    };
    setMessages((prev) => [...prev, userMsg]);
    if (!promptText) setQuestion('');

    setChatLoading(true);
    try {
      if (mode === 'real') {
        const reply = await apiClient.sendAiChat(q, {
          summary,
          topDebtors: dataset.debts
            .filter((d) => d.remainingAmount > 0)
            .slice(0, 5)
            .map((d) => ({
              customerName: d.customerName,
              remainingAmount: d.remainingAmount,
              status: d.status,
            })),
          lowStockCount: lowStockProducts.length,
        });
        setMessages((prev) => [...prev, reply]);
      } else {
        // In Demo Mode, answer deterministically from demo dataset without faking backend AI
        await new Promise((r) => setTimeout(r, 250));
        setMessages((prev) => [...prev, buildDeterministicDemoReply(q)]);
      }
    } catch (err) {
      setChatError(
        err instanceof Error ? err.message : 'AI tahlilchi bilan bog‘lanishda xatolik.'
      );
    } finally {
      setChatLoading(false);
    }
  };

  const handleConfirmAction = async () => {
    if (!confirmAction) return;
    setApproving(true);
    try {
      await approveAiAction(confirmAction.id);
      if (confirmAction.actionType === 'send_reminder' || confirmAction.actionType === 'review_overdue') {
        setActivePage('debts');
      } else if (confirmAction.actionType === 'restock_alert') {
        setActivePage('inventory');
      }
      setConfirmAction(null);
    } finally {
      setApproving(false);
    }
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
        <div>
          <h2 className="font-display text-xl font-bold text-slate-900">
            AI Intelligence Markazi
          </h2>
          <p className="text-xs sm:text-sm text-slate-500 mt-0.5">
            Evristik biznes diagnostikasi, anomaliyalar tahlili, o‘zbek tilidagi AI chat va taxminiy
            prognozlar
          </p>
        </div>
        <StatusText tone="info" label="AI balansni mustaqil o‘zgartirmaydi" />
      </div>

      {/* A. AI Business Doctor + B. AI Daily Briefing */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
        <Card className="p-5 lg:col-span-2 space-y-4">
          <div className="flex flex-wrap items-start justify-between gap-3">
            <div>
              <div className="flex items-center gap-2 text-xs font-semibold text-[#2563EB]">
                <Activity className="w-4 h-4" />
                <span>AI Business Doctor · Evristik ko‘rsatkich</span>
              </div>
              <h3 className="font-display text-base font-bold text-slate-900 mt-1">
                {healthAssessment.label}
              </h3>
            </div>
            <div className="text-right">
              <div className="font-display text-3xl font-extrabold text-[#2563EB] tabular-nums">
                {healthAssessment.score}
                <span className="text-sm font-medium text-slate-400"> / 100</span>
              </div>
              <div className="text-[11px] text-slate-500">Evristik indikator</div>
            </div>
          </div>

          <p className="text-xs text-slate-600 bg-slate-50 border border-slate-200/80 rounded-xl p-3 leading-relaxed">
            {healthAssessment.methodology}
          </p>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 text-xs">
            <div className="space-y-2">
              <h4 className="font-bold text-emerald-800">Kuchli tomonlar</h4>
              <ul className="space-y-1.5 text-slate-700">
                {healthAssessment.strengths.map((s, i) => (
                  <li key={i} className="flex items-start gap-2">
                    <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600 mt-0.5 shrink-0" />
                    <span>{s}</span>
                  </li>
                ))}
                {healthAssessment.strengths.length === 0 && (
                  <li className="text-slate-500">Hozircha yetarli ma’lumot mavjud emas.</li>
                )}
              </ul>
            </div>
            <div className="space-y-2">
              <h4 className="font-bold text-amber-800">Zaif tomonlar va tavsiyalar</h4>
              <ul className="space-y-1.5 text-slate-700">
                {healthAssessment.weaknesses.map((w, i) => (
                  <li key={i} className="flex items-start gap-2">
                    <AlertTriangle className="w-3.5 h-3.5 text-amber-600 mt-0.5 shrink-0" />
                    <span>{w}</span>
                  </li>
                ))}
                {healthAssessment.recommendations.map((r, i) => (
                  <li key={`rec-${i}`} className="text-slate-600 pl-5">
                    • {r}
                  </li>
                ))}
              </ul>
            </div>
          </div>
        </Card>

        {/* B. Daily Briefing */}
        <Card className="p-5 flex flex-col justify-between space-y-4">
          <div className="space-y-3">
            <div className="flex items-center gap-2 text-xs font-semibold text-indigo-600">
              <Bot className="w-4 h-4" />
              <span>AI Kunlik Brifing</span>
            </div>
            <div className="space-y-2.5 text-xs">
              <div className="flex justify-between py-1.5 border-b border-slate-100">
                <span className="text-slate-500">Savdo hajmi</span>
                <span className="font-display font-bold text-slate-900 tabular-nums">
                  {formatUZS(summary.totalSalesRevenue)}
                </span>
              </div>
              <div className="flex justify-between py-1.5 border-b border-slate-100">
                <span className="text-slate-500">Sof foyda</span>
                <span className="font-display font-bold text-emerald-700 tabular-nums">
                  {formatUZS(summary.netProfit)}
                </span>
              </div>
              <div className="flex justify-between py-1.5 border-b border-slate-100">
                <span className="text-slate-500">Qarz undiruvi</span>
                <span className="font-display font-bold text-slate-900 tabular-nums">
                  {formatUZS(summary.debtCollections)}
                </span>
              </div>
              <div className="flex justify-between py-1.5 border-b border-slate-100">
                <span className="text-slate-500">Muddati o‘tgan qarz</span>
                <span className="font-display font-bold text-red-600 tabular-nums">
                  {formatUZS(summary.overdueDebt)}
                </span>
              </div>
            </div>
          </div>
          <p className="text-xs text-slate-600 leading-relaxed">
            Tavsiya: bugungi kun yakunida kassa qoldig‘i va muddati o‘tgan nasiyalarni solishtiring.
          </p>
        </Card>
      </div>

      {/* D. AI Natural Language Analytics Chat + C. Anomaly Detection */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
        <Card className="p-5 lg:col-span-2 flex flex-col h-[520px]">
          <div className="flex items-center justify-between gap-2 pb-3 border-b border-slate-100">
            <div>
              <h3 className="text-sm font-bold text-slate-900">
                O‘zbek tilida AI moliyaviy tahlilchi
              </h3>
              <p className="text-xs text-slate-500">
                {mode === 'real'
                  ? 'Backend server orqali Gemini AI bilan ishlaydi'
                  : 'Demo rejimda namuna ma’lumotlar asosida javob beradi'}
              </p>
            </div>
          </div>

          <div className="flex flex-wrap gap-1.5 py-2.5 border-b border-slate-100">
            {PRESET_QUESTIONS.map((pq) => (
              <button
                key={pq}
                type="button"
                onClick={() => void handleSendQuestion(pq)}
                className="px-2.5 py-1 text-xs rounded-lg border border-slate-200 bg-slate-50 hover:bg-blue-50 hover:border-blue-200 text-slate-700 transition-colors cursor-pointer"
              >
                {pq}
              </button>
            ))}
          </div>

          <div className="flex-1 overflow-y-auto py-3 space-y-3 pr-1">
            {messages.map((m) => (
              <div
                key={m.id}
                className={`flex ${m.role === 'user' ? 'justify-end' : 'justify-start'}`}
              >
                <div
                  className={`max-w-[88%] rounded-xl px-4 py-3 text-xs space-y-2 ${
                    m.role === 'user'
                      ? 'bg-[#2563EB] text-white'
                      : 'bg-slate-50 border border-slate-200 text-slate-800'
                  }`}
                >
                  <p className="leading-relaxed whitespace-pre-line">{m.text}</p>
                  {m.role === 'assistant' && m.basis && (
                    <div className="pt-2 border-t border-slate-200/80 text-[11px] text-slate-500 space-y-1">
                      <div>
                        Davr: {m.dateRangeUsed} · Asos: {m.basis} ·{' '}
                        {m.isEstimate ? 'Taxminiy baho' : 'Fakt ma’lumot'}
                      </div>
                      {m.recommendations && m.recommendations.length > 0 && (
                        <div className="text-slate-700">
                          Tavsiya: {m.recommendations.join(' ')}
                        </div>
                      )}
                      {m.missingData && (
                        <div className="text-amber-700">Eslatma: {m.missingData}</div>
                      )}
                    </div>
                  )}
                </div>
              </div>
            ))}
            {chatLoading && (
              <div className="text-xs text-slate-500 italic">AI ma’lumotlarni tahlil qilmoqda...</div>
            )}
            {chatError && (
              <div className="p-3 rounded-xl bg-red-50 border border-red-200 text-xs text-red-700">
                {chatError}
              </div>
            )}
          </div>

          <form
            onSubmit={(e) => {
              e.preventDefault();
              void handleSendQuestion();
            }}
            className="pt-3 border-t border-slate-100 flex items-center gap-2"
          >
            <div className="flex-1">
              <Input
                value={question}
                onChange={(e) => setQuestion(e.target.value)}
                placeholder="Savolingizni yozing... (masalan: Bu oy qancha foyda qildim?)"
                aria-label="AI tahlilchiga savol"
              />
            </div>
            <Button type="submit" variant="ai" loading={chatLoading}>
              <Send className="w-4 h-4" />
              Yuborish
            </Button>
          </form>
        </Card>

        {/* C. Anomaly Detection & F. AI Action Center */}
        <div className="space-y-4">
          <Card className="p-5 space-y-3">
            <div className="flex items-center gap-2 text-xs font-semibold text-amber-700">
              <ShieldAlert className="w-4 h-4" />
              <span>AI Anomaliyalar Nazorati</span>
            </div>
            {anomalies.length === 0 ? (
              <p className="text-xs text-slate-500">
                Hozircha g‘ayrioddiy og‘ishlar aniqlanmadi.
              </p>
            ) : (
              <div className="space-y-2.5">
                {anomalies.map((a) => (
                  <div
                    key={a.id}
                    className="p-3 rounded-xl border border-slate-200 bg-slate-50/70 space-y-1"
                  >
                    <div className="flex items-center justify-between gap-2">
                      <span className="text-xs font-bold text-slate-900">{a.title}</span>
                    </div>
                    <p className="text-[11px] text-slate-600 leading-relaxed">{a.detail}</p>
                  </div>
                ))}
              </div>
            )}
          </Card>

          <Card className="p-5 space-y-3">
            <div className="flex items-center justify-between">
              <h3 className="text-sm font-bold text-slate-900">AI Harakatlar Markazi</h3>
              <span className="text-[11px] text-slate-500">Tasdiq talab etiladi</span>
            </div>
            {dataset.aiActions.length === 0 ? (
              <p className="text-xs text-slate-500">Tavsiya etilgan harakatlar hozircha yo‘q.</p>
            ) : (
              <div className="space-y-2.5">
                {dataset.aiActions.map((act) => (
                  <div
                    key={act.id}
                    className="p-3 rounded-xl border border-slate-200 space-y-2"
                  >
                    <div className="flex items-start justify-between gap-2">
                      <span className="text-xs font-semibold text-slate-900">{act.title}</span>
                      <StatusText
                        tone={act.status === 'Tasdiqlangan' ? 'positive' : 'warning'}
                        label={act.status}
                      />
                    </div>
                    <p className="text-[11px] text-slate-600">{act.description}</p>
                    {act.status === 'Kutilmoqda' && can('approve_ai_actions') && (
                      <Button
                        size="sm"
                        variant="secondary"
                        onClick={() => setConfirmAction(act)}
                        className="w-full"
                      >
                        Ko‘rib chiqish va tasdiqlash
                      </Button>
                    )}
                  </div>
                ))}
              </div>
            )}
          </Card>
        </div>
      </div>

      {/* E. AI Forecasting */}
      <Card className="p-5 space-y-4">
        <div className="flex flex-wrap items-center justify-between gap-2">
          <div>
            <div className="flex items-center gap-2 text-xs font-semibold text-[#2563EB]">
              <TrendingUp className="w-4 h-4" />
              <span>AI Prognozlar (Taxminiy baholar)</span>
            </div>
            <p className="text-xs text-slate-500 mt-0.5">
              Barcha prognozlar tarixiy ma’lumotlarga asoslangan taxminiy hisob-kitob bo‘lib,
              kafolatlangan natija hisoblanmaydi.
            </p>
          </div>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 xl:grid-cols-4 gap-4">
          {forecasts.map((fc) => (
            <div
              key={fc.id}
              className="p-4 rounded-xl border border-slate-200 bg-slate-50/50 space-y-2"
            >
              <div className="flex items-center justify-between gap-2">
                <span className="text-xs font-semibold text-slate-600">{fc.horizon}</span>
                <StatusText
                  tone={
                    fc.confidenceLabel === 'Yuqori'
                      ? 'positive'
                      : fc.confidenceLabel === 'O‘rta'
                      ? 'info'
                      : 'warning'
                  }
                  label={`Ishonchlilik: ${fc.confidenceLabel}`}
                />
              </div>
              <div className="text-xs font-bold text-slate-900">{fc.metricLabel}</div>
              <div className="font-display text-lg font-bold text-slate-900 tabular-nums">
                {formatUZS(fc.projectedValueUzs)}
              </div>
              <p className="text-[11px] text-slate-500 leading-relaxed">{fc.assumptions}</p>
            </div>
          ))}
        </div>
      </Card>

      <ConfirmDialog
        open={Boolean(confirmAction)}
        onClose={() => setConfirmAction(null)}
        onConfirm={() => void handleConfirmAction()}
        title="AI tavsiyasini tasdiqlaysizmi?"
        description={
          confirmAction
            ? `${confirmAction.title}: ${confirmAction.description} Ushbu amal faqat sizning roziligingiz bilan bajariladi.`
            : ''
        }
        confirmLabel="Tasdiqlayman"
        loading={approving}
      />
    </div>
  );
}

import React, { useMemo, useState } from 'react';
import { AlertTriangle, Edit2, Package, Plus, Search } from 'lucide-react';
import { useApp } from '../context/AppContext.tsx';
import { formatDateUZ, formatUZS } from '../lib/accounting.ts';
import { productSchema } from '../lib/validation.ts';
import type { Product } from '../types/domain.ts';
import {
  Button,
  Card,
  EmptyState,
  FieldLabel,
  Input,
  Modal,
  Select,
  StatusText,
} from '../components/ui/Primitives.tsx';

export function InventoryPage() {
  const { dataset, summary, selectedBranchId, saveProduct, can } = useApp();

  const [tab, setTab] = useState<'products' | 'movements'>('products');
  const [search, setSearch] = useState('');
  const [stockFilter, setStockFilter] = useState<'all' | 'low'>('all');
  const [modalOpen, setModalOpen] = useState(false);
  const [editing, setEditing] = useState<Product | null>(null);

  const [name, setName] = useState('');
  const [sku, setSku] = useState('');
  const [category, setCategory] = useState('Smartfonlar');
  const [purchasePrice, setPurchasePrice] = useState('');
  const [sellingPrice, setSellingPrice] = useState('');
  const [quantity, setQuantity] = useState('');
  const [minStockLevel, setMinStockLevel] = useState('3');
  const [branchId, setBranchId] = useState(dataset.branches[0]?.id || 'br-main');
  const [formErr, setFormErr] = useState<string | null>(null);
  const [saving, setSaving] = useState(false);

  const filteredProducts = useMemo(() => {
    return dataset.products.filter((p) => {
      if (selectedBranchId !== 'all' && p.branchId !== selectedBranchId) return false;
      if (stockFilter === 'low' && p.quantity > p.minStockLevel) return false;
      if (
        search.trim() &&
        !`${p.name} ${p.sku} ${p.category}`.toLowerCase().includes(search.trim().toLowerCase())
      ) {
        return false;
      }
      return true;
    });
  }, [dataset.products, selectedBranchId, stockFilter, search]);

  const lowStockCount = useMemo(
    () =>
      dataset.products.filter(
        (p) =>
          (selectedBranchId === 'all' || p.branchId === selectedBranchId) &&
          p.quantity <= p.minStockLevel
      ).length,
    [dataset.products, selectedBranchId]
  );

  const branchName = (id: string) =>
    dataset.branches.find((b) => b.id === id)?.name || 'Asosiy filial';

  const openAdd = () => {
    setEditing(null);
    setName('');
    setSku('');
    setCategory('Smartfonlar');
    setPurchasePrice('');
    setSellingPrice('');
    setQuantity('');
    setMinStockLevel('3');
    setBranchId(dataset.branches[0]?.id || 'br-main');
    setFormErr(null);
    setModalOpen(true);
  };

  const openEdit = (p: Product) => {
    setEditing(p);
    setName(p.name);
    setSku(p.sku);
    setCategory(p.category);
    setPurchasePrice(String(p.purchasePrice));
    setSellingPrice(String(p.sellingPrice));
    setQuantity(String(p.quantity));
    setMinStockLevel(String(p.minStockLevel));
    setBranchId(p.branchId);
    setFormErr(null);
    setModalOpen(true);
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setFormErr(null);
    const parsed = productSchema.safeParse({
      name,
      sku,
      category,
      purchasePrice: Number(purchasePrice),
      sellingPrice: Number(sellingPrice),
      quantity: Number(quantity),
      minStockLevel: Number(minStockLevel),
      branchId: branchId || dataset.branches[0]?.id || 'br-main',
    });
    if (!parsed.success) {
      setFormErr(parsed.error.issues[0]?.message || 'Ma’lumotlarni tekshiring.');
      return;
    }
    setSaving(true);
    try {
      await saveProduct(parsed.data, editing?.id);
      setModalOpen(false);
    } catch (err) {
      setFormErr(err instanceof Error ? err.message : 'Saqlashda xatolik.');
    } finally {
      setSaving(false);
    }
  };

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
        <div>
          <h2 className="font-display text-xl font-bold text-slate-900">Ombor boshqaruvi</h2>
          <p className="text-xs sm:text-sm text-slate-500 mt-0.5">
            Tovar qoldiqlari, tannarx bahosi, minimal me’yor va harakat tarixi
          </p>
        </div>
        {can('manage_inventory') && (
          <Button onClick={openAdd}>
            <Plus className="w-4 h-4" />
            Mahsulot qo‘shish
          </Button>
        )}
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
        <Card className="p-4 space-y-1">
          <div className="text-xs text-slate-500">Ombor qiymati (tannarx bo‘yicha)</div>
          <div className="font-display text-xl font-bold text-slate-900 tabular-nums">
            {formatUZS(summary.inventoryValuation)}
          </div>
        </Card>
        <Card className="p-4 space-y-1">
          <div className="text-xs text-slate-500">Jami SKU turlari</div>
          <div className="font-display text-xl font-bold text-slate-900 tabular-nums">
            {filteredProducts.length} ta mahsulot
          </div>
        </Card>
        <Card className="p-4 space-y-1">
          <div className="text-xs text-slate-500">Kam qolgan tovarlar</div>
          <div className="flex items-center gap-2 mt-1">
            <span
              className={`font-display text-xl font-bold tabular-nums ${
                lowStockCount > 0 ? 'text-amber-700' : 'text-emerald-700'
              }`}
            >
              {lowStockCount} ta
            </span>
            {lowStockCount > 0 && <AlertTriangle className="w-4 h-4 text-amber-600" />}
          </div>
        </Card>
      </div>

      <Card className="p-5 space-y-4">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-3">
          <div className="flex gap-1 p-1 bg-slate-100 rounded-lg self-start">
            <button
              type="button"
              onClick={() => setTab('products')}
              className={`px-3 py-1.5 text-xs font-medium rounded-md cursor-pointer ${
                tab === 'products' ? 'bg-white text-slate-900 shadow-sm' : 'text-slate-600'
              }`}
            >
              Mahsulotlar
            </button>
            <button
              type="button"
              onClick={() => setTab('movements')}
              className={`px-3 py-1.5 text-xs font-medium rounded-md cursor-pointer ${
                tab === 'movements' ? 'bg-white text-slate-900 shadow-sm' : 'text-slate-600'
              }`}
            >
              Ombor harakatlari ({dataset.stockMovements.length})
            </button>
          </div>

          {tab === 'products' && (
            <div className="flex flex-wrap items-center gap-2 flex-1 justify-end">
              <div className="relative flex-1 max-w-xs">
                <Search className="w-4 h-4 text-slate-400 absolute left-3 top-3" />
                <Input
                  value={search}
                  onChange={(e) => setSearch(e.target.value)}
                  placeholder="Nomi yoki SKU..."
                  className="pl-9"
                />
              </div>
              <button
                type="button"
                onClick={() => setStockFilter(stockFilter === 'all' ? 'low' : 'all')}
                className={`px-3 py-2 text-xs font-medium rounded-lg border cursor-pointer ${
                  stockFilter === 'low'
                    ? 'bg-amber-50 border-amber-200 text-amber-800'
                    : 'bg-white border-slate-200 text-slate-600'
                }`}
              >
                {stockFilter === 'low' ? 'Faqat kam qolganlar' : 'Kam qolganlarni filtrlash'}
              </button>
            </div>
          )}
        </div>

        {tab === 'products' ? (
          filteredProducts.length === 0 ? (
            <EmptyState
              icon={<Package className="w-5 h-5" />}
              title="Mahsulotlar topilmadi"
              description="Omborga birinchi mahsulotni qo‘shing yoki filtrni tozalang."
              actionLabel={can('manage_inventory') ? 'Mahsulot qo‘shish' : undefined}
              onAction={can('manage_inventory') ? openAdd : undefined}
            />
          ) : (
            <>
              <div className="hidden md:block overflow-x-auto">
                <table className="w-full text-left border-collapse">
                  <thead>
                    <tr className="border-b border-slate-200 text-xs font-semibold text-slate-500">
                      <th className="py-2.5 pr-4">Mahsulot / SKU</th>
                      <th className="py-2.5 px-3">Kategoriya</th>
                      <th className="py-2.5 px-3 text-right">Xarid narxi</th>
                      <th className="py-2.5 px-3 text-right">Sotuv narxi</th>
                      <th className="py-2.5 px-3 text-right">Qoldiq</th>
                      <th className="py-2.5 px-3">Filial</th>
                      <th className="py-2.5 px-3">Holati</th>
                      <th className="py-2.5 pl-3 text-right">Amal</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-100 text-sm">
                    {filteredProducts.map((p) => (
                      <tr key={p.id} className="hover:bg-slate-50/70">
                        <td className="py-3 pr-4">
                          <div className="font-semibold text-slate-900">{p.name}</div>
                          <div className="font-mono text-xs text-slate-500">{p.sku}</div>
                        </td>
                        <td className="py-3 px-3 text-xs text-slate-600">{p.category}</td>
                        <td className="py-3 px-3 text-right font-mono text-xs text-slate-600 tabular-nums whitespace-nowrap">
                          {formatUZS(p.purchasePrice)}
                        </td>
                        <td className="py-3 px-3 text-right font-mono font-bold text-slate-900 tabular-nums whitespace-nowrap">
                          {formatUZS(p.sellingPrice)}
                        </td>
                        <td className="py-3 px-3 text-right font-mono font-semibold tabular-nums">
                          {p.quantity} dona
                        </td>
                        <td className="py-3 px-3 text-xs text-slate-600">
                          {branchName(p.branchId)}
                        </td>
                        <td className="py-3 px-3">
                          <StatusText
                            tone={
                              p.status === 'Mavjud'
                                ? 'positive'
                                : p.status === 'Kam qolgan'
                                ? 'warning'
                                : 'negative'
                            }
                            label={p.status}
                          />
                        </td>
                        <td className="py-3 pl-3 text-right">
                          {can('manage_inventory') && (
                            <Button size="sm" variant="secondary" onClick={() => openEdit(p)}>
                              <Edit2 className="w-3.5 h-3.5" />
                              Tahrirlash
                            </Button>
                          )}
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>

              <div className="md:hidden space-y-2.5">
                {filteredProducts.map((p) => (
                  <div key={p.id} className="p-3.5 rounded-xl border border-slate-200 space-y-2">
                    <div className="flex items-start justify-between gap-2">
                      <div>
                        <div className="text-sm font-bold text-slate-900">{p.name}</div>
                        <div className="text-xs font-mono text-slate-500">
                          {p.sku} · {p.category}
                        </div>
                      </div>
                      <StatusText
                        tone={
                          p.status === 'Mavjud'
                            ? 'positive'
                            : p.status === 'Kam qolgan'
                            ? 'warning'
                            : 'negative'
                        }
                        label={p.status}
                      />
                    </div>
                    <div className="flex justify-between items-center text-xs pt-1">
                      <span className="font-mono font-semibold text-slate-700">
                        Qoldiq: {p.quantity} dona
                      </span>
                      <span className="font-mono font-bold text-slate-900">
                        {formatUZS(p.sellingPrice)}
                      </span>
                    </div>
                  </div>
                ))}
              </div>
            </>
          )
        ) : dataset.stockMovements.length === 0 ? (
          <EmptyState
            icon={<Package className="w-5 h-5" />}
            title="Ombor harakatlari yo‘q"
            description="Savdo yoki kirim amalga oshirilgach barcha harakatlar bu yerda ko‘rinadi."
          />
        ) : (
          <div className="divide-y divide-slate-100 text-xs">
            {dataset.stockMovements.map((m) => (
              <div key={m.id} className="py-3 flex items-center justify-between gap-3">
                <div>
                  <div className="font-semibold text-slate-900">{m.productName}</div>
                  <div className="text-slate-500">
                    {formatDateUZ(m.createdAt, true)} · {m.note} · {m.actorName}
                  </div>
                </div>
                <span
                  className={`font-mono font-bold tabular-nums ${
                    m.quantityDelta >= 0 ? 'text-emerald-700' : 'text-red-600'
                  }`}
                >
                  {m.quantityDelta >= 0 ? `+${m.quantityDelta}` : m.quantityDelta} dona
                </span>
              </div>
            ))}
          </div>
        )}
      </Card>

      <Modal
        open={modalOpen}
        onClose={() => setModalOpen(false)}
        title={editing ? 'Mahsulotni tahrirlash' : 'Yangi mahsulot qo‘shish'}
      >
        <form onSubmit={handleSubmit} className="space-y-3.5">
          {formErr && (
            <div className="p-3 rounded-lg bg-red-50 border border-red-200 text-xs text-red-700">
              {formErr}
            </div>
          )}
          <div>
            <FieldLabel htmlFor="prod-name" required>
              Mahsulot nomi
            </FieldLabel>
            <Input
              id="prod-name"
              value={name}
              onChange={(e) => setName(e.target.value)}
              placeholder="Masalan: Samsung Galaxy A55"
            />
          </div>
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <div>
              <FieldLabel htmlFor="prod-sku" required>
                SKU kodi
              </FieldLabel>
              <Input
                id="prod-sku"
                value={sku}
                onChange={(e) => setSku(e.target.value)}
                placeholder="SM-A55-128"
              />
            </div>
            <div>
              <FieldLabel htmlFor="prod-cat" required>
                Kategoriya
              </FieldLabel>
              <Input
                id="prod-cat"
                value={category}
                onChange={(e) => setCategory(e.target.value)}
              />
            </div>
          </div>
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <div>
              <FieldLabel htmlFor="prod-buy" required>
                Xarid narxi (so‘m)
              </FieldLabel>
              <Input
                id="prod-buy"
                type="number"
                min="0"
                value={purchasePrice}
                onChange={(e) => setPurchasePrice(e.target.value)}
              />
            </div>
            <div>
              <FieldLabel htmlFor="prod-sell" required>
                Sotuv narxi (so‘m)
              </FieldLabel>
              <Input
                id="prod-sell"
                type="number"
                min="1"
                value={sellingPrice}
                onChange={(e) => setSellingPrice(e.target.value)}
              />
            </div>
          </div>
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
            <div>
              <FieldLabel htmlFor="prod-qty" required>
                Miqdor (dona)
              </FieldLabel>
              <Input
                id="prod-qty"
                type="number"
                min="0"
                value={quantity}
                onChange={(e) => setQuantity(e.target.value)}
              />
            </div>
            <div>
              <FieldLabel htmlFor="prod-min" required>
                Min. qoldiq
              </FieldLabel>
              <Input
                id="prod-min"
                type="number"
                min="0"
                value={minStockLevel}
                onChange={(e) => setMinStockLevel(e.target.value)}
              />
            </div>
            <div>
              <FieldLabel htmlFor="prod-branch">Filial</FieldLabel>
              <Select
                id="prod-branch"
                value={branchId}
                onChange={(e) => setBranchId(e.target.value)}
              >
                {dataset.branches.map((b) => (
                  <option key={b.id} value={b.id}>
                    {b.name}
                  </option>
                ))}
              </Select>
            </div>
          </div>
          <div className="flex justify-end gap-2 pt-2">
            <Button variant="secondary" onClick={() => setModalOpen(false)}>
              Bekor qilish
            </Button>
            <Button type="submit" loading={saving}>
              Saqlash
            </Button>
          </div>
        </form>
      </Modal>
    </div>
  );
}

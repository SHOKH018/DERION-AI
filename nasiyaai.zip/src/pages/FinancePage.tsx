import React, { useMemo, useState } from 'react';
import { Plus, Search, Wallet } from 'lucide-react';
import { useApp } from '../context/AppContext.tsx';
import { formatDateUZ, formatUZS, isWithinDateRange } from '../lib/accounting.ts';
import { transactionSchema } from '../lib/validation.ts';
import type { PaymentMethod, TransactionType } from '../types/domain.ts';
import {
  Button,
  Card,
  EmptyState,
  FieldLabel,
  Input,
  Modal,
  Select,
  StatusText,
} from '../components/ui/Primitives.tsx';

export function FinancePage() {
  const { dataset, summary, selectedBranchId, dateRange, createTransaction, can } = useApp();

  const [search, setSearch] = useState('');
  const [typeFilter, setTypeFilter] = useState<'all' | TransactionType>('all');
  const [methodFilter, setMethodFilter] = useState<'all' | PaymentMethod>('all');
  const [modalOpen, setModalOpen] = useState(false);

  const [txType, setTxType] = useState<'Boshqa kirim' | 'Xarajat'>('Xarajat');
  const [amount, setAmount] = useState('');
  const [category, setCategory] = useState('Ijara');
  const [description, setDescription] = useState('');
  const [date, setDate] = useState('2026-11-25');
  const [paymentMethod, setPaymentMethod] = useState<PaymentMethod>('Naqd');
  const [branchId, setBranchId] = useState(dataset.branches[0]?.id || 'br-main');
  const [formErr, setFormErr] = useState<string | null>(null);
  const [submitting, setSubmitting] = useState(false);

  const filteredTransactions = useMemo(() => {
    return dataset.transactions.filter((tx) => {
      if (selectedBranchId !== 'all' && tx.branchId !== selectedBranchId) return false;
      if (!isWithinDateRange(tx.date, dateRange)) return false;
      if (typeFilter !== 'all' && tx.type !== typeFilter) return false;
      if (methodFilter !== 'all' && tx.paymentMethod !== methodFilter) return false;
      if (
        search.trim() &&
        !`${tx.description} ${tx.category}`.toLowerCase().includes(search.trim().toLowerCase())
      ) {
        return false;
      }
      return true;
    });
  }, [dataset.transactions, selectedBranchId, dateRange, typeFilter, methodFilter, search]);

  const branchName = (id: string) =>
    dataset.branches.find((b) => b.id === id)?.name || 'Asosiy filial';

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setFormErr(null);
    const parsed = transactionSchema.safeParse({
      amount: Number(amount),
      category,
      description,
      date: new Date(date).toISOString(),
      type: txType,
      paymentMethod,
      branchId: branchId || dataset.branches[0]?.id || 'br-main',
    });
    if (!parsed.success) {
      setFormErr(parsed.error.issues[0]?.message || 'Ma’lumotlarni tekshiring.');
      return;
    }
    setSubmitting(true);
    try {
      await createTransaction(parsed.data);
      setAmount('');
      setDescription('');
      setModalOpen(false);
    } catch (err) {
      setFormErr(err instanceof Error ? err.message : 'Saqlashda xatolik.');
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
        <div>
          <h2 className="font-display text-xl font-bold text-slate-900">Moliya boshqaruvi</h2>
          <p className="text-xs sm:text-sm text-slate-500 mt-0.5">
            Savdo tushumi, qarz undiruvi, xarajatlar va sof foyda hisoboti
          </p>
        </div>
        {can('create_transaction') && (
          <Button onClick={() => setModalOpen(true)}>
            <Plus className="w-4 h-4" />
            Tranzaksiya qo‘shish
          </Button>
        )}
      </div>

      {/* Accounting Separation Notice */}
      <Card className="p-4 bg-slate-50/80 text-xs text-slate-600 leading-relaxed">
        <strong className="text-slate-900">Buxgalteriya qoidasi:</strong> Qarzdan qaytgan to‘lovlar
        (<span className="font-mono">Qarz undiruvi</span>) yangi savdo daromadi sifatida
        qo‘shilmaydi. Sof foyda savdo daromadidan mahsulot tannarxi (COGS) va operatsion
        xarajatlarni ayirish orqali hisoblanadi.
      </Card>

      {/* Summary Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <Card className="p-4 space-y-1">
          <div className="text-xs text-slate-500 font-medium">Jami pul tushumi</div>
          <div className="font-display text-xl font-bold text-slate-900 tabular-nums">
            {formatUZS(summary.totalCashInflow)}
          </div>
          <div className="text-[11px] text-slate-500">
            Savdo + Qarz undiruvi ({formatUZS(summary.debtCollections)})
          </div>
        </Card>
        <Card className="p-4 space-y-1">
          <div className="text-xs text-slate-500 font-medium">Operatsion xarajatlar</div>
          <div className="font-display text-xl font-bold text-red-600 tabular-nums">
            {formatUZS(summary.operatingExpenses)}
          </div>
          <div className="text-[11px] text-slate-500">Tannarx (COGS): {formatUZS(summary.totalCOGS)}</div>
        </Card>
        <Card className="p-4 space-y-1">
          <div className="text-xs text-slate-500 font-medium">Sof foyda</div>
          <div
            className={`font-display text-xl font-bold tabular-nums ${
              summary.netProfit >= 0 ? 'text-emerald-700' : 'text-red-600'
            }`}
          >
            {formatUZS(summary.netProfit)}
          </div>
          <div className="text-[11px] text-slate-500">Savdo − Tannarx − Xarajatlar</div>
        </Card>
        <Card className="p-4 space-y-1">
          <div className="text-xs text-slate-500 font-medium">To‘lov turlari bo‘yicha</div>
          <div className="text-xs text-slate-700 space-y-0.5 pt-1 font-mono tabular-nums">
            <div className="flex justify-between">
              <span>Naqd:</span>
              <span>{formatUZS(summary.cashPayments)}</span>
            </div>
            <div className="flex justify-between">
              <span>Karta:</span>
              <span>{formatUZS(summary.cardPayments)}</span>
            </div>
            <div className="flex justify-between">
              <span>O‘tkazma:</span>
              <span>{formatUZS(summary.transferPayments)}</span>
            </div>
          </div>
        </Card>
      </div>

      {/* Filters & Table */}
      <Card className="p-5 space-y-4">
        <div className="grid grid-cols-1 sm:grid-cols-4 gap-3">
          <div className="sm:col-span-2 relative">
            <Search className="w-4 h-4 text-slate-400 absolute left-3 top-3" />
            <Input
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              placeholder="Tavsif yoki kategoriya bo‘yicha qidirish..."
              className="pl-9"
            />
          </div>
          <Select
            aria-label="Tranzaksiya turi"
            value={typeFilter}
            onChange={(e) => setTypeFilter(e.target.value as 'all' | TransactionType)}
          >
            <option value="all">Barcha turlar</option>
            <option value="Savdo tushumi">Savdo tushumi</option>
            <option value="Qarz undiruvi">Qarz undiruvi</option>
            <option value="Boshqa kirim">Boshqa kirim</option>
            <option value="Xarajat">Xarajat</option>
          </Select>
          <Select
            aria-label="To‘lov usuli"
            value={methodFilter}
            onChange={(e) => setMethodFilter(e.target.value as 'all' | PaymentMethod)}
          >
            <option value="all">Barcha usullar</option>
            <option value="Naqd">Naqd</option>
            <option value="Karta">Karta</option>
            <option value="O‘tkazma">O‘tkazma</option>
          </Select>
        </div>

        {filteredTransactions.length === 0 ? (
          <EmptyState
            icon={<Wallet className="w-5 h-5" />}
            title="Ma’lumot topilmadi"
            description="Tanlangan filtrlar bo‘yicha moliyaviy operatsiyalar topilmadi."
          />
        ) : (
          <>
            <div className="hidden md:block overflow-x-auto">
              <table className="w-full text-left border-collapse">
                <thead>
                  <tr className="border-b border-slate-200 text-xs font-semibold text-slate-500">
                    <th className="py-2.5 pr-4">Sana</th>
                    <th className="py-2.5 px-4">Tavsif</th>
                    <th className="py-2.5 px-4">Kategoriya</th>
                    <th className="py-2.5 px-4">Turi</th>
                    <th className="py-2.5 px-4">Usul</th>
                    <th className="py-2.5 px-4">Filial</th>
                    <th className="py-2.5 px-4 text-right">Summa</th>
                    <th className="py-2.5 pl-4 text-right">Holati</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100 text-sm">
                  {filteredTransactions.map((tx) => (
                    <tr key={tx.id} className="hover:bg-slate-50/70">
                      <td className="py-3 pr-4 font-mono text-xs text-slate-500 tabular-nums whitespace-nowrap">
                        {formatDateUZ(tx.date)}
                      </td>
                      <td className="py-3 px-4 font-medium text-slate-900">{tx.description}</td>
                      <td className="py-3 px-4 text-xs text-slate-600">{tx.category}</td>
                      <td className="py-3 px-4 text-xs text-slate-700">{tx.type}</td>
                      <td className="py-3 px-4 text-xs text-slate-600">{tx.paymentMethod}</td>
                      <td className="py-3 px-4 text-xs text-slate-600">{branchName(tx.branchId)}</td>
                      <td
                        className={`py-3 px-4 text-right font-mono font-bold tabular-nums whitespace-nowrap ${
                          tx.type === 'Xarajat' ? 'text-red-600' : 'text-emerald-700'
                        }`}
                      >
                        {tx.type === 'Xarajat' ? '-' : '+'}
                        {formatUZS(tx.amount)}
                      </td>
                      <td className="py-3 pl-4 text-right">
                        <StatusText tone="positive" label={tx.status} />
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>

            <div className="md:hidden space-y-2.5">
              {filteredTransactions.map((tx) => (
                <div
                  key={tx.id}
                  className="p-3.5 rounded-xl border border-slate-200 bg-slate-50/50 space-y-1.5"
                >
                  <div className="flex items-start justify-between gap-2">
                    <span className="text-sm font-semibold text-slate-900">{tx.description}</span>
                    <span
                      className={`font-mono text-sm font-bold tabular-nums shrink-0 ${
                        tx.type === 'Xarajat' ? 'text-red-600' : 'text-emerald-700'
                      }`}
                    >
                      {tx.type === 'Xarajat' ? '-' : '+'}
                      {formatUZS(tx.amount)}
                    </span>
                  </div>
                  <div className="text-xs text-slate-500">
                    {formatDateUZ(tx.date)} · {tx.category} · {tx.type} · {tx.paymentMethod}
                  </div>
                </div>
              ))}
            </div>
          </>
        )}
      </Card>

      <Modal open={modalOpen} onClose={() => setModalOpen(false)} title="Yangi moliyaviy operatsiya">
        <form onSubmit={handleSubmit} className="space-y-3.5">
          {formErr && (
            <div className="p-3 rounded-lg bg-red-50 border border-red-200 text-xs text-red-700">
              {formErr}
            </div>
          )}
          <div className="flex gap-1 p-1 bg-slate-100 rounded-lg">
            <button
              type="button"
              onClick={() => setTxType('Xarajat')}
              className={`flex-1 py-1.5 text-xs font-medium rounded-md cursor-pointer ${
                txType === 'Xarajat' ? 'bg-white text-slate-900 shadow-sm' : 'text-slate-600'
              }`}
            >
              Xarajat
            </button>
            <button
              type="button"
              onClick={() => setTxType('Boshqa kirim')}
              className={`flex-1 py-1.5 text-xs font-medium rounded-md cursor-pointer ${
                txType === 'Boshqa kirim' ? 'bg-white text-slate-900 shadow-sm' : 'text-slate-600'
              }`}
            >
              Boshqa kirim
            </button>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <div>
              <FieldLabel htmlFor="fin-amount" required>
                Summa (so‘m)
              </FieldLabel>
              <Input
                id="fin-amount"
                type="number"
                min="1"
                value={amount}
                onChange={(e) => setAmount(e.target.value)}
                placeholder="1 000 000"
              />
            </div>
            <div>
              <FieldLabel htmlFor="fin-cat" required>
                Kategoriya
              </FieldLabel>
              <Select
                id="fin-cat"
                value={category}
                onChange={(e) => setCategory(e.target.value)}
              >
                <option value="Ijara">Ijara</option>
                <option value="Ish haqi">Ish haqi</option>
                <option value="Logistika">Logistika</option>
                <option value="Kommunal">Kommunal</option>
                <option value="Marketing">Marketing</option>
                <option value="Investitsiya">Investitsiya</option>
                <option value="Boshqa">Boshqa</option>
              </Select>
            </div>
          </div>

          <div>
            <FieldLabel htmlFor="fin-desc" required>
              Tavsif
            </FieldLabel>
            <Input
              id="fin-desc"
              value={description}
              onChange={(e) => setDescription(e.target.value)}
              placeholder="Operatsiya tafsiloti"
            />
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
            <div>
              <FieldLabel htmlFor="fin-date" required>
                Sana
              </FieldLabel>
              <Input
                id="fin-date"
                type="date"
                value={date}
                onChange={(e) => setDate(e.target.value)}
              />
            </div>
            <div>
              <FieldLabel htmlFor="fin-method">To‘lov usuli</FieldLabel>
              <Select
                id="fin-method"
                value={paymentMethod}
                onChange={(e) => setPaymentMethod(e.target.value as PaymentMethod)}
              >
                <option value="Naqd">Naqd</option>
                <option value="Karta">Karta</option>
                <option value="O‘tkazma">O‘tkazma</option>
              </Select>
            </div>
            <div>
              <FieldLabel htmlFor="fin-branch">Filial</FieldLabel>
              <Select
                id="fin-branch"
                value={branchId}
                onChange={(e) => setBranchId(e.target.value)}
              >
                {dataset.branches.map((b) => (
                  <option key={b.id} value={b.id}>
                    {b.name}
                  </option>
                ))}
              </Select>
            </div>
          </div>

          <div className="flex justify-end gap-2 pt-2">
            <Button variant="secondary" onClick={() => setModalOpen(false)}>
              Bekor qilish
            </Button>
            <Button type="submit" loading={submitting}>
              Saqlash
            </Button>
          </div>
        </form>
      </Modal>
    </div>
  );
}

import React, { useState } from 'react';
import { CheckCircle2, Globe, Server, ShieldCheck, Smartphone } from 'lucide-react';
import { useApp } from '../context/AppContext.tsx';
import { API_ENDPOINTS_CONTRACT } from '../services/apiClient.ts';
import type { LanguageCode } from '../types/domain.ts';
import { Button, Card, FieldLabel, Input, Select, StatusText } from '../components/ui/Primitives.tsx';

export function SettingsPage() {
  const { dataset, updateSettings, can, backendCapabilities, mode } = useApp();

  const [shopName, setShopName] = useState(dataset.settings.shopName);
  const [legalName, setLegalName] = useState(dataset.settings.legalName);
  const [language, setLanguage] = useState<LanguageCode>(dataset.settings.language);
  const [apiBaseUrl, setApiBaseUrl] = useState(dataset.settings.apiBaseUrl);
  const [overdueAlerts, setOverdueAlerts] = useState(
    dataset.settings.notifications.overdueDebtAlerts
  );
  const [lowStockAlerts, setLowStockAlerts] = useState(
    dataset.settings.notifications.lowStockAlerts
  );
  const [dailySummary, setDailySummary] = useState(
    dataset.settings.notifications.dailySummaryAt2000
  );
  const [saving, setSaving] = useState(false);

  const handleSave = async (e: React.FormEvent) => {
    e.preventDefault();
    setSaving(true);
    try {
      await updateSettings({
        shopName: shopName.trim() || 'NasiyaAI Do‘koni',
        legalName: legalName.trim(),
        language,
        apiBaseUrl: apiBaseUrl.trim() || '/api',
        notifications: {
          ...dataset.settings.notifications,
          overdueDebtAlerts: overdueAlerts,
          lowStockAlerts,
          dailySummaryAt2000: dailySummary,
        },
      });
    } finally {
      setSaving(false);
    }
  };

  return (
    <div className="space-y-6">
      <div>
        <h2 className="font-display text-xl font-bold text-slate-900">Sozlamalar va integratsiya</h2>
        <p className="text-xs sm:text-sm text-slate-500 mt-0.5">
          Biznes profili, til, bildirishnomalar, Telegram bot va backend API shartnomasi
        </p>
      </div>

      <form onSubmit={handleSave} className="grid grid-cols-1 lg:grid-cols-2 gap-4">
        <Card className="p-5 space-y-4">
          <div className="flex items-center gap-2 text-xs font-semibold text-slate-700">
            <Globe className="w-4 h-4 text-[#2563EB]" />
            <span>Biznes profili va lokalizatsiya</span>
          </div>
          <div>
            <FieldLabel htmlFor="set-shop" required>
              Do‘kon nomi
            </FieldLabel>
            <Input
              id="set-shop"
              value={shopName}
              onChange={(e) => setShopName(e.target.value)}
            />
          </div>
          <div>
            <FieldLabel htmlFor="set-legal">Yuridik nomi</FieldLabel>
            <Input
              id="set-legal"
              value={legalName}
              onChange={(e) => setLegalName(e.target.value)}
              placeholder="Masalan: Baraka Savdo MChJ"
            />
          </div>
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
            <div>
              <FieldLabel htmlFor="set-lang">Interfeys tili</FieldLabel>
              <Select
                id="set-lang"
                value={language}
                onChange={(e) => setLanguage(e.target.value as LanguageCode)}
              >
                <option value="uz">O‘zbek (Lotin)</option>
                <option value="ru">Русский</option>
                <option value="en">English</option>
              </Select>
            </div>
            <div>
              <FieldLabel htmlFor="set-cur">Valyuta</FieldLabel>
              <Input id="set-cur" value="UZS (so‘m)" disabled />
            </div>
            <div>
              <FieldLabel htmlFor="set-tz">Vaqt mintaqasi</FieldLabel>
              <Input id="set-tz" value="Asia/Tashkent" disabled />
            </div>
          </div>
        </Card>

        <Card className="p-5 space-y-4">
          <div className="flex items-center gap-2 text-xs font-semibold text-slate-700">
            <Smartphone className="w-4 h-4 text-[#2563EB]" />
            <span>Telegram Bot, To‘lovlar va Bildirishnomalar</span>
          </div>

          <div className="space-y-2.5 text-xs">
            <label className="flex items-center justify-between p-3 rounded-xl border border-slate-200 cursor-pointer">
              <span className="font-medium text-slate-800">Muddati o‘tgan qarz ogohlantirishi</span>
              <input
                type="checkbox"
                checked={overdueAlerts}
                onChange={(e) => setOverdueAlerts(e.target.checked)}
                className="w-4 h-4 accent-[#2563EB]"
              />
            </label>
            <label className="flex items-center justify-between p-3 rounded-xl border border-slate-200 cursor-pointer">
              <span className="font-medium text-slate-800">Ombor kam qolganda ogohlantirish</span>
              <input
                type="checkbox"
                checked={lowStockAlerts}
                onChange={(e) => setLowStockAlerts(e.target.checked)}
                className="w-4 h-4 accent-[#2563EB]"
              />
            </label>
            <label className="flex items-center justify-between p-3 rounded-xl border border-slate-200 cursor-pointer">
              <span className="font-medium text-slate-800">Kunlik hisobot (20:00 Asia/Tashkent)</span>
              <input
                type="checkbox"
                checked={dailySummary}
                onChange={(e) => setDailySummary(e.target.checked)}
                className="w-4 h-4 accent-[#2563EB]"
              />
            </label>
          </div>

          <div className="pt-2 border-t border-slate-100 flex flex-wrap items-center justify-between gap-2 text-xs">
            <span className="text-slate-600">
              Telegram Bot ({dataset.settings.telegramBotUsername}):
            </span>
            <StatusText
              tone={backendCapabilities.telegramBotConfigured ? 'positive' : 'warning'}
              label={
                backendCapabilities.telegramBotConfigured
                  ? 'Bot token serverda ulangan'
                  : 'TELEGRAM_BOT_TOKEN sozlanmagan'
              }
            />
          </div>

          <div className="flex flex-wrap items-center justify-between gap-2 text-xs">
            <span className="text-slate-600">To‘lov tizimlari (integratsiya holati):</span>
            <span className="text-slate-700 font-medium">
              Payme · Click · Uzum (backend webhook orqali)
            </span>
          </div>
        </Card>

        <Card className="p-5 lg:col-span-2 space-y-4">
          <div className="flex flex-wrap items-center justify-between gap-2">
            <div className="flex items-center gap-2 text-xs font-semibold text-slate-700">
              <Server className="w-4 h-4 text-[#2563EB]" />
              <span>Backend API integratsiya konfiguratsiyasi</span>
            </div>
            <StatusText
              tone="info"
              label={mode === 'demo' ? 'Hozir Demo rejim faol' : 'Real API rejim faol'}
            />
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4 items-end">
            <div>
              <FieldLabel htmlFor="set-api-url">API Base URL (Python FastAPI / Express)</FieldLabel>
              <Input
                id="set-api-url"
                value={apiBaseUrl}
                onChange={(e) => setApiBaseUrl(e.target.value)}
                placeholder="/api"
              />
            </div>
            <div className="flex justify-end">
              {can('manage_settings') && (
                <Button type="submit" loading={saving}>
                  <CheckCircle2 className="w-4 h-4" />
                  Sozlamalarni saqlash
                </Button>
              )}
            </div>
          </div>
        </Card>
      </form>

      {/* Transparent Integration Contract Status */}
      <Card className="p-5 space-y-3">
        <div className="flex items-center gap-2 text-xs font-semibold text-slate-700">
          <ShieldCheck className="w-4 h-4 text-emerald-600" />
          <span>API Shartnomasi va Mavjud Python Telegram Bot Integratsiyasi Holati</span>
        </div>
        <p className="text-xs text-slate-500">
          Ushbu jadval frontend API mijozi va mahalliy Express / tashqi Python FastAPI (aiogram 3)
          backendi o‘rtasidagi endpointlar shartnomasini ko‘rsatadi.
        </p>
        <div className="overflow-x-auto">
          <table className="w-full text-left border-collapse text-xs">
            <thead>
              <tr className="border-b border-slate-200 text-slate-500 font-semibold">
                <th className="py-2 pr-4">Metod</th>
                <th className="py-2 px-3">Endpoint</th>
                <th className="py-2 px-3">Bo‘lim</th>
                <th className="py-2 px-3">Vazifasi</th>
                <th className="py-2 pl-3 text-right">Express / Shartnoma</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {API_ENDPOINTS_CONTRACT.map((ep) => (
                <tr key={`${ep.method}-${ep.path}`}>
                  <td className="py-2 pr-4 font-mono font-bold text-slate-700">{ep.method}</td>
                  <td className="py-2 px-3 font-mono text-slate-900">{ep.path}</td>
                  <td className="py-2 px-3 text-slate-600">{ep.module}</td>
                  <td className="py-2 px-3 text-slate-600">{ep.externalPythonBotNote}</td>
                  <td className="py-2 pl-3 text-right">
                    <StatusText
                      tone={ep.localExpressImplemented ? 'positive' : 'warning'}
                      label={ep.localExpressImplemented ? 'Tayyor' : 'Kutilmoqda'}
                    />
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </Card>
    </div>
  );
}

import React, { useMemo, useState } from 'react';
import { Bell, CheckCheck, ExternalLink } from 'lucide-react';
import { useApp } from '../context/AppContext.tsx';
import { formatDateUZ } from '../lib/accounting.ts';
import { Button, Card, EmptyState, StatusText } from '../components/ui/Primitives.tsx';

export function NotificationsPage() {
  const {
    dataset,
    markNotificationRead,
    markAllNotificationsRead,
    setActivePage,
    setSelectedDebtId,
  } = useApp();
  const [filter, setFilter] = useState<'all' | 'unread'>('all');

  const items = useMemo(() => {
    return dataset.notifications.filter((n) => (filter === 'unread' ? !n.isRead : true));
  }, [dataset.notifications, filter]);

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
        <div>
          <h2 className="font-display text-xl font-bold text-slate-900">Bildirishnomalar markazi</h2>
          <p className="text-xs sm:text-sm text-slate-500 mt-0.5">
            Qarz muddatlari, ombor ogohlantirishlari va AI tavsiyalari
          </p>
        </div>
        <div className="flex items-center gap-2">
          <div className="flex gap-1 p-1 bg-slate-100 rounded-lg">
            <button
              type="button"
              onClick={() => setFilter('all')}
              className={`px-3 py-1 text-xs font-medium rounded-md cursor-pointer ${
                filter === 'all' ? 'bg-white text-slate-900 shadow-sm' : 'text-slate-600'
              }`}
            >
              Barchasi
            </button>
            <button
              type="button"
              onClick={() => setFilter('unread')}
              className={`px-3 py-1 text-xs font-medium rounded-md cursor-pointer ${
                filter === 'unread' ? 'bg-white text-slate-900 shadow-sm' : 'text-slate-600'
              }`}
            >
              O‘qilmagan
            </button>
          </div>
          <Button size="sm" variant="secondary" onClick={markAllNotificationsRead}>
            <CheckCheck className="w-4 h-4" />
            Barchasini o‘qilgan qilish
          </Button>
        </div>
      </div>

      <Card className="p-5">
        {items.length === 0 ? (
          <EmptyState
            icon={<Bell className="w-5 h-5" />}
            title="Bildirishnomalar yo‘q"
            description="Hozircha yangi xabarlar mavjud emas."
          />
        ) : (
          <div className="divide-y divide-slate-100">
            {items.map((n) => (
              <div
                key={n.id}
                className={`py-4 flex flex-col sm:flex-row sm:items-center justify-between gap-3 ${
                  !n.isRead ? 'bg-blue-50/30 -mx-5 px-5' : ''
                }`}
              >
                <div className="space-y-1">
                  <div className="flex flex-wrap items-center gap-2">
                    <StatusText
                      tone={
                        n.type === 'Muddati o‘tgan qarz' || n.type === 'G‘ayrioddiy xarajat'
                          ? 'negative'
                          : n.type === 'Kam qolgan mahsulot'
                          ? 'warning'
                          : n.type === 'To‘lov qabul qilindi'
                          ? 'positive'
                          : 'info'
                      }
                      label={n.type}
                    />
                    <span className="text-xs font-mono text-slate-500">
                      {formatDateUZ(n.createdAt, true)}
                    </span>
                    {!n.isRead && <span className="text-[11px] font-semibold text-[#2563EB]">Yangi</span>}
                  </div>
                  <div className="text-sm font-bold text-slate-900">{n.title}</div>
                  <p className="text-xs text-slate-600">{n.message}</p>
                </div>

                <div className="flex items-center gap-2 shrink-0">
                  {!n.isRead && (
                    <Button
                      size="sm"
                      variant="ghost"
                      onClick={() => void markNotificationRead(n.id)}
                    >
                      O‘qildi
                    </Button>
                  )}
                  <Button
                    size="sm"
                    variant="secondary"
                    onClick={() => {
                      void markNotificationRead(n.id);
                      if (n.targetPage === 'debts' && n.relatedId) {
                        setSelectedDebtId(n.relatedId);
                      }
                      setActivePage(n.targetPage);
                    }}
                  >
                    <ExternalLink className="w-3.5 h-3.5" />
                    Ochish
                  </Button>
                </div>
              </div>
            ))}
          </div>
        )}
      </Card>
    </div>
  );
}

import React, { useMemo } from 'react';
import {
  ArrowDownRight,
  ArrowUpRight,
  Bot,
  CreditCard,
  Plus,
  Receipt,
  ShoppingBag,
  TrendingUp,
  UserPlus,
  Wallet,
} from 'lucide-react';
import {
  Area,
  AreaChart,
  Bar,
  BarChart,
  CartesianGrid,
  ResponsiveContainer,
  Tooltip,
  XAxis,
  YAxis,
} from 'recharts';
import { useApp } from '../context/AppContext.tsx';
import {
  formatCompactUZS,
  formatDateUZ,
  formatUZS,
  isWithinDateRange,
  resolveDebtStatus,
} from '../lib/accounting.ts';
import { Button, Card, EmptyState, SkeletonBlock, StatusText } from '../components/ui/Primitives.tsx';

export function DashboardPage() {
  const {
    user,
    dataset,
    summary,
    selectedBranchId,
    dateRange,
    loadingData,
    dataError,
    refreshData,
    setQuickModal,
    setActivePage,
    setSelectedDebtId,
    can,
    mode,
  } = useApp();

  const branchFilter = (bId: string) => selectedBranchId === 'all' || bId === selectedBranchId;

  const filteredSales = useMemo(
    () =>
      dataset.sales.filter(
        (s) => branchFilter(s.branchId) && isWithinDateRange(s.createdAt, dateRange)
      ),
    [dataset.sales, selectedBranchId, dateRange]
  );

  const filteredTransactions = useMemo(
    () =>
      dataset.transactions.filter(
        (tx) => branchFilter(tx.branchId) && isWithinDateRange(tx.date, dateRange)
      ),
    [dataset.transactions, selectedBranchId, dateRange]
  );

  const filteredDebts = useMemo(
    () => dataset.debts.filter((d) => branchFilter(d.branchId)),
    [dataset.debts, selectedBranchId]
  );

  const overdueDebts = useMemo(
    () =>
      filteredDebts.filter(
        (d) =>
          d.remainingAmount > 0 &&
          resolveDebtStatus(d.remainingAmount, d.paidAmount, d.dueDate) === 'Muddati o‘tgan'
      ),
    [filteredDebts]
  );

  const topDebtors = useMemo(() => {
    const map = new Map<string, { name: string; phone: string; remaining: number; count: number }>();
    for (const d of filteredDebts) {
      if (d.remainingAmount <= 0) continue;
      const cur = map.get(d.customerId) || {
        name: d.customerName,
        phone: d.customerPhone,
        remaining: 0,
        count: 0,
      };
      cur.remaining += d.remainingAmount;
      cur.count += 1;
      map.set(d.customerId, cur);
    }
    return Array.from(map.entries())
      .map(([id, v]) => ({ id, ...v }))
      .sort((a, b) => b.remaining - a.remaining)
      .slice(0, 5);
  }, [filteredDebts]);

  // Daily chart aggregation
  const chartData = useMemo(() => {
    const dayMap = new Map<
      string,
      { day: string; savdo: number; tushum: number; xarajat: number; undiruv: number }
    >();

    const ensureDay = (iso: string) => {
      const key = formatDateUZ(iso).slice(0, 5);
      if (!dayMap.has(key)) {
        dayMap.set(key, { day: key, savdo: 0, tushum: 0, xarajat: 0, undiruv: 0 });
      }
      return dayMap.get(key)!;
    };

    for (const s of filteredSales) {
      const row = ensureDay(s.createdAt);
      row.savdo += s.totalAmount;
      row.tushum += s.paidAmount;
    }

    for (const tx of filteredTransactions) {
      const row = ensureDay(tx.date);
      if (tx.type === 'Xarajat') row.xarajat += tx.amount;
      else if (tx.type === 'Qarz undiruvi') {
        row.undiruv += tx.amount;
        row.tushum += tx.amount;
      } else if (tx.type === 'Boshqa kirim') {
        row.tushum += tx.amount;
      }
    }

    return Array.from(dayMap.values()).reverse().slice(-10);
  }, [filteredSales, filteredTransactions]);

  if (loadingData) {
    return (
      <div className="space-y-6">
        <SkeletonBlock className="h-24" />
        <div className="grid grid-cols-1 sm:grid-cols-2 xl:grid-cols-3 gap-4">
          {Array.from({ length: 6 }).map((_, i) => (
            <SkeletonBlock key={i} className="h-32" />
          ))}
        </div>
        <SkeletonBlock className="h-72" />
      </div>
    );
  }

  if (dataError) {
    return (
      <Card className="p-8 text-center space-y-3">
        <h2 className="font-display text-base font-bold text-slate-900">
          Ma’lumotlarni yuklashda xatolik
        </h2>
        <p className="text-xs text-red-600">{dataError}</p>
        <Button size="sm" onClick={() => void refreshData()}>
          Qayta urinish
        </Button>
      </Card>
    );
  }

  const kpiCards = [
    {
      label: 'Jami savdo',
      value: summary.totalSalesRevenue,
      delta: mode === 'demo' ? '+14.2%' : '—',
      positive: true,
      note: 'Tanlangan davrdagi jami sotuv hajmi',
    },
    {
      label: 'Sof foyda',
      value: summary.netProfit,
      delta: mode === 'demo' ? '+9.8%' : '—',
      positive: summary.netProfit >= 0,
      note: 'Tannarx va xarajatlar ayirilgan',
    },
    {
      label: 'Jami tushum',
      value: summary.totalCashInflow,
      delta: mode === 'demo' ? '+11.4%' : '—',
      positive: true,
      note: 'Kassaga kelib tushgan mablag‘',
    },
    {
      label: 'Jami xarajat',
      value: summary.operatingExpenses,
      delta: mode === 'demo' ? '-3.1%' : '—',
      positive: false,
      note: 'Operatsion xarajatlar yig‘indisi',
    },
    {
      label: 'Undirilgan qarz',
      value: summary.debtCollections,
      delta: mode === 'demo' ? '+18.5%' : '—',
      positive: true,
      note: 'Qarzlardan qaytgan to‘lovlar',
    },
    {
      label: 'Qolgan qarz',
      value: summary.outstandingDebt,
      delta: `${summary.activeDebtorsCount} ta qarzdor`,
      positive: summary.overdueDebt === 0,
      note: `Muddati o‘tgan: ${formatUZS(summary.overdueDebt)}`,
    },
  ];

  return (
    <div className="space-y-6">
      {/* Greeting & Quick Actions */}
      <div className="flex flex-col xl:flex-row xl:items-center xl:justify-between gap-4">
        <div className="min-w-0">
          <h2 className="font-display text-xl sm:text-2xl font-bold text-slate-900 tracking-tight">
            Assalomu alaykum, {user?.fullName || 'Tadbirkor'}
          </h2>
          <p className="text-xs sm:text-sm text-slate-500 mt-0.5">
            {dataset.settings.shopName} · Asia/Tashkent vaqti · Valyuta: UZS
          </p>
        </div>

        <div className="flex flex-wrap items-center gap-2 shrink-0">
          {can('create_sale') && (
            <Button size="sm" onClick={() => setActivePage('sales')}>
              <ShoppingBag className="w-4 h-4" />
              Savdo yaratish
            </Button>
          )}
          {can('accept_payment') && (
            <Button size="sm" variant="secondary" onClick={() => setQuickModal('payment')}>
              <CreditCard className="w-4 h-4" />
              To‘lov qabul qilish
            </Button>
          )}
          {can('create_debt') && (
            <Button size="sm" variant="secondary" onClick={() => setQuickModal('debt')}>
              <Plus className="w-4 h-4" />
              Qarz qo‘shish
            </Button>
          )}
          {can('manage_customers') && (
            <Button size="sm" variant="secondary" onClick={() => setQuickModal('customer')}>
              <UserPlus className="w-4 h-4" />
              Mijoz qo‘shish
            </Button>
          )}
          {can('create_transaction') && (
            <Button size="sm" variant="secondary" onClick={() => setQuickModal('expense')}>
              <Receipt className="w-4 h-4" />
              Xarajat qo‘shish
            </Button>
          )}
        </div>
      </div>

      {/* 6 KPI Cards (horizontally scrollable on narrow mobile, crisp grid on tablet/desktop) */}
      <div className="flex sm:grid sm:grid-cols-2 xl:grid-cols-3 gap-4 overflow-x-auto no-scrollbar pb-1 snap-x">
        {kpiCards.map((kpi) => (
          <Card
            key={kpi.label}
            className="min-w-[260px] sm:min-w-0 snap-start p-5 flex flex-col justify-between gap-3"
          >
            <div className="flex items-center justify-between gap-2">
              <span className="text-xs font-semibold text-slate-500">{kpi.label}</span>
              <span
                className={`inline-flex items-center gap-1 text-xs font-mono font-semibold ${
                  kpi.positive ? 'text-emerald-700' : 'text-red-600'
                }`}
              >
                {kpi.positive ? (
                  <ArrowUpRight className="w-3.5 h-3.5" />
                ) : (
                  <ArrowDownRight className="w-3.5 h-3.5" />
                )}
                {kpi.delta}
              </span>
            </div>
            <div>
              <div className="font-display text-xl sm:text-2xl font-bold text-slate-900 tabular-nums">
                {formatUZS(kpi.value)}
              </div>
              <p className="text-[11px] text-slate-500 mt-1">{kpi.note}</p>
            </div>
          </Card>
        ))}
      </div>

      {/* AI Daily Insight Strip */}
      <Card className="p-5 bg-gradient-to-r from-[#EFF6FF] via-white to-[#EEF2FF] border-blue-200/80">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div className="space-y-1">
            <div className="flex items-center gap-2 text-xs font-semibold text-[#2563EB]">
              <Bot className="w-4 h-4" />
              <span>AI Kunlik Tahlil (Evristik xulosa)</span>
            </div>
            <p className="text-sm font-medium text-slate-800 leading-relaxed">
              {overdueDebts.length > 0
                ? `${overdueDebts.length} ta mijozda jami ${formatUZS(
                    summary.overdueDebt
                  )} muddati o‘tgan qarz mavjud. Bugun ularga eslatma yuborish pul oqimini tezlashtiradi.`
                : summary.totalSalesRevenue > 0
                ? `Savdo hajmi ${formatUZS(
                    summary.totalSalesRevenue
                  )}, sof foyda ${formatUZS(
                    summary.netProfit
                  )}. Muddati o‘tgan qarzlar nazorat ostida.`
                : 'Hozircha tahlil uchun yetarli savdo ma’lumotlari kiritilmagan. Birinchi savdo yoki qarzni kiriting.'}
            </p>
          </div>
          <Button variant="ai" size="sm" onClick={() => setActivePage('ai')}>
            AI Markaziga o‘tish
          </Button>
        </div>
      </Card>

      {/* Financial Charts */}
      <div className="grid grid-cols-1 xl:grid-cols-2 gap-4">
        <Card className="p-5">
          <div className="flex items-center justify-between mb-4">
            <div>
              <h3 className="text-sm font-bold text-slate-900">Kunlik tushum va xarajatlar</h3>
              <p className="text-xs text-slate-500">Kassa kirim va chiqimlari dinamikasi</p>
            </div>
            <TrendingUp className="w-4 h-4 text-slate-400" />
          </div>
          {chartData.length === 0 ? (
            <EmptyState
              icon={<Wallet className="w-5 h-5" />}
              title="Grafik uchun ma’lumot yo‘q"
              description="Tanlangan davr uchun tranzaksiyalar kiritilgach grafik shakllanadi."
            />
          ) : (
            <div className="h-64 w-full">
              <ResponsiveContainer width="100%" height="100%">
                <BarChart data={chartData}>
                  <CartesianGrid strokeDasharray="3 3" stroke="#E2E8F0" vertical={false} />
                  <XAxis dataKey="day" tick={{ fontSize: 11, fill: '#64748B' }} />
                  <YAxis
                    tickFormatter={(v) => formatCompactUZS(Number(v))}
                    tick={{ fontSize: 11, fill: '#64748B' }}
                    width={74}
                  />
                  <Tooltip
                    formatter={(val) => formatUZS(Number(val))}
                    contentStyle={{
                      borderRadius: '10px',
                      border: '1px solid #E2E8F0',
                      fontSize: '12px',
                    }}
                  />
                  <Bar dataKey="tushum" name="Tushum" fill="#2563EB" radius={[4, 4, 0, 0]} />
                  <Bar dataKey="xarajat" name="Xarajat" fill="#EF4444" radius={[4, 4, 0, 0]} />
                </BarChart>
              </ResponsiveContainer>
            </div>
          )}
        </Card>

        <Card className="p-5">
          <div className="flex items-center justify-between mb-4">
            <div>
              <h3 className="text-sm font-bold text-slate-900">Savdo va qarz undiruvi trendi</h3>
              <p className="text-xs text-slate-500">
                Savdo daromadi va qarzdan qaytgan mablag‘lar alohida ko‘rsatilgan
              </p>
            </div>
            <TrendingUp className="w-4 h-4 text-slate-400" />
          </div>
          {chartData.length === 0 ? (
            <EmptyState
              icon={<ShoppingBag className="w-5 h-5" />}
              title="Savdo tarixi bo‘sh"
              description="Yangi savdo qo‘shilgach kunlik trend shu yerda ko‘rinadi."
            />
          ) : (
            <div className="h-64 w-full">
              <ResponsiveContainer width="100%" height="100%">
                <AreaChart data={chartData}>
                  <CartesianGrid strokeDasharray="3 3" stroke="#E2E8F0" vertical={false} />
                  <XAxis dataKey="day" tick={{ fontSize: 11, fill: '#64748B' }} />
                  <YAxis
                    tickFormatter={(v) => formatCompactUZS(Number(v))}
                    tick={{ fontSize: 11, fill: '#64748B' }}
                    width={74}
                  />
                  <Tooltip
                    formatter={(val) => formatUZS(Number(val))}
                    contentStyle={{
                      borderRadius: '10px',
                      border: '1px solid #E2E8F0',
                      fontSize: '12px',
                    }}
                  />
                  <Area
                    type="monotone"
                    dataKey="savdo"
                    name="Savdo hajmi"
                    stroke="#2563EB"
                    fill="#DBEAFE"
                    strokeWidth={2}
                  />
                  <Area
                    type="monotone"
                    dataKey="undiruv"
                    name="Qarz undiruvi"
                    stroke="#16A34A"
                    fill="#DCFCE7"
                    strokeWidth={2}
                  />
                </AreaChart>
              </ResponsiveContainer>
            </div>
          )}
        </Card>
      </div>

      {/* Bottom Operational Lists: Top Debtors, Overdue Debts, Recent Sales & Transactions */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
        {/* Top Debtors & Overdue Debts */}
        <Card className="p-5">
          <div className="flex items-center justify-between mb-4">
            <h3 className="text-sm font-bold text-slate-900">Eng yirik qarzdorlar va muddati o‘tganlar</h3>
            <button
              type="button"
              onClick={() => setActivePage('debts')}
              className="text-xs font-semibold text-[#2563EB] hover:underline cursor-pointer"
            >
              Barchasi
            </button>
          </div>
          {topDebtors.length === 0 ? (
            <EmptyState
              icon={<CreditCard className="w-5 h-5" />}
              title="Aktiv qarzdorlar yo‘q"
              description="Barcha qarzlar yopilgan yoki hali nasiya yozuvi yaratilmagan."
            />
          ) : (
            <div className="divide-y divide-slate-100">
              {topDebtors.map((d) => {
                const isOverdue = overdueDebts.some((od) => od.customerId === d.id);
                return (
                  <div
                    key={d.id}
                    className="py-3 flex items-center justify-between gap-3"
                  >
                    <div className="min-w-0">
                      <div className="text-sm font-semibold text-slate-900 truncate">
                        {d.name}
                      </div>
                      <div className="text-xs text-slate-500">
                        {d.phone} · {d.count} ta shartnoma
                      </div>
                    </div>
                    <div className="text-right shrink-0 space-y-1">
                      <div className="font-mono text-sm font-bold text-slate-900 tabular-nums">
                        {formatUZS(d.remaining)}
                      </div>
                      {isOverdue ? (
                        <StatusText tone="negative" label="Muddati o‘tgan" />
                      ) : (
                        <StatusText tone="warning" label="Faol qarz" />
                      )}
                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </Card>

        {/* Recent Transactions */}
        <Card className="p-5">
          <div className="flex items-center justify-between mb-4">
            <h3 className="text-sm font-bold text-slate-900">So‘nggi tranzaksiyalar</h3>
            <button
              type="button"
              onClick={() => setActivePage('finance')}
              className="text-xs font-semibold text-[#2563EB] hover:underline cursor-pointer"
            >
              Moliya bo‘limi
            </button>
          </div>
          {filteredTransactions.length === 0 ? (
            <EmptyState
              icon={<Receipt className="w-5 h-5" />}
              title="Tranzaksiyalar topilmadi"
              description="Kirim va xarajatlar kiritilgach so‘nggi operatsiyalar shu yerda ko‘rinadi."
            />
          ) : (
            <div className="divide-y divide-slate-100">
              {filteredTransactions.slice(0, 5).map((tx) => {
                const isExpense = tx.type === 'Xarajat';
                return (
                  <div key={tx.id} className="py-3 flex items-center justify-between gap-3">
                    <div className="min-w-0">
                      <div className="text-sm font-medium text-slate-900 truncate">
                        {tx.description}
                      </div>
                      <div className="text-xs text-slate-500">
                        {formatDateUZ(tx.date, true)} · {tx.type} · {tx.paymentMethod}
                      </div>
                    </div>
                    <div
                      className={`font-mono text-sm font-bold tabular-nums shrink-0 ${
                        isExpense ? 'text-red-600' : 'text-emerald-700'
                      }`}
                    >
                      {isExpense ? '-' : '+'}
                      {formatUZS(tx.amount)}
                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </Card>
      </div>

      {/* Recent Sales & Overdue Quick Action Strip */}
      <Card className="p-5">
        <div className="flex items-center justify-between mb-4">
          <h3 className="text-sm font-bold text-slate-900">So‘nggi savdolar</h3>
          <button
            type="button"
            onClick={() => setActivePage('sales')}
            className="text-xs font-semibold text-[#2563EB] hover:underline cursor-pointer"
          >
            Savdolar sahifasi
          </button>
        </div>
        {filteredSales.length === 0 ? (
          <EmptyState
            icon={<ShoppingBag className="w-5 h-5" />}
            title="Savdolar mavjud emas"
            description="Birinchi savdoni yaratib, tushum va nasiya hisobini yuriting."
            actionLabel="Savdo yaratish"
            onAction={() => setActivePage('sales')}
          />
        ) : (
          <>
            <div className="hidden md:block overflow-x-auto">
              <table className="w-full text-left border-collapse">
                <thead>
                  <tr className="border-b border-slate-200 text-xs font-semibold text-slate-500">
                    <th className="py-2.5 pr-4">Sana</th>
                    <th className="py-2.5 px-4">Mijoz</th>
                    <th className="py-2.5 px-4">Mahsulotlar</th>
                    <th className="py-2.5 px-4 text-right">Jami summa</th>
                    <th className="py-2.5 px-4 text-right">To‘langan</th>
                    <th className="py-2.5 pl-4 text-right">Holati</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100 text-sm">
                  {filteredSales.slice(0, 5).map((sale) => (
                    <tr key={sale.id} className="hover:bg-slate-50/70">
                      <td className="py-3 pr-4 font-mono text-xs text-slate-500 tabular-nums whitespace-nowrap">
                        {formatDateUZ(sale.createdAt)}
                      </td>
                      <td className="py-3 px-4 font-medium text-slate-900">
                        {sale.customerName}
                      </td>
                      <td className="py-3 px-4 text-xs text-slate-600 max-w-xs truncate">
                        {sale.items.map((i) => `${i.productName} ×${i.quantity}`).join(', ')}
                      </td>
                      <td className="py-3 px-4 text-right font-mono font-semibold text-slate-900 tabular-nums whitespace-nowrap">
                        {formatUZS(sale.totalAmount)}
                      </td>
                      <td className="py-3 px-4 text-right font-mono text-slate-700 tabular-nums whitespace-nowrap">
                        {formatUZS(sale.paidAmount)}
                      </td>
                      <td className="py-3 pl-4 text-right">
                        <StatusText
                          tone={
                            sale.paymentStatus === 'To‘langan'
                              ? 'positive'
                              : sale.paymentStatus === 'Qisman'
                              ? 'warning'
                              : 'info'
                          }
                          label={sale.paymentStatus}
                        />
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
            {/* Mobile Cards */}
            <div className="md:hidden space-y-2.5">
              {filteredSales.slice(0, 5).map((sale) => (
                <div
                  key={sale.id}
                  onClick={() => {
                    if (sale.debtAmount > 0) {
                      const d = dataset.debts.find((item) => item.saleId === sale.id);
                      if (d) {
                        setSelectedDebtId(d.id);
                        setActivePage('debts');
                      }
                    }
                  }}
                  className="p-3.5 rounded-xl border border-slate-200 bg-slate-50/40 space-y-1.5"
                >
                  <div className="flex items-center justify-between gap-2">
                    <span className="text-sm font-semibold text-slate-900">{sale.customerName}</span>
                    <StatusText
                      tone={
                        sale.paymentStatus === 'To‘langan'
                          ? 'positive'
                          : sale.paymentStatus === 'Qisman'
                          ? 'warning'
                          : 'info'
                      }
                      label={sale.paymentStatus}
                    />
                  </div>
                  <div className="text-xs text-slate-500">
                    {sale.items.map((i) => `${i.productName} ×${i.quantity}`).join(', ')}
                  </div>
                  <div className="flex items-center justify-between text-xs pt-1">
                    <span className="text-slate-500 font-mono">{formatDateUZ(sale.createdAt)}</span>
                    <span className="font-mono font-bold text-slate-900 tabular-nums">
                      {formatUZS(sale.totalAmount)}
                    </span>
                  </div>
                </div>
              ))}
            </div>
          </>
        )}
      </Card>
    </div>
  );
}

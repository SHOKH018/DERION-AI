import React, { useMemo, useState } from 'react';
import { Plus, ShoppingBag, Trash2 } from 'lucide-react';
import { useApp } from '../context/AppContext.tsx';
import { calculateSaleTotals, formatDateUZ, formatUZS } from '../lib/accounting.ts';
import type { PaymentMethod } from '../types/domain.ts';
import {
  Button,
  Card,
  EmptyState,
  FieldLabel,
  Input,
  Select,
  StatusText,
} from '../components/ui/Primitives.tsx';

export function SalesPage() {
  const { dataset, selectedBranchId, createSale, can, setActivePage } = useApp();

  const [customerId, setCustomerId] = useState(dataset.customers[0]?.id || '');
  const [branchId, setBranchId] = useState(dataset.branches[0]?.id || 'br-main');
  const [selectedProductId, setSelectedProductId] = useState(dataset.products[0]?.id || '');
  const [cart, setCart] = useState<
    Array<{ productId: string; productName: string; quantity: number; unitPrice: number; purchasePrice: number }>
  >([]);
  const [discountAmount, setDiscountAmount] = useState('0');
  const [paidAmount, setPaidAmount] = useState('');
  const [paymentMethod, setPaymentMethod] = useState<PaymentMethod>('Naqd');
  const [dueDate, setDueDate] = useState('2026-12-25');
  const [saleErr, setSaleErr] = useState<string | null>(null);
  const [submitting, setSubmitting] = useState(false);

  const availableProducts = useMemo(
    () => dataset.products.filter((p) => p.quantity > 0),
    [dataset.products]
  );

  const addProductToCart = () => {
    const prodId = selectedProductId || availableProducts[0]?.id;
    const prod = availableProducts.find((p) => p.id === prodId);
    if (!prod) return;
    setSaleErr(null);
    setCart((prev) => {
      const existing = prev.find((i) => i.productId === prod.id);
      if (existing) {
        if (existing.quantity + 1 > prod.quantity) {
          setSaleErr(`Omborda "${prod.name}" dan jami ${prod.quantity} dona mavjud.`);
          return prev;
        }
        return prev.map((i) =>
          i.productId === prod.id ? { ...i, quantity: i.quantity + 1 } : i
        );
      }
      return [
        ...prev,
        {
          productId: prod.id,
          productName: prod.name,
          quantity: 1,
          unitPrice: prod.sellingPrice,
          purchasePrice: prod.purchasePrice,
        },
      ];
    });
  };

  const liveCalc = useMemo(() => {
    if (!cart.length) return null;
    try {
      const subtotal = cart.reduce((s, i) => s + i.quantity * i.unitPrice, 0);
      const disc = Math.max(0, Number(discountAmount || 0));
      const total = Math.max(0, subtotal - disc);
      const paid = paidAmount === '' ? total : Math.max(0, Number(paidAmount));
      return calculateSaleTotals({
        items: cart,
        discountAmount: disc,
        paidAmount: Math.min(paid, total),
      });
    } catch {
      return null;
    }
  }, [cart, discountAmount, paidAmount]);

  const handleSubmitSale = async (e: React.FormEvent) => {
    e.preventDefault();
    if (submitting) return; // Duplicate submission guard
    setSaleErr(null);

    const custId = customerId || dataset.customers[0]?.id;
    if (!custId) {
      setSaleErr('Avval Mijozlar bo‘limidan mijoz qo‘shing.');
      return;
    }
    if (!cart.length) {
      setSaleErr('Kamida bitta mahsulot qo‘shing.');
      return;
    }
    const subtotal = cart.reduce((s, i) => s + i.quantity * i.unitPrice, 0);
    const disc = Number(discountAmount || 0);
    const total = subtotal - disc;
    const paid = paidAmount === '' ? total : Number(paidAmount);

    if (disc < 0 || disc > subtotal) {
      setSaleErr('Chegirma summasi noto‘g‘ri.');
      return;
    }
    if (paid < 0 || paid > total) {
      setSaleErr('To‘langan summa jami summadan oshmasligi kerak.');
      return;
    }

    setSubmitting(true);
    try {
      await createSale({
        customerId: custId,
        branchId: branchId || dataset.branches[0]?.id || 'br-main',
        items: cart.map((c) => ({
          productId: c.productId,
          quantity: c.quantity,
          unitPrice: c.unitPrice,
        })),
        discountAmount: disc,
        paidAmount: paid,
        paymentMethod,
        dueDate: total - paid > 0 ? new Date(dueDate).toISOString() : undefined,
        idempotencyKey: `sale-${Date.now()}-${Math.random().toString(36).slice(2, 6)}`,
      });
      setCart([]);
      setDiscountAmount('0');
      setPaidAmount('');
    } catch (err) {
      setSaleErr(err instanceof Error ? err.message : 'Savdoni saqlashda xatolik.');
    } finally {
      setSubmitting(false);
    }
  };

  const filteredSales = useMemo(
    () =>
      dataset.sales.filter(
        (s) => selectedBranchId === 'all' || s.branchId === selectedBranchId
      ),
    [dataset.sales, selectedBranchId]
  );

  return (
    <div className="space-y-6">
      <div>
        <h2 className="font-display text-xl font-bold text-slate-900">Savdo va buyurtmalar</h2>
        <p className="text-xs sm:text-sm text-slate-500 mt-0.5">
          To‘liq to‘langan, qisman to‘langan va nasiya savdolarni rasmiylashtirish
        </p>
      </div>

      {can('create_sale') && (
        <Card className="p-5">
          <h3 className="text-sm font-bold text-slate-900 mb-4">Yangi savdo rasmiylashtirish</h3>
          <form onSubmit={handleSubmitSale} className="space-y-4">
            {saleErr && (
              <div className="p-3 rounded-lg bg-red-50 border border-red-200 text-xs text-red-700">
                {saleErr}
              </div>
            )}

            <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
              <div>
                <FieldLabel htmlFor="sale-customer" required>
                  Mijoz
                </FieldLabel>
                <Select
                  id="sale-customer"
                  value={customerId || dataset.customers[0]?.id || ''}
                  onChange={(e) => setCustomerId(e.target.value)}
                >
                  {dataset.customers.length === 0 && (
                    <option value="">Mijozlar mavjud emas</option>
                  )}
                  {dataset.customers.map((c) => (
                    <option key={c.id} value={c.id}>
                      {c.fullName} ({c.phone})
                    </option>
                  ))}
                </Select>
              </div>
              <div>
                <FieldLabel htmlFor="sale-branch" required>
                  Filial
                </FieldLabel>
                <Select
                  id="sale-branch"
                  value={branchId}
                  onChange={(e) => setBranchId(e.target.value)}
                >
                  {dataset.branches.map((b) => (
                    <option key={b.id} value={b.id}>
                      {b.name}
                    </option>
                  ))}
                </Select>
              </div>
              <div>
                <FieldLabel htmlFor="sale-product">Mahsulot qo‘shish</FieldLabel>
                <div className="flex gap-2">
                  <div className="flex-1">
                    <Select
                      id="sale-product"
                      value={selectedProductId || availableProducts[0]?.id || ''}
                      onChange={(e) => setSelectedProductId(e.target.value)}
                    >
                      {availableProducts.length === 0 && (
                        <option value="">Omborda tovar yo‘q</option>
                      )}
                      {availableProducts.map((p) => (
                        <option key={p.id} value={p.id}>
                          {p.name} ({p.quantity} dona) — {formatUZS(p.sellingPrice)}
                        </option>
                      ))}
                    </Select>
                  </div>
                  <Button
                    type="button"
                    variant="secondary"
                    onClick={addProductToCart}
                    disabled={availableProducts.length === 0}
                  >
                    <Plus className="w-4 h-4" />
                    Qo‘shish
                  </Button>
                </div>
              </div>
            </div>

            {cart.length > 0 && (
              <div className="border border-slate-200 rounded-xl overflow-hidden">
                <div className="divide-y divide-slate-100">
                  {cart.map((item) => (
                    <div
                      key={item.productId}
                      className="p-3 flex flex-wrap items-center justify-between gap-3 bg-slate-50/40"
                    >
                      <div className="min-w-0 flex-1">
                        <div className="text-sm font-semibold text-slate-900">
                          {item.productName}
                        </div>
                        <div className="text-xs text-slate-500 font-mono">
                          {formatUZS(item.unitPrice)} / dona
                        </div>
                      </div>
                      <div className="flex items-center gap-2">
                        <input
                          type="number"
                          min="1"
                          aria-label={`${item.productName} soni`}
                          value={item.quantity}
                          onChange={(e) => {
                            const val = Math.max(1, Number(e.target.value || 1));
                            setCart((prev) =>
                              prev.map((c) =>
                                c.productId === item.productId ? { ...c, quantity: val } : c
                              )
                            );
                          }}
                          className="w-20 rounded-lg border border-slate-200 bg-white px-2.5 py-1.5 text-xs font-mono text-center"
                        />
                        <span className="font-mono text-sm font-bold text-slate-900 tabular-nums min-w-[110px] text-right">
                          {formatUZS(item.quantity * item.unitPrice)}
                        </span>
                        <button
                          type="button"
                          onClick={() =>
                            setCart((prev) => prev.filter((c) => c.productId !== item.productId))
                          }
                          aria-label={`${item.productName} ni olib tashlash`}
                          className="p-1.5 text-slate-400 hover:text-red-600 cursor-pointer"
                        >
                          <Trash2 className="w-4 h-4" />
                        </button>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            )}

            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3">
              <div>
                <FieldLabel htmlFor="sale-discount">Chegirma (so‘m)</FieldLabel>
                <Input
                  id="sale-discount"
                  type="number"
                  min="0"
                  value={discountAmount}
                  onChange={(e) => setDiscountAmount(e.target.value)}
                />
              </div>
              <div>
                <FieldLabel htmlFor="sale-paid">
                  To‘langan summa (bo‘sh = to‘liq to‘lov)
                </FieldLabel>
                <Input
                  id="sale-paid"
                  type="number"
                  min="0"
                  value={paidAmount}
                  onChange={(e) => setPaidAmount(e.target.value)}
                  placeholder={liveCalc ? String(liveCalc.totalAmount) : '0'}
                />
              </div>
              <div>
                <FieldLabel htmlFor="sale-method">To‘lov usuli</FieldLabel>
                <Select
                  id="sale-method"
                  value={paymentMethod}
                  onChange={(e) => setPaymentMethod(e.target.value as PaymentMethod)}
                >
                  <option value="Naqd">Naqd</option>
                  <option value="Karta">Karta</option>
                  <option value="O‘tkazma">O‘tkazma</option>
                </Select>
              </div>
              <div>
                <FieldLabel htmlFor="sale-due">Nasiya muddati (agar qarz bo‘lsa)</FieldLabel>
                <Input
                  id="sale-due"
                  type="date"
                  value={dueDate}
                  onChange={(e) => setDueDate(e.target.value)}
                />
              </div>
            </div>

            {liveCalc && (
              <div className="p-4 rounded-xl bg-slate-50 border border-slate-200 flex flex-wrap items-center justify-between gap-4 text-xs">
                <div className="space-x-4">
                  <span>
                    Jami: <strong className="font-mono">{formatUZS(liveCalc.totalAmount)}</strong>
                  </span>
                  <span>
                    To‘lanadi:{' '}
                    <strong className="font-mono text-emerald-700">
                      {formatUZS(liveCalc.paidAmount)}
                    </strong>
                  </span>
                  <span>
                    Nasiya qarz:{' '}
                    <strong className="font-mono text-red-600">
                      {formatUZS(liveCalc.debtAmount)}
                    </strong>
                  </span>
                </div>
                <StatusText
                  tone={
                    liveCalc.paymentStatus === 'To‘langan'
                      ? 'positive'
                      : liveCalc.paymentStatus === 'Qisman'
                      ? 'warning'
                      : 'info'
                  }
                  label={liveCalc.paymentStatus}
                />
              </div>
            )}

            <div className="flex justify-end">
              <Button type="submit" loading={submitting} disabled={cart.length === 0}>
                Savdoni tasdiqlash
              </Button>
            </div>
          </form>
        </Card>
      )}

      <Card className="p-5 space-y-4">
        <h3 className="text-sm font-bold text-slate-900">Savdolar tarixi</h3>
        {filteredSales.length === 0 ? (
          <EmptyState
            icon={<ShoppingBag className="w-5 h-5" />}
            title="Hali savdolar kiritilmagan"
            description="Yuqoridagi shakl orqali birinchi savdoni rasmiylashtiring. Ombordan tovarlar avtomatik kamayadi."
            actionLabel={dataset.products.length === 0 ? 'Omborga mahsulot qo‘shish' : undefined}
            onAction={dataset.products.length === 0 ? () => setActivePage('inventory') : undefined}
          />
        ) : (
          <>
            <div className="hidden md:block overflow-x-auto">
              <table className="w-full text-left border-collapse">
                <thead>
                  <tr className="border-b border-slate-200 text-xs font-semibold text-slate-500">
                    <th className="py-2.5 pr-4">Sana</th>
                    <th className="py-2.5 px-3">Mijoz</th>
                    <th className="py-2.5 px-3">Mahsulotlar</th>
                    <th className="py-2.5 px-3 text-right">Jami</th>
                    <th className="py-2.5 px-3 text-right">To‘langan</th>
                    <th className="py-2.5 px-3 text-right">Nasiya</th>
                    <th className="py-2.5 pl-3 text-right">Holati</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100 text-sm">
                  {filteredSales.map((s) => (
                    <tr key={s.id} className="hover:bg-slate-50/70">
                      <td className="py-3 pr-4 font-mono text-xs text-slate-500 whitespace-nowrap">
                        {formatDateUZ(s.createdAt, true)}
                      </td>
                      <td className="py-3 px-3 font-medium text-slate-900">{s.customerName}</td>
                      <td className="py-3 px-3 text-xs text-slate-600">
                        {s.items.map((i) => `${i.productName} ×${i.quantity}`).join(', ')}
                      </td>
                      <td className="py-3 px-3 text-right font-mono font-bold tabular-nums whitespace-nowrap">
                        {formatUZS(s.totalAmount)}
                      </td>
                      <td className="py-3 px-3 text-right font-mono text-emerald-700 tabular-nums whitespace-nowrap">
                        {formatUZS(s.paidAmount)}
                      </td>
                      <td className="py-3 px-3 text-right font-mono text-red-600 tabular-nums whitespace-nowrap">
                        {formatUZS(s.debtAmount)}
                      </td>
                      <td className="py-3 pl-3 text-right">
                        <StatusText
                          tone={
                            s.paymentStatus === 'To‘langan'
                              ? 'positive'
                              : s.paymentStatus === 'Qisman'
                              ? 'warning'
                              : 'info'
                          }
                          label={s.paymentStatus}
                        />
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>

            <div className="md:hidden space-y-2.5">
              {filteredSales.map((s) => (
                <div key={s.id} className="p-3.5 rounded-xl border border-slate-200 space-y-1.5">
                  <div className="flex justify-between items-center">
                    <span className="text-sm font-bold text-slate-900">{s.customerName}</span>
                    <StatusText
                      tone={
                        s.paymentStatus === 'To‘langan'
                          ? 'positive'
                          : s.paymentStatus === 'Qisman'
                          ? 'warning'
                          : 'info'
                      }
                      label={s.paymentStatus}
                    />
                  </div>
                  <div className="text-xs text-slate-600">
                    {s.items.map((i) => `${i.productName} ×${i.quantity}`).join(', ')}
                  </div>
                  <div className="flex justify-between text-xs pt-1">
                    <span className="text-slate-500 font-mono">{formatDateUZ(s.createdAt)}</span>
                    <span className="font-mono font-bold text-slate-900 tabular-nums">
                      {formatUZS(s.totalAmount)}
                    </span>
                  </div>
                </div>
              ))}
            </div>
          </>
        )}
      </Card>
    </div>
  );
}

import React, { useMemo, useState } from 'react';
import { Download, FileSpreadsheet, Printer } from 'lucide-react';
import { useApp } from '../context/AppContext.tsx';
import { computeFinancialSummary, formatDateUZ, formatUZS } from '../lib/accounting.ts';
import type { DateRangePreset } from '../types/domain.ts';
import { Button, Card, EmptyState } from '../components/ui/Primitives.tsx';

type ReportKind =
  | 'daily'
  | 'weekly'
  | 'monthly'
  | 'yearly'
  | 'debts'
  | 'sales'
  | 'expenses'
  | 'profit';

const REPORT_LABELS: Record<ReportKind, string> = {
  daily: 'Kunlik hisobot',
  weekly: 'Haftalik hisobot',
  monthly: 'Oylik hisobot',
  yearly: 'Yillik hisobot',
  debts: 'Qarzlar hisoboti',
  sales: 'Savdolar hisoboti',
  expenses: 'Xarajatlar hisoboti',
  profit: 'Sof foyda hisoboti',
};

export function ReportsPage() {
  const { dataset, selectedBranchId, can, pushToast } = useApp();
  const [activeReport, setActiveReport] = useState<ReportKind>('monthly');

  const presetForReport = (kind: ReportKind): DateRangePreset => {
    if (kind === 'daily') return 'today';
    if (kind === 'weekly') return '7d';
    if (kind === 'monthly') return '30d';
    return 'all';
  };

  const reportSummary = useMemo(
    () =>
      computeFinancialSummary({
        sales: dataset.sales,
        debts: dataset.debts,
        transactions: dataset.transactions,
        products: dataset.products,
        branchId: selectedBranchId,
        dateRange: presetForReport(activeReport),
      }),
    [dataset, selectedBranchId, activeReport]
  );

  const exportCsv = () => {
    const rows = [
      ['Hisobot turi', REPORT_LABELS[activeReport]],
      ['Sana', formatDateUZ(new Date().toISOString(), true)],
      ['Jami savdo (UZS)', String(reportSummary.totalSalesRevenue)],
      ['Tannarx COGS (UZS)', String(reportSummary.totalCOGS)],
      ['Operatsion xarajatlar (UZS)', String(reportSummary.operatingExpenses)],
      ['Sof foyda (UZS)', String(reportSummary.netProfit)],
      ['Jami pul tushumi (UZS)', String(reportSummary.totalCashInflow)],
      ['Undirilgan qarz (UZS)', String(reportSummary.debtCollections)],
      ['Qolgan qarz (UZS)', String(reportSummary.outstandingDebt)],
      ['Muddati o‘tgan qarz (UZS)', String(reportSummary.overdueDebt)],
    ];
    const csv = rows.map((r) => r.map((c) => `"${c.replace(/"/g, '""')}"`).join(',')).join('\n');
    const blob = new Blob([csv], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `nasiyaai-${activeReport}.csv`;
    a.click();
    URL.revokeObjectURL(url);
    pushToast('success', `${REPORT_LABELS[activeReport]} CSV formatda yuklandi.`);
  };

  const handlePrintPdf = () => {
    window.print();
  };

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
        <div>
          <h2 className="font-display text-xl font-bold text-slate-900">Moliyaviy hisobotlar</h2>
          <p className="text-xs sm:text-sm text-slate-500 mt-0.5">
            Kunlik, haftalik, oylik, yillik va yo‘nalishlar kesimidagi hisobotlar
          </p>
        </div>
        {can('export_reports') && (
          <div className="flex items-center gap-2">
            <Button size="sm" variant="secondary" onClick={handlePrintPdf}>
              <Printer className="w-4 h-4" />
              PDF / Chop etish
            </Button>
            <Button size="sm" onClick={exportCsv}>
              <Download className="w-4 h-4" />
              CSV yuklab olish
            </Button>
          </div>
        )}
      </div>

      <div className="flex flex-wrap gap-1.5">
        {(Object.keys(REPORT_LABELS) as ReportKind[]).map((key) => (
          <button
            key={key}
            type="button"
            onClick={() => setActiveReport(key)}
            className={`px-3 py-2 text-xs font-medium rounded-lg border cursor-pointer transition-colors ${
              activeReport === key
                ? 'bg-[#2563EB] text-white border-[#2563EB]'
                : 'bg-white text-slate-700 border-slate-200 hover:bg-slate-50'
            }`}
          >
            {REPORT_LABELS[key]}
          </button>
        ))}
      </div>

      <Card className="p-6 space-y-5">
        <div className="flex items-center justify-between border-b border-slate-100 pb-4">
          <div>
            <h3 className="font-display text-base font-bold text-slate-900">
              {REPORT_LABELS[activeReport]}
            </h3>
            <p className="text-xs text-slate-500">
              {dataset.settings.shopName} · Asia/Tashkent · Valyuta: UZS
            </p>
          </div>
          <FileSpreadsheet className="w-5 h-5 text-slate-400" />
        </div>

        {dataset.sales.length === 0 && dataset.transactions.length === 0 ? (
          <EmptyState
            icon={<FileSpreadsheet className="w-5 h-5" />}
            title="Hisobot uchun ma’lumotlar mavjud emas"
            description="Savdo, qarz yoki xarajat yozuvlari kiritilgach hisobot ko‘rsatkichlari shakllanadi."
          />
        ) : (
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
            <div className="p-4 rounded-xl bg-slate-50 border border-slate-200/80">
              <div className="text-xs text-slate-500">Savdo daromadi</div>
              <div className="font-display text-lg font-bold text-slate-900 tabular-nums mt-1">
                {formatUZS(reportSummary.totalSalesRevenue)}
              </div>
            </div>
            <div className="p-4 rounded-xl bg-slate-50 border border-slate-200/80">
              <div className="text-xs text-slate-500">Sof foyda</div>
              <div className="font-display text-lg font-bold text-emerald-700 tabular-nums mt-1">
                {formatUZS(reportSummary.netProfit)}
              </div>
            </div>
            <div className="p-4 rounded-xl bg-slate-50 border border-slate-200/80">
              <div className="text-xs text-slate-500">Operatsion xarajatlar</div>
              <div className="font-display text-lg font-bold text-red-600 tabular-nums mt-1">
                {formatUZS(reportSummary.operatingExpenses)}
              </div>
            </div>
            <div className="p-4 rounded-xl bg-slate-50 border border-slate-200/80">
              <div className="text-xs text-slate-500">Qolgan qarz</div>
              <div className="font-display text-lg font-bold text-amber-700 tabular-nums mt-1">
                {formatUZS(reportSummary.outstandingDebt)}
              </div>
            </div>
          </div>
        )}
      </Card>
    </div>
  );
}

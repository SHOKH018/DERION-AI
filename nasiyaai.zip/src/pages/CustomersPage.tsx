import React, { useEffect, useMemo, useState } from 'react';
import { ArrowLeft, Download, Edit2, Plus, Search, Users } from 'lucide-react';
import { useApp } from '../context/AppContext.tsx';
import { formatDateUZ, formatUZS } from '../lib/accounting.ts';
import { setTelegramBackButton } from '../lib/telegram.ts';
import { customerSchema } from '../lib/validation.ts';
import type { Customer } from '../types/domain.ts';
import {
  Button,
  Card,
  EmptyState,
  FieldLabel,
  Input,
  Modal,
  Select,
  StatusText,
} from '../components/ui/Primitives.tsx';

export function CustomersPage() {
  const {
    dataset,
    selectedBranchId,
    selectedCustomerId,
    setSelectedCustomerId,
    saveCustomer,
    can,
  } = useApp();

  const [search, setSearch] = useState('');
  const [debtFilter, setDebtFilter] = useState<'all' | 'has_debt' | 'clean'>('all');
  const [modalOpen, setModalOpen] = useState(false);
  const [editingCustomer, setEditingCustomer] = useState<Customer | null>(null);

  const [fullName, setFullName] = useState('');
  const [phone, setPhone] = useState('+998 ');
  const [address, setAddress] = useState('');
  const [notes, setNotes] = useState('');
  const [branchId, setBranchId] = useState(dataset.branches[0]?.id || 'br-main');
  const [status, setStatus] = useState<Customer['status']>('Faol');
  const [formErr, setFormErr] = useState<string | null>(null);
  const [saving, setSaving] = useState(false);

  const customerSummaries = useMemo(() => {
    return dataset.customers
      .filter((c) => selectedBranchId === 'all' || c.branchId === selectedBranchId)
      .map((c) => {
        const custSales = dataset.sales.filter((s) => s.customerId === c.id);
        const custDebts = dataset.debts.filter((d) => d.customerId === c.id);
        const totalPurchases = custSales.reduce((acc, s) => acc + s.totalAmount, 0);
        const outstandingDebt = custDebts.reduce((acc, d) => acc + d.remainingAmount, 0);
        const allPayments = custDebts
          .flatMap((d) => d.payments)
          .sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());
        return {
          ...c,
          totalPurchases,
          outstandingDebt,
          lastPaymentDate: allPayments[0]?.createdAt,
          salesCount: custSales.length,
          debts: custDebts,
          sales: custSales,
          payments: allPayments,
        };
      });
  }, [dataset.customers, dataset.sales, dataset.debts, selectedBranchId]);

  const filteredCustomers = useMemo(() => {
    return customerSummaries.filter((c) => {
      if (debtFilter === 'has_debt' && c.outstandingDebt <= 0) return false;
      if (debtFilter === 'clean' && c.outstandingDebt > 0) return false;
      if (
        search.trim() &&
        !`${c.fullName} ${c.phone}`.toLowerCase().includes(search.trim().toLowerCase())
      ) {
        return false;
      }
      return true;
    });
  }, [customerSummaries, debtFilter, search]);

  const activeProfile = useMemo(
    () => customerSummaries.find((c) => c.id === selectedCustomerId) || null,
    [customerSummaries, selectedCustomerId]
  );

  useEffect(() => {
    if (!activeProfile) return;
    return setTelegramBackButton(true, () => setSelectedCustomerId(null));
  }, [activeProfile, setSelectedCustomerId]);

  const openCreateModal = () => {
    setEditingCustomer(null);
    setFullName('');
    setPhone('+998 ');
    setAddress('');
    setNotes('');
    setBranchId(dataset.branches[0]?.id || 'br-main');
    setStatus('Faol');
    setFormErr(null);
    setModalOpen(true);
  };

  const openEditModal = (c: Customer) => {
    setEditingCustomer(c);
    setFullName(c.fullName);
    setPhone(c.phone);
    setAddress(c.address || '');
    setNotes(c.notes || '');
    setBranchId(c.branchId);
    setStatus(c.status);
    setFormErr(null);
    setModalOpen(true);
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setFormErr(null);
    const parsed = customerSchema.safeParse({
      fullName,
      phone,
      address,
      notes,
      branchId: branchId || dataset.branches[0]?.id || 'br-main',
      status,
    });
    if (!parsed.success) {
      setFormErr(parsed.error.issues[0]?.message || 'Ma’lumotlarni tekshiring.');
      return;
    }
    setSaving(true);
    try {
      await saveCustomer(parsed.data, editingCustomer?.id);
      setModalOpen(false);
    } catch (err) {
      setFormErr(err instanceof Error ? err.message : 'Saqlashda xatolik.');
    } finally {
      setSaving(false);
    }
  };

  const handleExportCsv = () => {
    const rows = [
      ['Ism', 'Telefon', 'Jami xarid', 'Qolgan qarz', 'Holati'],
      ...filteredCustomers.map((c) => [
        c.fullName,
        c.phone,
        String(c.totalPurchases),
        String(c.outstandingDebt),
        c.status,
      ]),
    ];
    const csv = rows.map((r) => r.map((x) => `"${x.replace(/"/g, '""')}"`).join(',')).join('\n');
    const blob = new Blob([csv], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = 'mijozlar-nasiyaai.csv';
    a.click();
    URL.revokeObjectURL(url);
  };

  if (activeProfile) {
    return (
      <div className="space-y-6">
        <div className="flex flex-wrap items-center justify-between gap-3">
          <div className="flex items-center gap-3">
            <Button variant="secondary" size="sm" onClick={() => setSelectedCustomerId(null)}>
              <ArrowLeft className="w-4 h-4" />
              Mijozlarga qaytish
            </Button>
            <div>
              <h2 className="font-display text-lg font-bold text-slate-900">
                {activeProfile.fullName}
              </h2>
              <p className="text-xs text-slate-500">
                {activeProfile.phone} · {activeProfile.address || 'Manzil kiritilmagan'}
              </p>
            </div>
          </div>
          {can('manage_customers') && (
            <Button size="sm" variant="secondary" onClick={() => openEditModal(activeProfile)}>
              <Edit2 className="w-4 h-4" />
              Tahrirlash
            </Button>
          )}
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
          <Card className="p-4 space-y-1">
            <div className="text-xs text-slate-500">Jami xaridlar</div>
            <div className="font-display text-lg font-bold text-slate-900 tabular-nums">
              {formatUZS(activeProfile.totalPurchases)}
            </div>
            <div className="text-[11px] text-slate-500">{activeProfile.salesCount} ta savdo</div>
          </Card>
          <Card className="p-4 space-y-1">
            <div className="text-xs text-slate-500">Qolgan qarz</div>
            <div
              className={`font-display text-lg font-bold tabular-nums ${
                activeProfile.outstandingDebt > 0 ? 'text-red-600' : 'text-emerald-700'
              }`}
            >
              {formatUZS(activeProfile.outstandingDebt)}
            </div>
            <div className="text-[11px] text-slate-500">
              {activeProfile.debts.length} ta shartnoma
            </div>
          </Card>
          <Card className="p-4 space-y-1">
            <div className="text-xs text-slate-500">Oxirgi to‘lov</div>
            <div className="font-mono text-sm font-bold text-slate-900">
              {activeProfile.lastPaymentDate ? formatDateUZ(activeProfile.lastPaymentDate) : '—'}
            </div>
            <StatusText
              tone={
                activeProfile.status === 'Ishonchli'
                  ? 'positive'
                  : activeProfile.status === 'Kuzatuvda'
                  ? 'warning'
                  : 'info'
              }
              label={activeProfile.status}
            />
          </Card>
        </div>

        {activeProfile.notes && (
          <Card className="p-4 text-xs text-slate-700 bg-slate-50/70">
            <span className="font-semibold text-slate-900">Mijoz bo‘yicha izoh: </span>
            {activeProfile.notes}
          </Card>
        )}

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
          <Card className="p-5 space-y-3">
            <h3 className="text-sm font-bold text-slate-900">Xaridlar tarixi</h3>
            {activeProfile.sales.length === 0 ? (
              <p className="text-xs text-slate-500">Xaridlar tarixi bo‘sh.</p>
            ) : (
              <div className="divide-y divide-slate-100 text-xs">
                {activeProfile.sales.map((s) => (
                  <div key={s.id} className="py-2.5 flex justify-between gap-2">
                    <div>
                      <div className="font-semibold text-slate-900">
                        {s.items.map((i) => `${i.productName} ×${i.quantity}`).join(', ')}
                      </div>
                      <div className="text-slate-500">{formatDateUZ(s.createdAt)}</div>
                    </div>
                    <div className="text-right font-mono font-bold text-slate-900 tabular-nums">
                      {formatUZS(s.totalAmount)}
                    </div>
                  </div>
                ))}
              </div>
            )}
          </Card>

          <Card className="p-5 space-y-3">
            <h3 className="text-sm font-bold text-slate-900">Qarz va to‘lovlar tarixi</h3>
            {activeProfile.payments.length === 0 ? (
              <p className="text-xs text-slate-500">Qarz to‘lovlari tarixi bo‘sh.</p>
            ) : (
              <div className="divide-y divide-slate-100 text-xs">
                {activeProfile.payments.map((p) => (
                  <div key={p.id} className="py-2.5 flex justify-between gap-2">
                    <div>
                      <div className="font-semibold text-emerald-700">+{formatUZS(p.amount)}</div>
                      <div className="text-slate-500">
                        {formatDateUZ(p.createdAt, true)} · {p.paymentMethod}
                      </div>
                    </div>
                    <div className="text-slate-500">{p.receivedBy}</div>
                  </div>
                ))}
              </div>
            )}
          </Card>
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
        <div>
          <h2 className="font-display text-xl font-bold text-slate-900">Mijozlar CRM</h2>
          <p className="text-xs sm:text-sm text-slate-500 mt-0.5">
            Mijozlar bazasi, xarid tarixi va nasiya intizomi nazorati
          </p>
        </div>
        <div className="flex items-center gap-2">
          {can('export_customers') && (
            <Button variant="secondary" size="sm" onClick={handleExportCsv}>
              <Download className="w-4 h-4" />
              CSV eksport
            </Button>
          )}
          {can('manage_customers') && (
            <Button size="sm" onClick={openCreateModal}>
              <Plus className="w-4 h-4" />
              Mijoz qo‘shish
            </Button>
          )}
        </div>
      </div>

      <Card className="p-5 space-y-4">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-3">
          <div className="relative flex-1 max-w-md">
            <Search className="w-4 h-4 text-slate-400 absolute left-3 top-3" />
            <Input
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              placeholder="Ism yoki telefon raqam bo‘yicha qidirish..."
              className="pl-9"
            />
          </div>
          <div className="flex gap-1 p-1 bg-slate-100 rounded-lg">
            {(
              [
                ['all', 'Barchasi'],
                ['has_debt', 'Qarzdorlar'],
                ['clean', 'Qarzsiz'],
              ] as const
            ).map(([val, label]) => (
              <button
                key={val}
                type="button"
                onClick={() => setDebtFilter(val)}
                className={`px-3 py-1.5 text-xs font-medium rounded-md cursor-pointer ${
                  debtFilter === val ? 'bg-white text-slate-900 shadow-sm' : 'text-slate-600'
                }`}
              >
                {label}
              </button>
            ))}
          </div>
        </div>

        {filteredCustomers.length === 0 ? (
          <EmptyState
            icon={<Users className="w-5 h-5" />}
            title="Mijozlar topilmadi"
            description="Yangi mijoz qo‘shing yoki qidiruv parametrini o‘zgartiring."
            actionLabel={can('manage_customers') ? 'Mijoz qo‘shish' : undefined}
            onAction={can('manage_customers') ? openCreateModal : undefined}
          />
        ) : (
          <>
            <div className="hidden md:block overflow-x-auto">
              <table className="w-full text-left border-collapse">
                <thead>
                  <tr className="border-b border-slate-200 text-xs font-semibold text-slate-500">
                    <th className="py-2.5 pr-4">Mijoz</th>
                    <th className="py-2.5 px-4">Telefon</th>
                    <th className="py-2.5 px-4 text-right">Jami xarid</th>
                    <th className="py-2.5 px-4 text-right">Qolgan qarz</th>
                    <th className="py-2.5 px-4">Oxirgi to‘lov</th>
                    <th className="py-2.5 px-4">Holati</th>
                    <th className="py-2.5 pl-4 text-right">Amallar</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100 text-sm">
                  {filteredCustomers.map((c) => (
                    <tr key={c.id} className="hover:bg-slate-50/70">
                      <td className="py-3 pr-4 font-semibold text-slate-900">{c.fullName}</td>
                      <td className="py-3 px-4 font-mono text-xs text-slate-600">{c.phone}</td>
                      <td className="py-3 px-4 text-right font-mono text-xs text-slate-700 tabular-nums">
                        {formatUZS(c.totalPurchases)}
                      </td>
                      <td
                        className={`py-3 px-4 text-right font-mono font-bold tabular-nums ${
                          c.outstandingDebt > 0 ? 'text-red-600' : 'text-emerald-700'
                        }`}
                      >
                        {formatUZS(c.outstandingDebt)}
                      </td>
                      <td className="py-3 px-4 font-mono text-xs text-slate-500">
                        {c.lastPaymentDate ? formatDateUZ(c.lastPaymentDate) : '—'}
                      </td>
                      <td className="py-3 px-4">
                        <StatusText
                          tone={
                            c.status === 'Ishonchli'
                              ? 'positive'
                              : c.status === 'Kuzatuvda'
                              ? 'warning'
                              : 'info'
                          }
                          label={c.status}
                        />
                      </td>
                      <td className="py-3 pl-4 text-right">
                        <Button
                          size="sm"
                          variant="secondary"
                          onClick={() => setSelectedCustomerId(c.id)}
                        >
                          Profil
                        </Button>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>

            <div className="md:hidden space-y-2.5">
              {filteredCustomers.map((c) => (
                <div
                  key={c.id}
                  onClick={() => setSelectedCustomerId(c.id)}
                  className="p-3.5 rounded-xl border border-slate-200 bg-white space-y-1.5 cursor-pointer"
                >
                  <div className="flex items-center justify-between gap-2">
                    <span className="text-sm font-bold text-slate-900">{c.fullName}</span>
                    <StatusText
                      tone={
                        c.status === 'Ishonchli'
                          ? 'positive'
                          : c.status === 'Kuzatuvda'
                          ? 'warning'
                          : 'info'
                      }
                      label={c.status}
                    />
                  </div>
                  <div className="text-xs text-slate-500 font-mono">{c.phone}</div>
                  <div className="flex justify-between text-xs pt-1">
                    <span className="text-slate-500">Qolgan qarz:</span>
                    <span
                      className={`font-mono font-bold tabular-nums ${
                        c.outstandingDebt > 0 ? 'text-red-600' : 'text-emerald-700'
                      }`}
                    >
                      {formatUZS(c.outstandingDebt)}
                    </span>
                  </div>
                </div>
              ))}
            </div>
          </>
        )}
      </Card>

      <Modal
        open={modalOpen}
        onClose={() => setModalOpen(false)}
        title={editingCustomer ? 'Mijozni tahrirlash' : 'Yangi mijoz qo‘shish'}
      >
        <form onSubmit={handleSubmit} className="space-y-3.5">
          {formErr && (
            <div className="p-3 rounded-lg bg-red-50 border border-red-200 text-xs text-red-700">
              {formErr}
            </div>
          )}
          <div>
            <FieldLabel htmlFor="cust-name" required>
              F.I.Sh.
            </FieldLabel>
            <Input
              id="cust-name"
              value={fullName}
              onChange={(e) => setFullName(e.target.value)}
            />
          </div>
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <div>
              <FieldLabel htmlFor="cust-phone" required>
                Telefon raqam
              </FieldLabel>
              <Input
                id="cust-phone"
                value={phone}
                onChange={(e) => setPhone(e.target.value)}
              />
            </div>
            <div>
              <FieldLabel htmlFor="cust-status">Holat</FieldLabel>
              <Select
                id="cust-status"
                value={status}
                onChange={(e) => setStatus(e.target.value as Customer['status'])}
              >
                <option value="Faol">Faol</option>
                <option value="Ishonchli">Ishonchli</option>
                <option value="Kuzatuvda">Kuzatuvda</option>
              </Select>
            </div>
          </div>
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <div>
              <FieldLabel htmlFor="cust-branch">Filial</FieldLabel>
              <Select
                id="cust-branch"
                value={branchId}
                onChange={(e) => setBranchId(e.target.value)}
              >
                {dataset.branches.map((b) => (
                  <option key={b.id} value={b.id}>
                    {b.name}
                  </option>
                ))}
              </Select>
            </div>
            <div>
              <FieldLabel htmlFor="cust-addr">Manzil</FieldLabel>
              <Input
                id="cust-addr"
                value={address}
                onChange={(e) => setAddress(e.target.value)}
              />
            </div>
          </div>
          <div>
            <FieldLabel htmlFor="cust-notes">Izoh</FieldLabel>
            <Input
              id="cust-notes"
              value={notes}
              onChange={(e) => setNotes(e.target.value)}
            />
          </div>
          <div className="flex justify-end gap-2 pt-2">
            <Button variant="secondary" onClick={() => setModalOpen(false)}>
              Bekor qilish
            </Button>
            <Button type="submit" loading={saving}>
              Saqlash
            </Button>
          </div>
        </form>
      </Modal>
    </div>
  );
}

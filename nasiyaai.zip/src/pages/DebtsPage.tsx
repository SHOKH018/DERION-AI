import React, { useEffect, useMemo, useState } from 'react';
import {
  ArrowLeft,
  BellRing,
  CreditCard,
  Download,
  Plus,
  Search,
} from 'lucide-react';
import { useApp } from '../context/AppContext.tsx';
import { formatDateUZ, formatUZS, resolveDebtStatus } from '../lib/accounting.ts';
import { setTelegramBackButton } from '../lib/telegram.ts';
import { debtPaymentSchema } from '../lib/validation.ts';
import type { Debt, DebtStatus, PaymentMethod } from '../types/domain.ts';
import {
  Button,
  Card,
  ConfirmDialog,
  EmptyState,
  FieldLabel,
  Input,
  Modal,
  Select,
  StatusText,
} from '../components/ui/Primitives.tsx';

export function DebtsPage() {
  const {
    dataset,
    summary,
    selectedBranchId,
    selectedDebtId,
    setSelectedDebtId,
    setQuickModal,
    acceptDebtPayment,
    sendDebtReminder,
    can,
  } = useApp();

  const [search, setSearch] = useState('');
  const [statusFilter, setStatusFilter] = useState<'all' | DebtStatus>('all');

  const [payModalDebt, setPayModalDebt] = useState<Debt | null>(null);
  const [payAmount, setPayAmount] = useState('');
  const [payMethod, setPayMethod] = useState<PaymentMethod>('Naqd');
  const [payNote, setPayNote] = useState('');
  const [payError, setPayError] = useState<string | null>(null);
  const [payLoading, setPayLoading] = useState(false);

  const [reminderTarget, setReminderTarget] = useState<Debt | null>(null);
  const [reminderSending, setReminderSending] = useState(false);

  const enrichedDebts = useMemo(() => {
    return dataset.debts
      .filter((d) => selectedBranchId === 'all' || d.branchId === selectedBranchId)
      .map((d) => ({
        ...d,
        computedStatus: resolveDebtStatus(d.remainingAmount, d.paidAmount, d.dueDate),
      }));
  }, [dataset.debts, selectedBranchId]);

  const filteredDebts = useMemo(() => {
    return enrichedDebts.filter((d) => {
      if (statusFilter !== 'all' && d.computedStatus !== statusFilter) return false;
      if (
        search.trim() &&
        !`${d.customerName} ${d.customerPhone} ${d.description}`
          .toLowerCase()
          .includes(search.trim().toLowerCase())
      ) {
        return false;
      }
      return true;
    });
  }, [enrichedDebts, statusFilter, search]);

  const activeDetailDebt = useMemo(
    () => enrichedDebts.find((d) => d.id === selectedDebtId) || null,
    [enrichedDebts, selectedDebtId]
  );

  // Telegram BackButton support when viewing debt details
  useEffect(() => {
    if (!activeDetailDebt) return;
    return setTelegramBackButton(true, () => setSelectedDebtId(null));
  }, [activeDetailDebt, setSelectedDebtId]);

  const upcomingCount = useMemo(() => {
    const now = Date.now();
    const week = now + 7 * 86400_000;
    return enrichedDebts.filter((d) => {
      const due = new Date(d.dueDate).getTime();
      return d.remainingAmount > 0 && due >= now && due <= week;
    }).length;
  }, [enrichedDebts]);

  const branchName = (id: string) =>
    dataset.branches.find((b) => b.id === id)?.name || 'Asosiy filial';

  const statusTone = (status: DebtStatus) => {
    if (status === 'To‘langan') return 'positive';
    if (status === 'Muddati o‘tgan') return 'negative';
    if (status === 'Qisman to‘langan') return 'warning';
    return 'info';
  };

  const handleAcceptPayment = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!payModalDebt || payLoading) return;
    setPayError(null);

    const parsed = debtPaymentSchema.safeParse({
      amount: Number(payAmount),
      paymentMethod: payMethod,
      note: payNote,
    });
    if (!parsed.success) {
      setPayError(parsed.error.issues[0]?.message || 'Summani tekshiring.');
      return;
    }
    if (parsed.data.amount > payModalDebt.remainingAmount) {
      setPayError(
        `To‘lov summasi qolgan qarzdan (${formatUZS(
          payModalDebt.remainingAmount
        )}) oshib ketishi mumkin emas.`
      );
      return;
    }

    setPayLoading(true);
    try {
      await acceptDebtPayment(payModalDebt.id, {
        ...parsed.data,
        idempotencyKey: `debtpay-${payModalDebt.id}-${Date.now()}`,
      });
      setPayAmount('');
      setPayNote('');
      setPayModalDebt(null);
    } catch (err) {
      setPayError(err instanceof Error ? err.message : 'Xatolik yuz berdi.');
    } finally {
      setPayLoading(false);
    }
  };

  const handleConfirmReminder = async () => {
    if (!reminderTarget) return;
    setReminderSending(true);
    try {
      const msg = `Hurmatli ${reminderTarget.customerName}, ${formatUZS(
        reminderTarget.remainingAmount
      )} miqdoridagi nasiya to‘lov muddati ${formatDateUZ(reminderTarget.dueDate)} etib belgilangan.`;
      await sendDebtReminder(reminderTarget.id, msg);
      setReminderTarget(null);
    } finally {
      setReminderSending(false);
    }
  };

  const exportDebtCsv = (debt: Debt) => {
    const rows = [
      ['Mijoz', 'Telefon', 'Asl summa', 'To‘langan', 'Qolgan', 'Muddat', 'Holati'],
      [
        debt.customerName,
        debt.customerPhone,
        String(debt.originalAmount),
        String(debt.paidAmount),
        String(debt.remainingAmount),
        formatDateUZ(debt.dueDate),
        debt.status,
      ],
    ];
    const csv = rows.map((r) => r.map((c) => `"${c.replace(/"/g, '""')}"`).join(',')).join('\n');
    const blob = new Blob([csv], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `qarz-${debt.id}.csv`;
    a.click();
    URL.revokeObjectURL(url);
  };

  // Detail View
  if (activeDetailDebt) {
    return (
      <div className="space-y-6">
        <div className="flex flex-wrap items-center justify-between gap-3">
          <div className="flex items-center gap-3">
            <Button variant="secondary" size="sm" onClick={() => setSelectedDebtId(null)}>
              <ArrowLeft className="w-4 h-4" />
              Qarzlarga qaytish
            </Button>
            <div>
              <h2 className="font-display text-lg font-bold text-slate-900">
                {activeDetailDebt.customerName}
              </h2>
              <p className="text-xs text-slate-500">
                {activeDetailDebt.customerPhone} · {branchName(activeDetailDebt.branchId)}
              </p>
            </div>
          </div>
          <div className="flex flex-wrap items-center gap-2">
            {activeDetailDebt.remainingAmount > 0 && can('accept_payment') && (
              <Button
                size="sm"
                onClick={() => {
                  setPayError(null);
                  setPayAmount(String(activeDetailDebt.remainingAmount));
                  setPayModalDebt(activeDetailDebt);
                }}
              >
                To‘lov qabul qilish
              </Button>
            )}
            {activeDetailDebt.remainingAmount > 0 && can('send_reminder') && (
              <Button
                size="sm"
                variant="secondary"
                onClick={() => setReminderTarget(activeDetailDebt)}
              >
                <BellRing className="w-4 h-4" />
                Eslatma yuborish
              </Button>
            )}
            <Button
              size="sm"
              variant="secondary"
              onClick={() => exportDebtCsv(activeDetailDebt)}
            >
              <Download className="w-4 h-4" />
              Eksport
            </Button>
          </div>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-4 gap-4">
          <Card className="p-4 space-y-1">
            <div className="text-xs text-slate-500">Asl qarz summasi</div>
            <div className="font-display text-lg font-bold text-slate-900 tabular-nums">
              {formatUZS(activeDetailDebt.originalAmount)}
            </div>
          </Card>
          <Card className="p-4 space-y-1">
            <div className="text-xs text-slate-500">To‘langan summa</div>
            <div className="font-display text-lg font-bold text-emerald-700 tabular-nums">
              {formatUZS(activeDetailDebt.paidAmount)}
            </div>
          </Card>
          <Card className="p-4 space-y-1">
            <div className="text-xs text-slate-500">Qolgan qarz</div>
            <div className="font-display text-lg font-bold text-red-600 tabular-nums">
              {formatUZS(activeDetailDebt.remainingAmount)}
            </div>
          </Card>
          <Card className="p-4 space-y-1">
            <div className="text-xs text-slate-500">Qaytarish muddati</div>
            <div className="font-mono text-sm font-bold text-slate-900">
              {formatDateUZ(activeDetailDebt.dueDate)}
            </div>
            <StatusText
              tone={statusTone(activeDetailDebt.computedStatus)}
              label={activeDetailDebt.computedStatus}
            />
          </Card>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
          <Card className="p-5 space-y-3">
            <h3 className="text-sm font-bold text-slate-900">To‘lovlar tarixi va audit izi</h3>
            {activeDetailDebt.payments.length === 0 ? (
              <p className="text-xs text-slate-500">Hali to‘lovlar amalga oshirilmagan.</p>
            ) : (
              <div className="divide-y divide-slate-100">
                {activeDetailDebt.payments.map((p) => (
                  <div key={p.id} className="py-3 flex items-center justify-between gap-3">
                    <div>
                      <div className="text-sm font-semibold text-slate-900">
                        +{formatUZS(p.amount)}
                      </div>
                      <div className="text-xs text-slate-500">
                        {formatDateUZ(p.createdAt, true)} · {p.paymentMethod} · Qabul qildi:{' '}
                        {p.receivedBy}
                      </div>
                      {p.note && <div className="text-xs text-slate-600 mt-0.5">{p.note}</div>}
                    </div>
                    <span className="font-mono text-[11px] text-slate-400">
                      #{p.transactionId}
                    </span>
                  </div>
                ))}
              </div>
            )}
          </Card>

          <Card className="p-5 space-y-4">
            <div>
              <h3 className="text-sm font-bold text-slate-900">Shartnoma tafsiloti</h3>
              <p className="text-xs text-slate-600 mt-1">{activeDetailDebt.description}</p>
              {activeDetailDebt.notes && (
                <p className="text-xs text-slate-500 mt-2 bg-slate-50 p-3 rounded-lg border border-slate-200">
                  Izoh: {activeDetailDebt.notes}
                </p>
              )}
            </div>
            <div className="space-y-2 pt-2 border-t border-slate-100">
              <h4 className="text-xs font-bold text-slate-700">Yuborilgan eslatmalar</h4>
              {activeDetailDebt.reminders.length === 0 ? (
                <p className="text-xs text-slate-500">Hali eslatma yuborilmagan.</p>
              ) : (
                activeDetailDebt.reminders.map((r) => (
                  <div
                    key={r.id}
                    className="p-2.5 rounded-lg bg-slate-50 border border-slate-200 text-xs space-y-1"
                  >
                    <div className="flex justify-between text-slate-500">
                      <span>{r.channel}</span>
                      <span>
                        {formatDateUZ(r.sentAt, true)} · {r.status}
                      </span>
                    </div>
                    <p className="text-slate-700">{r.message}</p>
                  </div>
                ))
              )}
            </div>
          </Card>
        </div>

        {/* Modals rendered below */}
        <Modal
          open={Boolean(payModalDebt)}
          onClose={() => setPayModalDebt(null)}
          title="Qarz to‘lovini qabul qilish"
          subtitle={payModalDebt ? `Mijoz: ${payModalDebt.customerName}` : undefined}
        >
          <form onSubmit={handleAcceptPayment} className="space-y-3.5">
            {payError && (
              <div className="p-3 rounded-lg bg-red-50 border border-red-200 text-xs text-red-700">
                {payError}
              </div>
            )}
            <div className="p-3 rounded-xl bg-slate-50 border border-slate-200 flex justify-between text-xs">
              <span className="text-slate-600">Qolgan qarz:</span>
              <span className="font-mono font-bold text-slate-900 tabular-nums">
                {payModalDebt ? formatUZS(payModalDebt.remainingAmount) : ''}
              </span>
            </div>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <div>
                <FieldLabel htmlFor="detail-pay-amount" required>
                  To‘lov summasi (so‘m)
                </FieldLabel>
                <Input
                  id="detail-pay-amount"
                  type="number"
                  min="1"
                  value={payAmount}
                  onChange={(e) => setPayAmount(e.target.value)}
                />
              </div>
              <div>
                <FieldLabel htmlFor="detail-pay-method">To‘lov usuli</FieldLabel>
                <Select
                  id="detail-pay-method"
                  value={payMethod}
                  onChange={(e) => setPayMethod(e.target.value as PaymentMethod)}
                >
                  <option value="Naqd">Naqd</option>
                  <option value="Karta">Karta</option>
                  <option value="O‘tkazma">O‘tkazma</option>
                </Select>
              </div>
            </div>
            <div>
              <FieldLabel htmlFor="detail-pay-note">Izoh</FieldLabel>
              <Input
                id="detail-pay-note"
                value={payNote}
                onChange={(e) => setPayNote(e.target.value)}
                placeholder="Masalan: 2-bosqich to‘lov"
              />
            </div>
            <div className="flex justify-end gap-2 pt-2">
              <Button variant="secondary" onClick={() => setPayModalDebt(null)}>
                Bekor qilish
              </Button>
              <Button type="submit" loading={payLoading}>
                Tasdiqlash
              </Button>
            </div>
          </form>
        </Modal>

        <ConfirmDialog
          open={Boolean(reminderTarget)}
          onClose={() => setReminderTarget(null)}
          onConfirm={() => void handleConfirmReminder()}
          title="Telegram eslatma yuborilsinmi?"
          description={
            reminderTarget
              ? `${reminderTarget.customerName} (${reminderTarget.customerPhone}) ga ${formatUZS(
                  reminderTarget.remainingAmount
                )} qarz bo‘yicha Telegram bot eslatmasi yuboriladi.`
              : ''
          }
          confirmLabel="Eslatmani yuborish"
          loading={reminderSending}
        />
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
        <div>
          <h2 className="font-display text-xl font-bold text-slate-900">Qarzlar boshqaruvi</h2>
          <p className="text-xs sm:text-sm text-slate-500 mt-0.5">
            Qisman to‘lovlar, muddati o‘tgan qarzlar nazorati va mijoz eslatmalari
          </p>
        </div>
        {can('create_debt') && (
          <Button onClick={() => setQuickModal('debt')}>
            <Plus className="w-4 h-4" />
            Yangi qarz
          </Button>
        )}
      </div>

      {/* Debt KPI Strip */}
      <div className="grid grid-cols-2 lg:grid-cols-5 gap-3">
        <Card className="p-4">
          <div className="text-xs text-slate-500">Qolgan jami qarz</div>
          <div className="font-display text-lg font-bold text-slate-900 tabular-nums mt-1">
            {formatUZS(summary.outstandingDebt)}
          </div>
        </Card>
        <Card className="p-4">
          <div className="text-xs text-slate-500">Muddati o‘tgan</div>
          <div className="font-display text-lg font-bold text-red-600 tabular-nums mt-1">
            {formatUZS(summary.overdueDebt)}
          </div>
        </Card>
        <Card className="p-4">
          <div className="text-xs text-slate-500">Undirilgan qarz</div>
          <div className="font-display text-lg font-bold text-emerald-700 tabular-nums mt-1">
            {formatUZS(summary.debtCollections)}
          </div>
        </Card>
        <Card className="p-4">
          <div className="text-xs text-slate-500">Qarzdorlar soni</div>
          <div className="font-display text-lg font-bold text-slate-900 tabular-nums mt-1">
            {summary.activeDebtorsCount} ta
          </div>
        </Card>
        <Card className="p-4 col-span-2 lg:col-span-1">
          <div className="text-xs text-slate-500">Yaqin 7 kun muddatli</div>
          <div className="font-display text-lg font-bold text-amber-700 tabular-nums mt-1">
            {upcomingCount} ta shartnoma
          </div>
        </Card>
      </div>

      <Card className="p-5 space-y-4">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-3">
          <div className="relative flex-1 max-w-md">
            <Search className="w-4 h-4 text-slate-400 absolute left-3 top-3" />
            <Input
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              placeholder="Mijoz ismi, telefon yoki izoh bo‘yicha qidirish..."
              className="pl-9"
            />
          </div>
          <div className="flex flex-wrap gap-1 p-1 bg-slate-100 rounded-lg">
            {(['all', 'Faol', 'Qisman to‘langan', 'Muddati o‘tgan', 'To‘langan'] as const).map(
              (st) => (
                <button
                  key={st}
                  type="button"
                  onClick={() => setStatusFilter(st)}
                  className={`px-3 py-1.5 text-xs font-medium rounded-md transition-colors cursor-pointer whitespace-nowrap ${
                    statusFilter === st
                      ? 'bg-white text-slate-900 shadow-sm'
                      : 'text-slate-600 hover:text-slate-900'
                  }`}
                >
                  {st === 'all' ? 'Barchasi' : st}
                </button>
              )
            )}
          </div>
        </div>

        {filteredDebts.length === 0 ? (
          <EmptyState
            icon={<CreditCard className="w-5 h-5" />}
            title="Qarz yozuvlari topilmadi"
            description="Tanlangan filtr bo‘yicha qarzdorlik topilmadi."
            actionLabel={can('create_debt') ? 'Yangi qarz qo‘shish' : undefined}
            onAction={can('create_debt') ? () => setQuickModal('debt') : undefined}
          />
        ) : (
          <>
            <div className="hidden md:block overflow-x-auto">
              <table className="w-full text-left border-collapse">
                <thead>
                  <tr className="border-b border-slate-200 text-xs font-semibold text-slate-500">
                    <th className="py-2.5 pr-4">Mijoz</th>
                    <th className="py-2.5 px-3">Asl summa</th>
                    <th className="py-2.5 px-3">To‘langan</th>
                    <th className="py-2.5 px-3">Qolgan qarz</th>
                    <th className="py-2.5 px-3">Muddat</th>
                    <th className="py-2.5 px-3">Filial</th>
                    <th className="py-2.5 px-3">Holati</th>
                    <th className="py-2.5 pl-3 text-right">Amallar</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100 text-sm">
                  {filteredDebts.map((debt) => (
                    <tr key={debt.id} className="hover:bg-slate-50/70">
                      <td className="py-3 pr-4">
                        <button
                          type="button"
                          onClick={() => setSelectedDebtId(debt.id)}
                          className="text-left group cursor-pointer"
                        >
                          <div className="font-semibold text-slate-900 group-hover:text-[#2563EB]">
                            {debt.customerName}
                          </div>
                          <div className="text-xs text-slate-500">{debt.customerPhone}</div>
                        </button>
                      </td>
                      <td className="py-3 px-3 font-mono text-xs text-slate-700 tabular-nums whitespace-nowrap">
                        {formatUZS(debt.originalAmount)}
                      </td>
                      <td className="py-3 px-3 font-mono text-xs text-emerald-700 tabular-nums whitespace-nowrap">
                        {formatUZS(debt.paidAmount)}
                      </td>
                      <td className="py-3 px-3 font-mono text-sm font-bold text-slate-900 tabular-nums whitespace-nowrap">
                        {formatUZS(debt.remainingAmount)}
                      </td>
                      <td className="py-3 px-3 font-mono text-xs text-slate-600 tabular-nums whitespace-nowrap">
                        {formatDateUZ(debt.dueDate)}
                      </td>
                      <td className="py-3 px-3 text-xs text-slate-600">
                        {branchName(debt.branchId)}
                      </td>
                      <td className="py-3 px-3">
                        <StatusText
                          tone={statusTone(debt.computedStatus)}
                          label={debt.computedStatus}
                        />
                      </td>
                      <td className="py-3 pl-3 text-right">
                        <div className="inline-flex items-center gap-1.5">
                          {debt.remainingAmount > 0 && can('accept_payment') && (
                            <Button
                              size="sm"
                              onClick={() => {
                                setPayError(null);
                                setPayAmount('');
                                setPayModalDebt(debt);
                              }}
                            >
                              To‘lov
                            </Button>
                          )}
                          <Button
                            size="sm"
                            variant="secondary"
                            onClick={() => setSelectedDebtId(debt.id)}
                          >
                            Batafsil
                          </Button>
                        </div>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>

            {/* Mobile Cards */}
            <div className="md:hidden space-y-2.5">
              {filteredDebts.map((debt) => (
                <div
                  key={debt.id}
                  className="p-3.5 rounded-xl border border-slate-200 bg-white space-y-2"
                >
                  <div className="flex items-start justify-between gap-2">
                    <button
                      type="button"
                      onClick={() => setSelectedDebtId(debt.id)}
                      className="text-left cursor-pointer"
                    >
                      <div className="text-sm font-bold text-slate-900">{debt.customerName}</div>
                      <div className="text-xs text-slate-500">{debt.customerPhone}</div>
                    </button>
                    <StatusText
                      tone={statusTone(debt.computedStatus)}
                      label={debt.computedStatus}
                    />
                  </div>
                  <div className="grid grid-cols-2 gap-2 text-xs pt-1">
                    <div>
                      <span className="text-slate-500">Qolgan: </span>
                      <span className="font-mono font-bold text-slate-900 tabular-nums">
                        {formatUZS(debt.remainingAmount)}
                      </span>
                    </div>
                    <div className="text-right font-mono text-slate-500">
                      Muddat: {formatDateUZ(debt.dueDate)}
                    </div>
                  </div>
                  <div className="flex gap-2 pt-1">
                    {debt.remainingAmount > 0 && can('accept_payment') && (
                      <Button
                        size="sm"
                        className="flex-1"
                        onClick={() => {
                          setPayError(null);
                          setPayAmount('');
                          setPayModalDebt(debt);
                        }}
                      >
                        To‘lov qabul qilish
                      </Button>
                    )}
                    <Button
                      size="sm"
                      variant="secondary"
                      onClick={() => setSelectedDebtId(debt.id)}
                    >
                      Batafsil
                    </Button>
                  </div>
                </div>
              ))}
            </div>
          </>
        )}
      </Card>

      {/* Partial Payment Modal */}
      <Modal
        open={Boolean(payModalDebt)}
        onClose={() => setPayModalDebt(null)}
        title="Qarz to‘lovini qabul qilish"
        subtitle={payModalDebt ? `Mijoz: ${payModalDebt.customerName}` : undefined}
      >
        <form onSubmit={handleAcceptPayment} className="space-y-3.5">
          {payError && (
            <div className="p-3 rounded-lg bg-red-50 border border-red-200 text-xs text-red-700">
              {payError}
            </div>
          )}
          <div className="p-3 rounded-xl bg-slate-50 border border-slate-200 flex justify-between text-xs">
            <span className="text-slate-600">Qolgan qarz qoldig‘i:</span>
            <span className="font-mono font-bold text-slate-900 tabular-nums">
              {payModalDebt ? formatUZS(payModalDebt.remainingAmount) : ''}
            </span>
          </div>
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <div>
              <FieldLabel htmlFor="list-pay-amount" required>
                To‘lov summasi (so‘m)
              </FieldLabel>
              <Input
                id="list-pay-amount"
                type="number"
                min="1"
                value={payAmount}
                onChange={(e) => setPayAmount(e.target.value)}
                placeholder="1 000 000"
              />
            </div>
            <div>
              <FieldLabel htmlFor="list-pay-method">To‘lov usuli</FieldLabel>
              <Select
                id="list-pay-method"
                value={payMethod}
                onChange={(e) => setPayMethod(e.target.value as PaymentMethod)}
              >
                <option value="Naqd">Naqd</option>
                <option value="Karta">Karta</option>
                <option value="O‘tkazma">O‘tkazma</option>
              </Select>
            </div>
          </div>
          <div>
            <FieldLabel htmlFor="list-pay-note">Izoh</FieldLabel>
            <Input
              id="list-pay-note"
              value={payNote}
              onChange={(e) => setPayNote(e.target.value)}
              placeholder="Qisman to‘lov izohi"
            />
          </div>
          <div className="flex justify-end gap-2 pt-2">
            <Button variant="secondary" onClick={() => setPayModalDebt(null)}>
              Bekor qilish
            </Button>
            <Button type="submit" loading={payLoading}>
              Tasdiqlash
            </Button>
          </div>
        </form>
      </Modal>
    </div>
  );
}

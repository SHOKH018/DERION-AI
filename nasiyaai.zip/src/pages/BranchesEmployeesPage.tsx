import React, { useMemo, useState } from 'react';
import { Building2, Plus, Shield, UserCheck } from 'lucide-react';
import { useApp } from '../context/AppContext.tsx';
import { computeFinancialSummary, formatDateUZ, formatUZS } from '../lib/accounting.ts';
import { branchSchema, employeeSchema } from '../lib/validation.ts';
import type { UserRole } from '../types/domain.ts';
import {
  Button,
  Card,
  EmptyState,
  FieldLabel,
  Input,
  Modal,
  Select,
  StatusText,
} from '../components/ui/Primitives.tsx';

export function BranchesPage() {
  const { dataset, addBranch, can, setSelectedBranchId, setActivePage } = useApp();
  const [modalOpen, setModalOpen] = useState(false);
  const [name, setName] = useState('');
  const [address, setAddress] = useState('');
  const [managerName, setManagerName] = useState('');
  const [phone, setPhone] = useState('+998 ');
  const [target, setTarget] = useState('100000000');
  const [err, setErr] = useState<string | null>(null);
  const [saving, setSaving] = useState(false);

  const branchCards = useMemo(() => {
    return dataset.branches.map((b) => ({
      ...b,
      summary: computeFinancialSummary({
        sales: dataset.sales,
        debts: dataset.debts,
        transactions: dataset.transactions,
        products: dataset.products,
        branchId: b.id,
      }),
    }));
  }, [dataset]);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setErr(null);
    const parsed = branchSchema.safeParse({
      name,
      address,
      managerName,
      phone,
      monthlyTargetUzs: Number(target || 0),
    });
    if (!parsed.success) {
      setErr(parsed.error.issues[0]?.message || 'Ma’lumotlarni tekshiring.');
      return;
    }
    setSaving(true);
    try {
      await addBranch(parsed.data);
      setName('');
      setAddress('');
      setManagerName('');
      setModalOpen(false);
    } catch (e2) {
      setErr(e2 instanceof Error ? e2.message : 'Xatolik');
    } finally {
      setSaving(false);
    }
  };

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
        <div>
          <h2 className="font-display text-xl font-bold text-slate-900">Filiallar</h2>
          <p className="text-xs sm:text-sm text-slate-500 mt-0.5">
            Har bir savdo nuqtasining moliyaviy ko‘rsatkichlari va rahbarlari
          </p>
        </div>
        {can('manage_branches') && (
          <Button onClick={() => setModalOpen(true)}>
            <Plus className="w-4 h-4" />
            Filial qo‘shish
          </Button>
        )}
      </div>

      {branchCards.length === 0 ? (
        <Card className="p-6">
          <EmptyState
            icon={<Building2 className="w-5 h-5" />}
            title="Filiallar topilmadi"
            description="Birinchi filialni qo‘shing."
          />
        </Card>
      ) : (
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
          {branchCards.map((b) => (
            <Card key={b.id} className="p-5 space-y-4">
              <div className="flex items-start justify-between gap-3">
                <div>
                  <h3 className="font-display text-base font-bold text-slate-900">{b.name}</h3>
                  <p className="text-xs text-slate-500 mt-0.5">{b.address}</p>
                </div>
                <StatusText tone={b.status === 'Faol' ? 'positive' : 'neutral'} label={b.status} />
              </div>
              <div className="text-xs text-slate-600">
                Mas’ul: <strong className="text-slate-900">{b.managerName}</strong> ·{' '}
                <span className="font-mono">{b.phone}</span>
              </div>
              <div className="grid grid-cols-3 gap-3 pt-2 border-t border-slate-100 text-xs">
                <div>
                  <div className="text-slate-500">Savdo</div>
                  <div className="font-mono font-bold text-slate-900 tabular-nums mt-0.5">
                    {formatUZS(b.summary.totalSalesRevenue)}
                  </div>
                </div>
                <div>
                  <div className="text-slate-500">Sof foyda</div>
                  <div className="font-mono font-bold text-emerald-700 tabular-nums mt-0.5">
                    {formatUZS(b.summary.netProfit)}
                  </div>
                </div>
                <div>
                  <div className="text-slate-500">Qolgan qarz</div>
                  <div className="font-mono font-bold text-red-600 tabular-nums mt-0.5">
                    {formatUZS(b.summary.outstandingDebt)}
                  </div>
                </div>
              </div>
              <div className="flex justify-end">
                <Button
                  size="sm"
                  variant="secondary"
                  onClick={() => {
                    setSelectedBranchId(b.id);
                    setActivePage('reports');
                  }}
                >
                  Filial hisoboti
                </Button>
              </div>
            </Card>
          ))}
        </div>
      )}

      <Modal open={modalOpen} onClose={() => setModalOpen(false)} title="Yangi filial qo‘shish">
        <form onSubmit={handleSubmit} className="space-y-3.5">
          {err && (
            <div className="p-3 rounded-lg bg-red-50 border border-red-200 text-xs text-red-700">
              {err}
            </div>
          )}
          <div>
            <FieldLabel htmlFor="br-name" required>
              Filial nomi
            </FieldLabel>
            <Input id="br-name" value={name} onChange={(e) => setName(e.target.value)} />
          </div>
          <div>
            <FieldLabel htmlFor="br-addr" required>
              Manzil
            </FieldLabel>
            <Input id="br-addr" value={address} onChange={(e) => setAddress(e.target.value)} />
          </div>
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <div>
              <FieldLabel htmlFor="br-mgr" required>
                Mas’ul rahbar
              </FieldLabel>
              <Input
                id="br-mgr"
                value={managerName}
                onChange={(e) => setManagerName(e.target.value)}
              />
            </div>
            <div>
              <FieldLabel htmlFor="br-phone" required>
                Telefon
              </FieldLabel>
              <Input id="br-phone" value={phone} onChange={(e) => setPhone(e.target.value)} />
            </div>
          </div>
          <div>
            <FieldLabel htmlFor="br-target">Oylik reja (so‘m)</FieldLabel>
            <Input
              id="br-target"
              type="number"
              value={target}
              onChange={(e) => setTarget(e.target.value)}
            />
          </div>
          <div className="flex justify-end gap-2 pt-2">
            <Button variant="secondary" onClick={() => setModalOpen(false)}>
              Bekor qilish
            </Button>
            <Button type="submit" loading={saving}>
              Saqlash
            </Button>
          </div>
        </form>
      </Modal>
    </div>
  );
}

export function EmployeesPage() {
  const { dataset, addEmployee, can } = useApp();
  const [modalOpen, setModalOpen] = useState(false);
  const [fullName, setFullName] = useState('');
  const [phone, setPhone] = useState('+998 ');
  const [role, setRole] = useState<UserRole>('Seller');
  const [branchId, setBranchId] = useState(dataset.branches[0]?.id || 'br-main');
  const [err, setErr] = useState<string | null>(null);
  const [saving, setSaving] = useState(false);

  const branchName = (id: string) =>
    dataset.branches.find((b) => b.id === id)?.name || 'Asosiy filial';

  const roleDesc: Record<UserRole, string> = {
    Owner: 'To‘liq boshqaruv, moliya, xodimlar va sozlamalar',
    Admin: 'Do‘kon, ombor, savdo va xodimlar boshqaruvi',
    Seller: 'Savdo, mijozlar, qarzlar va to‘lov qabul qilish',
    Accountant: 'Moliya, analitika va moliyaviy hisobotlar',
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setErr(null);
    const parsed = employeeSchema.safeParse({
      fullName,
      phone,
      role,
      branchId: branchId || dataset.branches[0]?.id || 'br-main',
    });
    if (!parsed.success) {
      setErr(parsed.error.issues[0]?.message || 'Ma’lumotlarni tekshiring.');
      return;
    }
    setSaving(true);
    try {
      await addEmployee(parsed.data);
      setFullName('');
      setModalOpen(false);
    } catch (e2) {
      setErr(e2 instanceof Error ? e2.message : 'Xatolik');
    } finally {
      setSaving(false);
    }
  };

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
        <div>
          <h2 className="font-display text-xl font-bold text-slate-900">Xodimlar va rollar</h2>
          <p className="text-xs sm:text-sm text-slate-500 mt-0.5">
            Rolga asoslangan kirish nazorati (RBAC) va filial biriktiruvi
          </p>
        </div>
        {can('manage_employees') && (
          <Button onClick={() => setModalOpen(true)}>
            <Plus className="w-4 h-4" />
            Xodim qo‘shish
          </Button>
        )}
      </div>

      <Card className="p-5">
        {dataset.employees.length === 0 ? (
          <EmptyState
            icon={<UserCheck className="w-5 h-5" />}
            title="Xodimlar ro‘yxati bo‘sh"
            description="Jamoa a’zolarini qo‘shing va ularga mos rollarni belgilang."
          />
        ) : (
          <div className="divide-y divide-slate-100">
            {dataset.employees.map((emp) => (
              <div
                key={emp.id}
                className="py-3.5 flex flex-col sm:flex-row sm:items-center justify-between gap-2"
              >
                <div>
                  <div className="text-sm font-bold text-slate-900">{emp.fullName}</div>
                  <div className="text-xs text-slate-500">
                    <span className="font-mono">{emp.phone}</span> · {branchName(emp.branchId)} ·
                    Oxirgi faollik: {formatDateUZ(emp.lastActiveAt, true)}
                  </div>
                </div>
                <div className="flex items-center gap-2">
                  <StatusText tone="info" label={emp.role} />
                  <StatusText
                    tone={emp.status === 'Faol' ? 'positive' : 'negative'}
                    label={emp.status}
                  />
                </div>
              </div>
            ))}
          </div>
        )}
      </Card>

      <Card className="p-5 space-y-3">
        <div className="flex items-center gap-2 text-xs font-semibold text-slate-700">
          <Shield className="w-4 h-4 text-[#2563EB]" />
          <span>Rollar va server-tomon vakolatlar matritsasi</span>
        </div>
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3 text-xs">
          {(['Owner', 'Admin', 'Seller', 'Accountant'] as UserRole[]).map((r) => (
            <div key={r} className="p-3 rounded-xl bg-slate-50 border border-slate-200">
              <div className="font-bold text-slate-900">{r}</div>
              <p className="text-slate-600 mt-1 leading-relaxed">{roleDesc[r]}</p>
            </div>
          ))}
        </div>
      </Card>

      <Modal open={modalOpen} onClose={() => setModalOpen(false)} title="Yangi xodim qo‘shish">
        <form onSubmit={handleSubmit} className="space-y-3.5">
          {err && (
            <div className="p-3 rounded-lg bg-red-50 border border-red-200 text-xs text-red-700">
              {err}
            </div>
          )}
          <div>
            <FieldLabel htmlFor="emp-name" required>
              F.I.Sh.
            </FieldLabel>
            <Input
              id="emp-name"
              value={fullName}
              onChange={(e) => setFullName(e.target.value)}
            />
          </div>
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <div>
              <FieldLabel htmlFor="emp-phone" required>
                Telefon
              </FieldLabel>
              <Input id="emp-phone" value={phone} onChange={(e) => setPhone(e.target.value)} />
            </div>
            <div>
              <FieldLabel htmlFor="emp-role">Rol</FieldLabel>
              <Select
                id="emp-role"
                value={role}
                onChange={(e) => setRole(e.target.value as UserRole)}
              >
                <option value="Seller">Seller (Sotuvchi)</option>
                <option value="Accountant">Accountant (Buxgalter)</option>
                <option value="Admin">Admin</option>
                <option value="Owner">Owner</option>
              </Select>
            </div>
          </div>
          <div>
            <FieldLabel htmlFor="emp-branch">Filial</FieldLabel>
            <Select
              id="emp-branch"
              value={branchId}
              onChange={(e) => setBranchId(e.target.value)}
            >
              {dataset.branches.map((b) => (
                <option key={b.id} value={b.id}>
                  {b.name}
                </option>
              ))}
            </Select>
          </div>
          <div className="flex justify-end gap-2 pt-2">
            <Button variant="secondary" onClick={() => setModalOpen(false)}>
              Bekor qilish
            </Button>
            <Button type="submit" loading={saving}>
              Saqlash
            </Button>
          </div>
        </form>
      </Modal>
    </div>
  );
}

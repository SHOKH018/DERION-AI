import React, { useMemo, useState } from 'react';
import { BarChart3 } from 'lucide-react';
import {
  Bar,
  BarChart,
  CartesianGrid,
  Line,
  LineChart,
  ResponsiveContainer,
  Tooltip,
  XAxis,
  YAxis,
} from 'recharts';
import { useApp } from '../context/AppContext.tsx';
import { computeFinancialSummary, formatCompactUZS, formatUZS } from '../lib/accounting.ts';
import { Card, EmptyState } from '../components/ui/Primitives.tsx';

export function AnalyticsPage() {
  const { dataset } = useApp();
  const [period, setPeriod] = useState<'day' | 'week' | 'month' | 'year'>('month');

  const branchMetrics = useMemo(() => {
    return dataset.branches.map((b) => {
      const s = computeFinancialSummary({
        sales: dataset.sales,
        debts: dataset.debts,
        transactions: dataset.transactions,
        products: dataset.products,
        branchId: b.id,
      });
      return {
        name: b.name,
        savdo: s.totalSalesRevenue,
        foyda: s.netProfit,
        qarz: s.outstandingDebt,
      };
    });
  }, [dataset]);

  const productPerf = useMemo(() => {
    const map = new Map<string, { name: string; qty: number; revenue: number; profit: number }>();
    for (const s of dataset.sales) {
      for (const item of s.items) {
        const cur = map.get(item.productId) || {
          name: item.productName,
          qty: 0,
          revenue: 0,
          profit: 0,
        };
        cur.qty += item.quantity;
        cur.revenue += item.lineTotal;
        cur.profit += item.lineTotal - item.purchasePrice * item.quantity;
        map.set(item.productId, cur);
      }
    }
    return Array.from(map.values()).sort((a, b) => b.revenue - a.revenue);
  }, [dataset.sales]);

  const customerPerf = useMemo(() => {
    return dataset.customers
      .map((c) => {
        const spent = dataset.sales
          .filter((s) => s.customerId === c.id)
          .reduce((acc, s) => acc + s.totalAmount, 0);
        const debt = dataset.debts
          .filter((d) => d.customerId === c.id)
          .reduce((acc, d) => acc + d.remainingAmount, 0);
        return { id: c.id, name: c.fullName, spent, debt };
      })
      .sort((a, b) => b.spent - a.spent)
      .slice(0, 6);
  }, [dataset.customers, dataset.sales, dataset.debts]);

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
        <div>
          <h2 className="font-display text-xl font-bold text-slate-900">Biznes analitikasi</h2>
          <p className="text-xs sm:text-sm text-slate-500 mt-0.5">
            Savdo, foyda, qarz undiruvi, filiallar va mahsulotlar samaradorligi
          </p>
        </div>
        <div className="flex gap-1 p-1 bg-slate-100 rounded-lg self-start">
          {(
            [
              ['day', 'Kun'],
              ['week', 'Hafta'],
              ['month', 'Oy'],
              ['year', 'Yil'],
            ] as const
          ).map(([val, label]) => (
            <button
              key={val}
              type="button"
              onClick={() => setPeriod(val)}
              className={`px-3 py-1.5 text-xs font-medium rounded-md cursor-pointer ${
                period === val ? 'bg-white text-slate-900 shadow-sm' : 'text-slate-600'
              }`}
            >
              {label}
            </button>
          ))}
        </div>
      </div>

      {dataset.sales.length === 0 ? (
        <Card className="p-6">
          <EmptyState
            icon={<BarChart3 className="w-5 h-5" />}
            title="Analitika uchun ma’lumotlar yo‘q"
            description="Savdo va moliyaviy operatsiyalar kiritilgach grafiklar avtomatik shakllanadi."
          />
        </Card>
      ) : (
        <>
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
            <Card className="p-5">
              <h3 className="text-sm font-bold text-slate-900 mb-1">
                Filiallar kesimida savdo va foyda ({period === 'day' ? 'Kunlik' : period === 'week' ? 'Haftalik' : period === 'month' ? 'Oylik' : 'Yillik'} ko‘rinish)
              </h3>
              <p className="text-xs text-slate-500 mb-4">Haqiqiy savdo daromadi va sof foyda</p>
              <div className="h-64 w-full">
                <ResponsiveContainer width="100%" height="100%">
                  <BarChart data={branchMetrics}>
                    <CartesianGrid strokeDasharray="3 3" stroke="#E2E8F0" vertical={false} />
                    <XAxis dataKey="name" tick={{ fontSize: 11, fill: '#64748B' }} />
                    <YAxis
                      tickFormatter={(v) => formatCompactUZS(Number(v))}
                      tick={{ fontSize: 11, fill: '#64748B' }}
                      width={64}
                    />
                    <Tooltip formatter={(val) => formatUZS(Number(val))} />
                    <Bar dataKey="savdo" name="Savdo" fill="#2563EB" radius={[4, 4, 0, 0]} />
                    <Bar dataKey="foyda" name="Sof foyda" fill="#16A34A" radius={[4, 4, 0, 0]} />
                  </BarChart>
                </ResponsiveContainer>
              </div>
            </Card>

            <Card className="p-5">
              <h3 className="text-sm font-bold text-slate-900 mb-1">Filiallar qarz yuki</h3>
              <p className="text-xs text-slate-500 mb-4">Har bir filialdagi qolgan nasiya qoldig‘i</p>
              <div className="h-64 w-full">
                <ResponsiveContainer width="100%" height="100%">
                  <LineChart data={branchMetrics}>
                    <CartesianGrid strokeDasharray="3 3" stroke="#E2E8F0" vertical={false} />
                    <XAxis dataKey="name" tick={{ fontSize: 11, fill: '#64748B' }} />
                    <YAxis
                      tickFormatter={(v) => formatCompactUZS(Number(v))}
                      tick={{ fontSize: 11, fill: '#64748B' }}
                      width={64}
                    />
                    <Tooltip formatter={(val) => formatUZS(Number(val))} />
                    <Line
                      type="monotone"
                      dataKey="qarz"
                      name="Qolgan qarz"
                      stroke="#D97706"
                      strokeWidth={2.5}
                    />
                  </LineChart>
                </ResponsiveContainer>
              </div>
            </Card>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
            <Card className="p-5 space-y-3">
              <h3 className="text-sm font-bold text-slate-900">Eng samarali mahsulotlar</h3>
              <div className="divide-y divide-slate-100 text-xs">
                {productPerf.map((p) => (
                  <div key={p.name} className="py-2.5 flex justify-between gap-3">
                    <div>
                      <div className="font-semibold text-slate-900">{p.name}</div>
                      <div className="text-slate-500">Sotilgan: {p.qty} dona</div>
                    </div>
                    <div className="text-right font-mono tabular-nums">
                      <div className="font-bold text-slate-900">{formatUZS(p.revenue)}</div>
                      <div className="text-emerald-700">Yalpi foyda: {formatUZS(p.profit)}</div>
                    </div>
                  </div>
                ))}
              </div>
            </Card>

            <Card className="p-5 space-y-3">
              <h3 className="text-sm font-bold text-slate-900">Mijozlar faolligi</h3>
              <div className="divide-y divide-slate-100 text-xs">
                {customerPerf.map((c) => (
                  <div key={c.id} className="py-2.5 flex justify-between gap-3">
                    <div className="font-semibold text-slate-900">{c.name}</div>
                    <div className="text-right font-mono tabular-nums">
                      <div className="font-bold text-slate-900">Xarid: {formatUZS(c.spent)}</div>
                      <div className={c.debt > 0 ? 'text-red-600' : 'text-emerald-700'}>
                        Qarz: {formatUZS(c.debt)}
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </Card>
          </div>
        </>
      )}
    </div>
  );
}

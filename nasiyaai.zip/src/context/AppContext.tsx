import React, { createContext, useCallback, useContext, useEffect, useMemo, useState } from 'react';
import { createDemoDataset, DEMO_AVATAR_URL } from '../data/demoDataset.ts';
import { TRANSLATIONS, type LocalizationBundle } from '../i18n/translations.ts';
import {
  applyDebtPayment,
  calculateSaleTotals,
  computeBusinessHealthHeuristic,
  computeFinancialSummary,
  formatUZS,
  hasPermission,
  resolveDebtStatus,
} from '../lib/accounting.ts';
import { initTelegramMiniApp, type TelegramEnvironmentInfo } from '../lib/telegram.ts';
import { apiClient } from '../services/apiClient.ts';
import type { ToastItem } from '../components/ui/Primitives.tsx';
import type {
  AppMode,
  AppNotification,
  AuthUser,
  Branch,
  BusinessDataset,
  BusinessHealthAssessment,
  BusinessSettings,
  Customer,
  DateRangePreset,
  Debt,
  Employee,
  FinanceTransaction,
  FinancialSummary,
  LanguageCode,
  NavPageId,
  PaymentMethod,
  PermissionKey,
  Product,
  Sale,
  UserRole,
} from '../types/domain.ts';

interface AppContextValue {
  mode: AppMode;
  setMode: (mode: AppMode) => void;
  activePage: NavPageId;
  setActivePage: (page: NavPageId) => void;
  selectedBranchId: string;
  setSelectedBranchId: (id: string) => void;
  dateRange: DateRangePreset;
  setDateRange: (range: DateRangePreset) => void;
  user: AuthUser | null;
  switchDemoRole: (role: UserRole) => void;
  telegramEnv: TelegramEnvironmentInfo;
  telegramAuthState: 'idle' | 'authenticating' | 'authenticated' | 'error';
  telegramAuthError: string | null;
  retryTelegramAuth: () => void;
  realAuthLoading: boolean;
  realAuthError: string | null;
  needsBootstrap: boolean;
  backendCapabilities: {
    telegramBotConfigured: boolean;
    geminiConfigured: boolean;
    externalBackendUrl: string | null;
  };
  bootstrapRealAdmin: (passcode: string, fullName: string, shopName: string) => Promise<void>;
  loginRealWeb: (passcode: string, role?: UserRole) => Promise<void>;
  logoutReal: () => Promise<void>;
  refreshData: () => Promise<void>;
  loadingData: boolean;
  dataError: string | null;
  dataset: BusinessDataset;
  summary: FinancialSummary;
  healthAssessment: BusinessHealthAssessment;
  t: LocalizationBundle;
  can: (permission: PermissionKey) => boolean;
  toasts: ToastItem[];
  pushToast: (tone: ToastItem['tone'], message: string) => void;
  dismissToast: (id: string) => void;
  // Quick modal triggers from dashboard
  quickModal: 'none' | 'debt' | 'payment' | 'customer' | 'expense' | 'sale';
  setQuickModal: (m: 'none' | 'debt' | 'payment' | 'customer' | 'expense' | 'sale') => void;
  selectedDebtId: string | null;
  setSelectedDebtId: (id: string | null) => void;
  selectedCustomerId: string | null;
  setSelectedCustomerId: (id: string | null) => void;
  // Mutations
  createTransaction: (input: {
    amount: number;
    category: string;
    description: string;
    date: string;
    type: 'Boshqa kirim' | 'Xarajat';
    paymentMethod: PaymentMethod;
    branchId: string;
  }) => Promise<void>;
  createDebt: (input: {
    customerMode: 'existing' | 'new';
    customerId?: string;
    newCustomerName?: string;
    newCustomerPhone?: string;
    amount: number;
    initialPayment: number;
    description: string;
    date: string;
    dueDate: string;
    paymentMethod: PaymentMethod;
    branchId: string;
    notes?: string;
  }) => Promise<void>;
  acceptDebtPayment: (
    debtId: string,
    input: { amount: number; paymentMethod: PaymentMethod; note?: string; idempotencyKey: string }
  ) => Promise<void>;
  sendDebtReminder: (debtId: string, message: string) => Promise<void>;
  saveCustomer: (
    input: Omit<Customer, 'id' | 'createdAt'>,
    editId?: string
  ) => Promise<Customer>;
  createSale: (input: {
    customerId: string;
    branchId: string;
    items: Array<{ productId: string; quantity: number; unitPrice: number }>;
    discountAmount: number;
    paidAmount: number;
    paymentMethod: PaymentMethod;
    dueDate?: string;
    idempotencyKey: string;
  }) => Promise<Sale>;
  saveProduct: (
    input: Omit<Product, 'id' | 'status'>,
    editId?: string
  ) => Promise<void>;
  addBranch: (input: Omit<Branch, 'id' | 'status'>) => Promise<void>;
  addEmployee: (input: Omit<Employee, 'id' | 'status' | 'lastActiveAt'>) => Promise<void>;
  markNotificationRead: (id: string) => Promise<void>;
  markAllNotificationsRead: () => void;
  updateSettings: (partial: Partial<BusinessSettings>) => Promise<void>;
  approveAiAction: (actionId: string) => Promise<void>;
}

const AppContext = createContext<AppContextValue | null>(null);

const EMPTY_REAL_DATASET: BusinessDataset = {
  branches: [],
  employees: [],
  customers: [],
  products: [],
  stockMovements: [],
  sales: [],
  debts: [],
  transactions: [],
  notifications: [],
  aiActions: [],
  settings: {
    shopName: 'NasiyaAI Do‘koni',
    legalName: '',
    currency: 'UZS',
    timezone: 'Asia/Tashkent',
    language: 'uz',
    telegramBotConnected: false,
    telegramBotUsername: '@NasiyaAI_Bot',
    connectedPaymentProviders: { payme: false, click: false, uzum: false },
    notifications: {
      overdueDebtAlerts: true,
      lowStockAlerts: true,
      dailySummaryAt2000: true,
      unusualExpenseAlerts: true,
    },
    apiBaseUrl: '/api',
  },
};

const DEMO_USER: AuthUser = {
  id: 'demo-owner',
  fullName: 'Jahongir Rahimov',
  phone: '+998 90 900 11 22',
  telegramUsername: 'jahongir_biznes',
  role: 'Owner',
  shopId: 'demo-shop',
  shopName: 'Baraka Texnika',
  branchId: 'br-chilonzor',
  avatarUrl: DEMO_AVATAR_URL,
  authSource: 'demo',
};

export function AppProvider({ children }: { children: React.ReactNode }) {
  const [telegramEnv] = useState<TelegramEnvironmentInfo>(() => initTelegramMiniApp());
  const [mode, setModeState] = useState<AppMode>(() =>
    telegramEnv.isTelegramWebApp && telegramEnv.hasInitData ? 'real' : 'demo'
  );
  const [activePage, setActivePage] = useState<NavPageId>('dashboard');
  const [selectedBranchId, setSelectedBranchId] = useState<string>('all');
  const [dateRange, setDateRange] = useState<DateRangePreset>('30d');

  const [demoDataset, setDemoDataset] = useState<BusinessDataset>(() => createDemoDataset());
  const [demoUser, setDemoUser] = useState<AuthUser>(DEMO_USER);
  const [realDataset, setRealDataset] = useState<BusinessDataset>(EMPTY_REAL_DATASET);
  const [realUser, setRealUser] = useState<AuthUser | null>(null);

  const [telegramAuthState, setTelegramAuthState] = useState<
    'idle' | 'authenticating' | 'authenticated' | 'error'
  >('idle');
  const [telegramAuthError, setTelegramAuthError] = useState<string | null>(null);

  const [needsBootstrap, setNeedsBootstrap] = useState(false);
  const [backendCapabilities, setBackendCapabilities] = useState({
    telegramBotConfigured: false,
    geminiConfigured: false,
    externalBackendUrl: null as string | null,
  });
  const [realAuthLoading, setRealAuthLoading] = useState(false);
  const [realAuthError, setRealAuthError] = useState<string | null>(null);
  const [loadingData, setLoadingData] = useState(false);
  const [dataError, setDataError] = useState<string | null>(null);

  const [toasts, setToasts] = useState<ToastItem[]>([]);
  const [quickModal, setQuickModal] = useState<
    'none' | 'debt' | 'payment' | 'customer' | 'expense' | 'sale'
  >('none');
  const [selectedDebtId, setSelectedDebtId] = useState<string | null>(null);
  const [selectedCustomerId, setSelectedCustomerId] = useState<string | null>(null);

  const [demoProcessedKeys] = useState<Set<string>>(() => new Set());

  const pushToast = useCallback((tone: ToastItem['tone'], message: string) => {
    const id = `toast-${Date.now()}-${Math.random().toString(36).slice(2, 5)}`;
    setToasts((prev) => [...prev, { id, tone, message }]);
    setTimeout(() => {
      setToasts((prev) => prev.filter((item) => item.id !== id));
    }, 4500);
  }, []);

  const dismissToast = useCallback((id: string) => {
    setToasts((prev) => prev.filter((t) => t.id !== id));
  }, []);

  const fetchRealOverview = useCallback(async () => {
    setLoadingData(true);
    setDataError(null);
    try {
      const overview = await apiClient.getDashboardOverview();
      setRealDataset(overview);
    } catch (err) {
      setDataError(err instanceof Error ? err.message : 'Backend ma’lumotlarini yuklab bo‘lmadi.');
    } finally {
      setLoadingData(false);
    }
  }, []);

  const checkBootstrapStatus = useCallback(async () => {
    try {
      const status = await apiClient.getBootstrapStatus();
      setNeedsBootstrap(status.needsBootstrap);
      setBackendCapabilities({
        telegramBotConfigured: status.telegramBotConfigured,
        geminiConfigured: status.geminiConfigured,
        externalBackendUrl: status.externalBackendUrl,
      });
    } catch {
      // ignore if external backend doesn't implement bootstrap-status
    }
  }, []);

  const runTelegramAuth = useCallback(async () => {
    if (!telegramEnv.hasInitData) return;
    setTelegramAuthState('authenticating');
    setTelegramAuthError(null);
    try {
      const res = await apiClient.authenticateTelegram(telegramEnv.initData);
      setRealUser(res.user);
      setTelegramAuthState('authenticated');
      await fetchRealOverview();
    } catch (err) {
      setTelegramAuthState('error');
      setTelegramAuthError(
        err instanceof Error ? err.message : 'Telegram Mini App autentifikatsiyasi amalga oshmadi.'
      );
    }
  }, [telegramEnv.hasInitData, telegramEnv.initData, fetchRealOverview]);

  useEffect(() => {
    void checkBootstrapStatus();
    if (telegramEnv.isTelegramWebApp && telegramEnv.hasInitData) {
      void runTelegramAuth();
    }
  }, [checkBootstrapStatus, telegramEnv.isTelegramWebApp, telegramEnv.hasInitData, runTelegramAuth]);

  const setMode = useCallback(
    (nextMode: AppMode) => {
      setModeState(nextMode);
      setSelectedBranchId('all');
      setSelectedDebtId(null);
      setSelectedCustomerId(null);
      if (nextMode === 'real') {
        void checkBootstrapStatus();
        if (realUser) {
          void fetchRealOverview();
        }
      }
    },
    [checkBootstrapStatus, fetchRealOverview, realUser]
  );

  const switchDemoRole = useCallback(
    (role: UserRole) => {
      setDemoUser((prev) => ({ ...prev, role }));
      pushToast('info', `Demo rol "${role}" ga o‘zgartirildi.`);
    },
    [pushToast]
  );

  const bootstrapRealAdmin = useCallback(
    async (passcode: string, fullName: string, shopName: string) => {
      setRealAuthLoading(true);
      setRealAuthError(null);
      try {
        const res = await apiClient.bootstrapAdmin(passcode, fullName, shopName);
        setRealUser(res.user);
        setNeedsBootstrap(false);
        await fetchRealOverview();
        pushToast('success', 'Administrator hisobi yaratildi va tizimga kirildi.');
      } catch (err) {
        setRealAuthError(err instanceof Error ? err.message : 'Sozlashda xatolik.');
        throw err;
      } finally {
        setRealAuthLoading(false);
      }
    },
    [fetchRealOverview, pushToast]
  );

  const loginRealWeb = useCallback(
    async (passcode: string, role?: UserRole) => {
      setRealAuthLoading(true);
      setRealAuthError(null);
      try {
        const res = await apiClient.loginWithPasscode(passcode, role);
        setRealUser(res.user);
        await fetchRealOverview();
        pushToast('success', 'Real API rejimiga muvaffaqiyatli kirildi.');
      } catch (err) {
        setRealAuthError(err instanceof Error ? err.message : 'Kirishda xatolik.');
        throw err;
      } finally {
        setRealAuthLoading(false);
      }
    },
    [fetchRealOverview, pushToast]
  );

  const logoutReal = useCallback(async () => {
    await apiClient.logout();
    setRealUser(null);
    setRealDataset(EMPTY_REAL_DATASET);
    pushToast('info', 'Tizimdan chiqildi.');
  }, [pushToast]);

  const refreshData = useCallback(async () => {
    if (mode === 'demo') {
      pushToast('info', 'Demo ma’lumotlar yangilandi.');
      return;
    }
    await fetchRealOverview();
  }, [mode, fetchRealOverview, pushToast]);

  const dataset = mode === 'demo' ? demoDataset : realDataset;
  const user = mode === 'demo' ? demoUser : realUser;

  const summary = useMemo(
    () =>
      computeFinancialSummary({
        sales: dataset.sales,
        debts: dataset.debts,
        transactions: dataset.transactions,
        products: dataset.products,
        branchId: selectedBranchId,
        dateRange,
        nowIso: mode === 'demo' ? '2026-11-25T20:00:00+05:00' : new Date().toISOString(),
      }),
    [dataset, selectedBranchId, dateRange, mode]
  );

  const healthAssessment = useMemo(
    () => computeBusinessHealthHeuristic(summary, dataset.products),
    [summary, dataset.products]
  );

  const lang: LanguageCode = dataset.settings.language || 'uz';
  const t = TRANSLATIONS[lang] || TRANSLATIONS.uz;

  const can = useCallback(
    (permission: PermissionKey) => {
      if (!user) return false;
      return hasPermission(user.role, permission);
    },
    [user]
  );

  // Mutations
  const createTransaction = useCallback(
    async (input: {
      amount: number;
      category: string;
      description: string;
      date: string;
      type: 'Boshqa kirim' | 'Xarajat';
      paymentMethod: PaymentMethod;
      branchId: string;
    }) => {
      if (mode === 'real') {
        const created = await apiClient.createTransaction(input);
        setRealDataset((prev) => ({
          ...prev,
          transactions: [created, ...prev.transactions],
        }));
        pushToast('success', 'Tranzaksiya serverga saqlandi.');
        return;
      }

      const tx: FinanceTransaction = {
        id: `tx-${Date.now()}`,
        date: input.date,
        description: input.description,
        category: input.category,
        type: input.type,
        paymentMethod: input.paymentMethod,
        amount: Math.round(input.amount),
        branchId: input.branchId,
        status: 'Tasdiqlangan',
      };
      setDemoDataset((prev) => ({
        ...prev,
        transactions: [tx, ...prev.transactions],
      }));
      pushToast('success', 'Tranzaksiya (Demo rejim) qo‘shildi.');
    },
    [mode, pushToast]
  );

  const createDebt = useCallback(
    async (input: {
      customerMode: 'existing' | 'new';
      customerId?: string;
      newCustomerName?: string;
      newCustomerPhone?: string;
      amount: number;
      initialPayment: number;
      description: string;
      date: string;
      dueDate: string;
      paymentMethod: PaymentMethod;
      branchId: string;
      notes?: string;
    }) => {
      if (mode === 'real') {
        await apiClient.createDebt(input);
        await fetchRealOverview();
        pushToast('success', 'Yangi qarz yozuvi yaratildi.');
        return;
      }

      let customer = demoDataset.customers.find((c) => c.id === input.customerId);
      let nextCustomers = demoDataset.customers;
      if (input.customerMode === 'new' && input.newCustomerName && input.newCustomerPhone) {
        customer = {
          id: `cust-${Date.now()}`,
          fullName: input.newCustomerName.trim(),
          phone: input.newCustomerPhone.trim(),
          branchId: input.branchId,
          status: 'Faol',
          createdAt: new Date().toISOString(),
        };
        nextCustomers = [customer, ...demoDataset.customers];
      }
      if (!customer) throw new Error('Mijoz tanlanmadi.');
      if (input.initialPayment >= input.amount) {
        throw new Error('Boshlang‘ich to‘lov jami qarzdan kichik bo‘lishi kerak.');
      }

      const debtId = `debt-${Date.now()}`;
      const remaining = Math.round(input.amount - input.initialPayment);
      const newTxs: FinanceTransaction[] = [];
      const payments: Debt['payments'] = [];

      if (input.initialPayment > 0) {
        const txId = `tx-${Date.now()}`;
        newTxs.push({
          id: txId,
          date: input.date,
          description: `Qarz boshlang‘ich to‘lovi #${debtId} (${customer.fullName})`,
          category: 'Qarz undiruvi',
          type: 'Qarz undiruvi',
          paymentMethod: input.paymentMethod,
          amount: Math.round(input.initialPayment),
          branchId: input.branchId,
          status: 'Tasdiqlangan',
          relatedRecordId: debtId,
        });
        payments.push({
          id: `dp-${Date.now()}`,
          debtId,
          amount: Math.round(input.initialPayment),
          paymentMethod: input.paymentMethod,
          note: 'Boshlang‘ich to‘lov',
          receivedBy: demoUser.fullName,
          createdAt: input.date,
          transactionId: txId,
        });
      }

      const newDebt: Debt = {
        id: debtId,
        customerId: customer.id,
        customerName: customer.fullName,
        customerPhone: customer.phone,
        branchId: input.branchId,
        description: input.description.trim(),
        originalAmount: Math.round(input.amount),
        paidAmount: Math.round(input.initialPayment),
        remainingAmount: remaining,
        createdAt: input.date,
        dueDate: input.dueDate,
        status: resolveDebtStatus(remaining, input.initialPayment, input.dueDate),
        notes: input.notes,
        payments,
        reminders: [],
      };

      setDemoDataset((prev) => ({
        ...prev,
        customers: nextCustomers,
        debts: [newDebt, ...prev.debts],
        transactions: [...newTxs, ...prev.transactions],
      }));
      pushToast('success', 'Yangi qarz (Demo rejim) qo‘shildi.');
    },
    [mode, fetchRealOverview, pushToast, demoDataset.customers, demoUser.fullName]
  );

  const acceptDebtPayment = useCallback(
    async (
      debtId: string,
      input: { amount: number; paymentMethod: PaymentMethod; note?: string; idempotencyKey: string }
    ) => {
      if (mode === 'real') {
        await apiClient.acceptDebtPayment(debtId, input);
        await fetchRealOverview();
        pushToast('success', `${formatUZS(input.amount)} qarz to‘lovi qabul qilindi.`);
        return;
      }

      if (demoProcessedKeys.has(input.idempotencyKey)) {
        throw new Error('Takroriy to‘lov aniqlandi.');
      }

      const target = demoDataset.debts.find((d) => d.id === debtId);
      if (!target) throw new Error('Qarz topilmadi.');

      const result = applyDebtPayment(target, input.amount);
      const txId = `tx-${Date.now()}`;
      const nowIso = new Date().toISOString();
      const tx: FinanceTransaction = {
        id: txId,
        date: nowIso,
        description: `Qarz to‘lovi #${target.id} (${target.customerName})`,
        category: 'Qarz undiruvi',
        type: 'Qarz undiruvi',
        paymentMethod: input.paymentMethod,
        amount: Math.round(input.amount),
        branchId: target.branchId,
        status: 'Tasdiqlangan',
        relatedRecordId: target.id,
      };

      const paymentRecord = {
        id: `dp-${Date.now()}`,
        idempotencyKey: input.idempotencyKey,
        debtId: target.id,
        amount: Math.round(input.amount),
        paymentMethod: input.paymentMethod,
        note: input.note,
        receivedBy: demoUser.fullName,
        createdAt: nowIso,
        transactionId: txId,
      };

      demoProcessedKeys.add(input.idempotencyKey);
      setDemoDataset((prev) => ({
        ...prev,
        debts: prev.debts.map((d) =>
          d.id === debtId
            ? {
                ...d,
                paidAmount: result.paidAmount,
                remainingAmount: result.remainingAmount,
                status: result.status,
                payments: [paymentRecord, ...d.payments],
              }
            : d
        ),
        transactions: [tx, ...prev.transactions],
      }));
      pushToast('success', `${formatUZS(input.amount)} qarz to‘lovi saqlandi (Demo rejim).`);
    },
    [mode, fetchRealOverview, pushToast, demoDataset.debts, demoUser.fullName, demoProcessedKeys]
  );

  const sendDebtReminder = useCallback(
    async (debtId: string, message: string) => {
      if (mode === 'real') {
        const res = await apiClient.sendDebtReminder(debtId, message);
        await fetchRealOverview();
        pushToast(
          'success',
          res.deliveredViaBot
            ? 'Telegram eslatma bot orqali yuborildi.'
            : 'Eslatma qayd etildi (tashqi bot API ulanmagan).'
        );
        return;
      }

      const reminder = {
        id: `rem-${Date.now()}`,
        debtId,
        channel: 'Telegram Bot' as const,
        message,
        sentAt: new Date().toISOString(),
        status: 'Demo (simulyatsiya)' as const,
      };
      setDemoDataset((prev) => ({
        ...prev,
        debts: prev.debts.map((d) =>
          d.id === debtId ? { ...d, reminders: [reminder, ...d.reminders] } : d
        ),
      }));
      pushToast('info', 'Demo rejim: haqiqiy Telegram xabar yuborilmadi, jurnalga yozildi.');
    },
    [mode, fetchRealOverview, pushToast]
  );

  const saveCustomer = useCallback(
    async (input: Omit<Customer, 'id' | 'createdAt'>, editId?: string) => {
      if (mode === 'real') {
        const saved = editId
          ? await apiClient.updateCustomer(editId, input)
          : await apiClient.createCustomer(input);
        await fetchRealOverview();
        pushToast('success', editId ? 'Mijoz yangilandi.' : 'Yangi mijoz qo‘shildi.');
        return saved;
      }

      if (editId) {
        let updated: Customer | null = null;
        setDemoDataset((prev) => ({
          ...prev,
          customers: prev.customers.map((c) => {
            if (c.id !== editId) return c;
            updated = { ...c, ...input };
            return updated;
          }),
        }));
        pushToast('success', 'Mijoz ma’lumotlari yangilandi.');
        return updated!;
      }

      const created: Customer = {
        ...input,
        id: `cust-${Date.now()}`,
        createdAt: new Date().toISOString(),
      };
      setDemoDataset((prev) => ({
        ...prev,
        customers: [created, ...prev.customers],
      }));
      pushToast('success', 'Yangi mijoz qo‘shildi.');
      return created;
    },
    [mode, fetchRealOverview, pushToast]
  );

  const createSale = useCallback(
    async (input: {
      customerId: string;
      branchId: string;
      items: Array<{ productId: string; quantity: number; unitPrice: number }>;
      discountAmount: number;
      paidAmount: number;
      paymentMethod: PaymentMethod;
      dueDate?: string;
      idempotencyKey: string;
    }) => {
      if (mode === 'real') {
        const res = await apiClient.createSale(input);
        await fetchRealOverview();
        pushToast('success', 'Savdo muvaffaqiyatli rasmiylashtirildi.');
        return res.sale;
      }

      if (demoProcessedKeys.has(input.idempotencyKey)) {
        throw new Error('Takroriy savdo yuborildi.');
      }

      const customer = demoDataset.customers.find((c) => c.id === input.customerId);
      if (!customer) throw new Error('Mijoz tanlanmagan.');

      const resolvedItems = input.items.map((row) => {
        const p = demoDataset.products.find((prod) => prod.id === row.productId);
        if (!p) throw new Error('Mahsulot topilmadi.');
        if (p.quantity < row.quantity) {
          throw new Error(`Omborda "${p.name}" yetarli emas (mavjud: ${p.quantity} dona).`);
        }
        return {
          productId: p.id,
          productName: p.name,
          quantity: row.quantity,
          unitPrice: row.unitPrice,
          purchasePrice: p.purchasePrice,
        };
      });

      const calc = calculateSaleTotals({
        items: resolvedItems,
        discountAmount: input.discountAmount,
        paidAmount: input.paidAmount,
      });

      const saleId = `sale-${Date.now()}`;
      const nowIso = new Date().toISOString();
      const sale: Sale = {
        id: saleId,
        idempotencyKey: input.idempotencyKey,
        customerId: customer.id,
        customerName: customer.fullName,
        branchId: input.branchId,
        items: calc.items,
        subtotal: calc.subtotal,
        discountAmount: calc.discountAmount,
        totalAmount: calc.totalAmount,
        cogsTotal: calc.cogsTotal,
        paidAmount: calc.paidAmount,
        debtAmount: calc.debtAmount,
        paymentMethod: input.paymentMethod,
        paymentStatus: calc.paymentStatus,
        sellerName: demoUser.fullName,
        createdAt: nowIso,
      };

      demoProcessedKeys.add(input.idempotencyKey);

      setDemoDataset((prev) => {
        const updatedProducts = prev.products.map((p) => {
          const soldLine = calc.items.find((i) => i.productId === p.id);
          if (!soldLine) return p;
          const nextQty = p.quantity - soldLine.quantity;
          return {
            ...p,
            quantity: nextQty,
            status: (nextQty <= 0
              ? 'Tugagan'
              : nextQty <= p.minStockLevel
              ? 'Kam qolgan'
              : 'Mavjud') as Product['status'],
          };
        });

        const newMovements = calc.items.map((item) => ({
          id: `sm-${Date.now()}-${Math.random().toString(36).slice(2, 5)}`,
          productId: item.productId,
          productName: item.productName,
          branchId: input.branchId,
          type: 'Sotuv' as const,
          quantityDelta: -item.quantity,
          note: `Savdo #${saleId} (${customer.fullName})`,
          createdAt: nowIso,
          actorName: demoUser.fullName,
        }));

        const nextTxs =
          calc.paidAmount > 0
            ? [
                {
                  id: `tx-${Date.now()}`,
                  date: nowIso,
                  description: `Savdo #${saleId} to‘lovi (${customer.fullName})`,
                  category: 'Savdo',
                  type: 'Savdo tushumi' as const,
                  paymentMethod: input.paymentMethod,
                  amount: calc.paidAmount,
                  branchId: input.branchId,
                  status: 'Tasdiqlangan' as const,
                  relatedRecordId: saleId,
                },
                ...prev.transactions,
              ]
            : prev.transactions;

        const nextDebts =
          calc.debtAmount > 0
            ? [
                {
                  id: `debt-${Date.now()}`,
                  saleId,
                  customerId: customer.id,
                  customerName: customer.fullName,
                  customerPhone: customer.phone,
                  branchId: input.branchId,
                  description: `${calc.items
                    .map((i) => `${i.productName} (${i.quantity})`)
                    .join(', ')} — nasiya`,
                  originalAmount: calc.debtAmount,
                  paidAmount: 0,
                  remainingAmount: calc.debtAmount,
                  createdAt: nowIso,
                  dueDate: input.dueDate || new Date(Date.now() + 30 * 86400_000).toISOString(),
                  status: 'Faol' as const,
                  payments: [],
                  reminders: [],
                },
                ...prev.debts,
              ]
            : prev.debts;

        return {
          ...prev,
          products: updatedProducts,
          stockMovements: [...newMovements, ...prev.stockMovements],
          sales: [sale, ...prev.sales],
          transactions: nextTxs,
          debts: nextDebts,
        };
      });

      pushToast('success', 'Savdo saqlandi, ombor va qarz qoldiqlari yangilandi.');
      return sale;
    },
    [
      mode,
      fetchRealOverview,
      pushToast,
      demoDataset.customers,
      demoDataset.products,
      demoUser.fullName,
      demoProcessedKeys,
    ]
  );

  const saveProduct = useCallback(
    async (input: Omit<Product, 'id' | 'status'>, editId?: string) => {
      if (mode === 'real') {
        if (editId) await apiClient.updateProduct(editId, input);
        else await apiClient.createProduct(input);
        await fetchRealOverview();
        pushToast('success', editId ? 'Mahsulot yangilandi.' : 'Mahsulot omborga qo‘shildi.');
        return;
      }

      const status: Product['status'] =
        input.quantity <= 0
          ? 'Tugagan'
          : input.quantity <= input.minStockLevel
          ? 'Kam qolgan'
          : 'Mavjud';

      if (editId) {
        setDemoDataset((prev) => ({
          ...prev,
          products: prev.products.map((p) => (p.id === editId ? { ...p, ...input, status } : p)),
        }));
        pushToast('success', 'Mahsulot yangilandi.');
        return;
      }

      const product: Product = {
        ...input,
        id: `prod-${Date.now()}`,
        status,
      };
      setDemoDataset((prev) => ({
        ...prev,
        products: [product, ...prev.products],
        stockMovements: [
          {
            id: `sm-${Date.now()}`,
            productId: product.id,
            productName: product.name,
            branchId: product.branchId,
            type: 'Kirim',
            quantityDelta: product.quantity,
            note: 'Boshlang‘ich ombor kirimi',
            createdAt: new Date().toISOString(),
            actorName: demoUser.fullName,
          },
          ...prev.stockMovements,
        ],
      }));
      pushToast('success', 'Yangi mahsulot qo‘shildi.');
    },
    [mode, fetchRealOverview, pushToast, demoUser.fullName]
  );

  const addBranch = useCallback(
    async (input: Omit<Branch, 'id' | 'status'>) => {
      if (mode === 'real') {
        await apiClient.createBranch(input);
        await fetchRealOverview();
        pushToast('success', 'Yangi filial qo‘shildi.');
        return;
      }
      setDemoDataset((prev) => ({
        ...prev,
        branches: [...prev.branches, { ...input, id: `br-${Date.now()}`, status: 'Faol' }],
      }));
      pushToast('success', 'Yangi filial qo‘shildi.');
    },
    [mode, fetchRealOverview, pushToast]
  );

  const addEmployee = useCallback(
    async (input: Omit<Employee, 'id' | 'status' | 'lastActiveAt'>) => {
      if (mode === 'real') {
        await apiClient.createEmployee(input);
        await fetchRealOverview();
        pushToast('success', 'Yangi xodim qo‘shildi.');
        return;
      }
      setDemoDataset((prev) => ({
        ...prev,
        employees: [
          ...prev.employees,
          {
            ...input,
            id: `emp-${Date.now()}`,
            status: 'Faol',
            lastActiveAt: new Date().toISOString(),
          },
        ],
      }));
      pushToast('success', 'Xodim qo‘shildi.');
    },
    [mode, fetchRealOverview, pushToast]
  );

  const markNotificationRead = useCallback(
    async (id: string) => {
      if (mode === 'real') {
        await apiClient.markNotificationRead(id);
      }
      const updater = (list: AppNotification[]) =>
        list.map((n) => (n.id === id ? { ...n, isRead: true } : n));
      if (mode === 'real') {
        setRealDataset((prev) => ({ ...prev, notifications: updater(prev.notifications) }));
      } else {
        setDemoDataset((prev) => ({ ...prev, notifications: updater(prev.notifications) }));
      }
    },
    [mode]
  );

  const markAllNotificationsRead = useCallback(() => {
    const updater = (list: AppNotification[]) => list.map((n) => ({ ...n, isRead: true }));
    if (mode === 'real') {
      setRealDataset((prev) => ({ ...prev, notifications: updater(prev.notifications) }));
    } else {
      setDemoDataset((prev) => ({ ...prev, notifications: updater(prev.notifications) }));
    }
    pushToast('info', 'Barcha bildirishnomalar o‘qilgan deb belgilandi.');
  }, [mode, pushToast]);

  const updateSettings = useCallback(
    async (partial: Partial<BusinessSettings>) => {
      if (mode === 'real') {
        const updated = await apiClient.updateSettings(partial);
        setRealDataset((prev) => ({ ...prev, settings: updated }));
        if (partial.apiBaseUrl) apiClient.setBaseUrl(partial.apiBaseUrl);
        pushToast('success', 'Sozlamalar serverda saqlandi.');
        return;
      }
      if (partial.apiBaseUrl) apiClient.setBaseUrl(partial.apiBaseUrl);
      setDemoDataset((prev) => ({
        ...prev,
        settings: { ...prev.settings, ...partial },
      }));
      pushToast('success', 'Sozlamalar saqlandi.');
    },
    [mode, pushToast]
  );

  const approveAiAction = useCallback(
    async (actionId: string) => {
      if (mode === 'real') {
        const res = await apiClient.approveAiAction(actionId);
        await fetchRealOverview();
        pushToast('success', res.message);
        return;
      }
      setDemoDataset((prev) => ({
        ...prev,
        aiActions: prev.aiActions.map((a) =>
          a.id === actionId ? { ...a, status: 'Tasdiqlangan' } : a
        ),
      }));
      pushToast('success', 'AI tavsiya etgan amal foydalanuvchi tasdig‘i bilan belgilandi.');
    },
    [mode, fetchRealOverview, pushToast]
  );

  return (
    <AppContext.Provider
      value={{
        mode,
        setMode,
        activePage,
        setActivePage,
        selectedBranchId,
        setSelectedBranchId,
        dateRange,
        setDateRange,
        user,
        switchDemoRole,
        telegramEnv,
        telegramAuthState,
        telegramAuthError,
        retryTelegramAuth: runTelegramAuth,
        realAuthLoading,
        realAuthError,
        needsBootstrap,
        backendCapabilities,
        bootstrapRealAdmin,
        loginRealWeb,
        logoutReal,
        refreshData,
        loadingData,
        dataError,
        dataset,
        summary,
        healthAssessment,
        t,
        can,
        toasts,
        pushToast,
        dismissToast,
        quickModal,
        setQuickModal,
        selectedDebtId,
        setSelectedDebtId,
        selectedCustomerId,
        setSelectedCustomerId,
        createTransaction,
        createDebt,
        acceptDebtPayment,
        sendDebtReminder,
        saveCustomer,
        createSale,
        saveProduct,
        addBranch,
        addEmployee,
        markNotificationRead,
        markAllNotificationsRead,
        updateSettings,
        approveAiAction,
      }}
    >
      {children}
    </AppContext.Provider>
  );
}

export function useApp(): AppContextValue {
  const ctx = useContext(AppContext);
  if (!ctx) throw new Error('useApp must be used inside AppProvider');
  return ctx;
}

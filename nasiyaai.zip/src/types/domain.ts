export type AppMode = 'demo' | 'real';

export type LanguageCode = 'uz' | 'ru' | 'en';

export type UserRole = 'Owner' | 'Admin' | 'Seller' | 'Accountant';

export type NavPageId =
  | 'dashboard'
  | 'ai'
  | 'finance'
  | 'debts'
  | 'customers'
  | 'sales'
  | 'inventory'
  | 'analytics'
  | 'reports'
  | 'branches'
  | 'employees'
  | 'notifications'
  | 'settings';

export type PaymentMethod = 'Naqd' | 'Karta' | 'O‘tkazma';

export type DebtStatus = 'Faol' | 'Qisman to‘langan' | 'To‘langan' | 'Muddati o‘tgan';

export type DateRangePreset = 'today' | '7d' | '30d' | '90d' | 'all';

export type PermissionKey =
  | 'view_dashboard'
  | 'view_ai'
  | 'approve_ai_actions'
  | 'view_finance'
  | 'create_transaction'
  | 'view_debts'
  | 'create_debt'
  | 'accept_payment'
  | 'send_reminder'
  | 'view_customers'
  | 'manage_customers'
  | 'export_customers'
  | 'view_sales'
  | 'create_sale'
  | 'view_inventory'
  | 'manage_inventory'
  | 'view_analytics'
  | 'view_reports'
  | 'export_reports'
  | 'view_branches'
  | 'manage_branches'
  | 'view_employees'
  | 'manage_employees'
  | 'view_notifications'
  | 'view_settings'
  | 'manage_settings';

export interface AuthUser {
  id: string;
  fullName: string;
  phone: string;
  telegramUsername?: string;
  telegramId?: string;
  role: UserRole;
  shopId: string;
  shopName: string;
  branchId: string;
  avatarUrl?: string;
  authSource: 'telegram' | 'web' | 'demo';
}

export interface Branch {
  id: string;
  name: string;
  address: string;
  managerName: string;
  phone: string;
  status: 'Faol' | 'Nofaol';
  monthlyTargetUzs: number;
}

export interface Employee {
  id: string;
  fullName: string;
  phone: string;
  role: UserRole;
  branchId: string;
  status: 'Faol' | 'Bloklangan';
  lastActiveAt: string;
}

export interface Customer {
  id: string;
  fullName: string;
  phone: string;
  address?: string;
  notes?: string;
  branchId: string;
  status: 'Faol' | 'Kuzatuvda' | 'Ishonchli';
  createdAt: string;
  lastInteractionAt?: string;
}

export interface Product {
  id: string;
  name: string;
  sku: string;
  category: string;
  purchasePrice: number;
  sellingPrice: number;
  quantity: number;
  minStockLevel: number;
  branchId: string;
  status: 'Mavjud' | 'Kam qolgan' | 'Tugagan';
}

export interface StockMovement {
  id: string;
  productId: string;
  productName: string;
  branchId: string;
  type: 'Kirim' | 'Sotuv' | 'Tuzatish';
  quantityDelta: number;
  note: string;
  createdAt: string;
  actorName: string;
}

export interface SaleItem {
  productId: string;
  productName: string;
  quantity: number;
  unitPrice: number;
  purchasePrice: number;
  lineTotal: number;
}

export interface Sale {
  id: string;
  idempotencyKey?: string;
  customerId: string;
  customerName: string;
  branchId: string;
  items: SaleItem[];
  subtotal: number;
  discountAmount: number;
  totalAmount: number;
  cogsTotal: number;
  paidAmount: number;
  debtAmount: number;
  paymentMethod: PaymentMethod;
  paymentStatus: 'To‘langan' | 'Qisman' | 'Nasiya';
  sellerName: string;
  createdAt: string;
}

export interface DebtPayment {
  id: string;
  idempotencyKey?: string;
  debtId: string;
  amount: number;
  paymentMethod: PaymentMethod;
  note?: string;
  receivedBy: string;
  createdAt: string;
  transactionId: string;
}

export interface DebtReminderLog {
  id: string;
  debtId: string;
  channel: 'Telegram Bot' | 'SMS';
  message: string;
  sentAt: string;
  status: 'Yuborildi' | 'Demo (simulyatsiya)';
}

export interface Debt {
  id: string;
  saleId?: string;
  customerId: string;
  customerName: string;
  customerPhone: string;
  branchId: string;
  description: string;
  originalAmount: number;
  paidAmount: number;
  remainingAmount: number;
  createdAt: string;
  dueDate: string;
  status: DebtStatus;
  notes?: string;
  payments: DebtPayment[];
  reminders: DebtReminderLog[];
}

export type TransactionType = 'Savdo tushumi' | 'Qarz undiruvi' | 'Boshqa kirim' | 'Xarajat';

export interface FinanceTransaction {
  id: string;
  date: string;
  description: string;
  category: string;
  type: TransactionType;
  paymentMethod: PaymentMethod;
  amount: number;
  branchId: string;
  status: 'Tasdiqlangan' | 'Kutilmoqda';
  relatedRecordId?: string;
}

export type NotificationType =
  | 'Yangi qarz'
  | 'To‘lov qabul qilindi'
  | 'Muddati o‘tgan qarz'
  | 'Kam qolgan mahsulot'
  | 'G‘ayrioddiy xarajat'
  | 'AI tavsiyasi'
  | 'Xodim harakati';

export interface AppNotification {
  id: string;
  type: NotificationType;
  title: string;
  message: string;
  createdAt: string;
  isRead: boolean;
  targetPage: NavPageId;
  relatedId?: string;
}

export interface AIInsightCard {
  id: string;
  category: 'anomaly' | 'briefing' | 'recommendation';
  severity: 'info' | 'warning' | 'critical';
  title: string;
  summary: string;
  basis: string;
  factVsEstimate: string;
  recommendedAction: string;
}

export interface AIForecastItem {
  id: string;
  metricLabel: string;
  horizon: string;
  projectedValueUzs: number;
  confidenceLabel: 'Yuqori' | 'O‘rta' | 'Past';
  historicalPeriodUsed: string;
  assumptions: string;
}

export interface AIActionSuggestion {
  id: string;
  title: string;
  description: string;
  actionType: 'send_reminder' | 'review_overdue' | 'check_expense' | 'restock_alert';
  targetId?: string;
  requiresConfirmation: true;
  status: 'Kutilmoqda' | 'Tasdiqlangan' | 'Bekor qilingan';
}

export interface AIChatMessage {
  id: string;
  role: 'user' | 'assistant';
  text: string;
  createdAt: string;
  dateRangeUsed?: string;
  basis?: string;
  isEstimate?: boolean;
  recommendations?: string[];
  missingData?: string;
}

export interface BusinessSettings {
  shopName: string;
  legalName: string;
  currency: 'UZS';
  timezone: 'Asia/Tashkent';
  language: LanguageCode;
  telegramBotConnected: boolean;
  telegramBotUsername: string;
  connectedPaymentProviders: {
    payme: boolean;
    click: boolean;
    uzum: boolean;
  };
  notifications: {
    overdueDebtAlerts: boolean;
    lowStockAlerts: boolean;
    dailySummaryAt2000: boolean;
    unusualExpenseAlerts: boolean;
  };
  apiBaseUrl: string;
}

export interface FinancialSummary {
  totalSalesRevenue: number;
  initialCashFromSales: number;
  debtCollections: number;
  otherIncome: number;
  totalCashInflow: number;
  totalCOGS: number;
  operatingExpenses: number;
  netProfit: number;
  cashPayments: number;
  cardPayments: number;
  transferPayments: number;
  outstandingDebt: number;
  overdueDebt: number;
  totalOriginalDebt: number;
  activeDebtorsCount: number;
  inventoryValuation: number;
}

export interface BusinessHealthAssessment {
  score: number;
  isHeuristic: true;
  label: string;
  methodology: string;
  strengths: string[];
  weaknesses: string[];
  recommendations: string[];
}

export interface BusinessDataset {
  branches: Branch[];
  employees: Employee[];
  customers: Customer[];
  products: Product[];
  stockMovements: StockMovement[];
  sales: Sale[];
  debts: Debt[];
  transactions: FinanceTransaction[];
  notifications: AppNotification[];
  aiActions: AIActionSuggestion[];
  settings: BusinessSettings;
}

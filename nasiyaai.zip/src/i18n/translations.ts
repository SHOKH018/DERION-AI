import type { LanguageCode, NavPageId } from '../types/domain.ts';

export interface LocalizationBundle {
  nav: Record<NavPageId, string>;
  common: {
    save: string;
    cancel: string;
    newDebt: string;
    acceptPayment: string;
    debtors: string;
    remainingDebt: string;
    downloadReport: string;
    noDataFound: string;
    retry: string;
    searchPlaceholder: string;
    allBranches: string;
    demoModeLabel: string;
    realModeLabel: string;
    confirmAction: string;
    loading: string;
  };
  dateRanges: {
    today: string;
    '7d': string;
    '30d': string;
    '90d': string;
    all: string;
  };
}

export const TRANSLATIONS: Record<LanguageCode, LocalizationBundle> = {
  uz: {
    nav: {
      dashboard: 'Bosh sahifa',
      ai: 'AI Intelligence',
      finance: 'Moliya',
      debts: 'Qarzlar',
      customers: 'Mijozlar',
      sales: 'Savdo',
      inventory: 'Ombor',
      analytics: 'Analitika',
      reports: 'Hisobotlar',
      branches: 'Filiallar',
      employees: 'Xodimlar',
      notifications: 'Bildirishnomalar',
      settings: 'Sozlamalar',
    },
    common: {
      save: 'Saqlash',
      cancel: 'Bekor qilish',
      newDebt: 'Yangi qarz',
      acceptPayment: 'To‘lov qabul qilish',
      debtors: 'Qarzdorlar',
      remainingDebt: 'Qolgan qarz',
      downloadReport: 'Hisobotni yuklab olish',
      noDataFound: 'Ma’lumot topilmadi',
      retry: 'Qayta urinish',
      searchPlaceholder: 'Qidirish...',
      allBranches: 'Barcha filiallar',
      demoModeLabel: 'Demo rejim (Namunaviy ma’lumotlar)',
      realModeLabel: 'Real API rejimi',
      confirmAction: 'Tasdiqlash',
      loading: 'Yuklanmoqda...',
    },
    dateRanges: {
      today: 'Bugun',
      '7d': '7 kun',
      '30d': '30 kun',
      '90d': '90 kun',
      all: 'Barcha vaqt',
    },
  },
  ru: {
    nav: {
      dashboard: 'Главная',
      ai: 'AI Интеллект',
      finance: 'Финансы',
      debts: 'Долги',
      customers: 'Клиенты',
      sales: 'Продажи',
      inventory: 'Склад',
      analytics: 'Аналитика',
      reports: 'Отчёты',
      branches: 'Филиалы',
      employees: 'Сотрудники',
      notifications: 'Уведомления',
      settings: 'Настройки',
    },
    common: {
      save: 'Сохранить',
      cancel: 'Отмена',
      newDebt: 'Новый долг',
      acceptPayment: 'Принять оплату',
      debtors: 'Должники',
      remainingDebt: 'Остаток долга',
      downloadReport: 'Скачать отчёт',
      noDataFound: 'Данные не найдены',
      retry: 'Повторить',
      searchPlaceholder: 'Поиск...',
      allBranches: 'Все филиалы',
      demoModeLabel: 'Демо режим (Образцы данных)',
      realModeLabel: 'Реальный API режим',
      confirmAction: 'Подтвердить',
      loading: 'Загрузка...',
    },
    dateRanges: {
      today: 'Сегодня',
      '7d': '7 дней',
      '30d': '30 дней',
      '90d': '90 дней',
      all: 'Всё время',
    },
  },
  en: {
    nav: {
      dashboard: 'Dashboard',
      ai: 'AI Intelligence',
      finance: 'Finance',
      debts: 'Debts',
      customers: 'Customers',
      sales: 'Sales',
      inventory: 'Inventory',
      analytics: 'Analytics',
      reports: 'Reports',
      branches: 'Branches',
      employees: 'Employees',
      notifications: 'Notifications',
      settings: 'Settings',
    },
    common: {
      save: 'Save',
      cancel: 'Cancel',
      newDebt: 'New Debt',
      acceptPayment: 'Accept Payment',
      debtors: 'Debtors',
      remainingDebt: 'Remaining Debt',
      downloadReport: 'Download Report',
      noDataFound: 'No data found',
      retry: 'Retry',
      searchPlaceholder: 'Search...',
      allBranches: 'All Branches',
      demoModeLabel: 'Demo Mode (Sample Data)',
      realModeLabel: 'Real API Mode',
      confirmAction: 'Confirm',
      loading: 'Loading...',
    },
    dateRanges: {
      today: 'Today',
      '7d': '7 days',
      '30d': '30 days',
      '90d': '90 days',
      all: 'All time',
    },
  },
};

import React from 'react';
import { AppProvider, useApp } from './context/AppContext.tsx';
import { AppShell } from './components/layout/AppShell.tsx';
import { RealAuthGate } from './components/auth/RealAuthGate.tsx';
import { QuickActionModals } from './components/modals/QuickActionModals.tsx';
import { ToastContainer } from './components/ui/Primitives.tsx';
import { DashboardPage } from './pages/DashboardPage.tsx';
import { AiIntelligencePage } from './pages/AiIntelligencePage.tsx';
import { FinancePage } from './pages/FinancePage.tsx';
import { DebtsPage } from './pages/DebtsPage.tsx';
import { CustomersPage } from './pages/CustomersPage.tsx';
import { SalesPage } from './pages/SalesPage.tsx';
import { InventoryPage } from './pages/InventoryPage.tsx';
import { AnalyticsPage } from './pages/AnalyticsPage.tsx';
import { ReportsPage } from './pages/ReportsPage.tsx';
import { BranchesPage, EmployeesPage } from './pages/BranchesEmployeesPage.tsx';
import { NotificationsPage } from './pages/NotificationsPage.tsx';
import { SettingsPage } from './pages/SettingsPage.tsx';

function PageRouter() {
  const { mode, user, activePage } = useApp();

  if (mode === 'real' && !user) {
    return <RealAuthGate />;
  }

  switch (activePage) {
    case 'dashboard':
      return <DashboardPage />;
    case 'ai':
      return <AiIntelligencePage />;
    case 'finance':
      return <FinancePage />;
    case 'debts':
      return <DebtsPage />;
    case 'customers':
      return <CustomersPage />;
    case 'sales':
      return <SalesPage />;
    case 'inventory':
      return <InventoryPage />;
    case 'analytics':
      return <AnalyticsPage />;
    case 'reports':
      return <ReportsPage />;
    case 'branches':
      return <BranchesPage />;
    case 'employees':
      return <EmployeesPage />;
    case 'notifications':
      return <NotificationsPage />;
    case 'settings':
      return <SettingsPage />;
    default:
      return <DashboardPage />;
  }
}

function AppWorkspace() {
  const { toasts, dismissToast } = useApp();

  return (
    <>
      <AppShell>
        <PageRouter />
      </AppShell>
      <QuickActionModals />
      <ToastContainer toasts={toasts} onDismiss={dismissToast} />
    </>
  );
}

export default function App() {
  return (
    <AppProvider>
      <AppWorkspace />
    </AppProvider>
  );
}

import type {
  AIChatMessage,
  AIForecastItem,
  AIInsightCard,
  AppNotification,
  AuthUser,
  Branch,
  BusinessDataset,
  BusinessSettings,
  Customer,
  Debt,
  Employee,
  FinanceTransaction,
  FinancialSummary,
  PaymentMethod,
  Product,
  Sale,
} from '../types/domain.ts';

export interface EndpointContractDoc {
  method: 'GET' | 'POST' | 'PATCH';
  path: string;
  module: string;
  localExpressImplemented: boolean;
  externalPythonBotNote: string;
}

export const API_ENDPOINTS_CONTRACT: EndpointContractDoc[] = [
  { method: 'POST', path: '/auth/telegram', module: 'Autentifikatsiya', localExpressImplemented: true, externalPythonBotNote: 'Telegram initData HMAC-SHA256 tekshiruvi' },
  { method: 'POST', path: '/auth/refresh', module: 'Autentifikatsiya', localExpressImplemented: true, externalPythonBotNote: 'Sessiya tokenini yangilash' },
  { method: 'POST', path: '/auth/logout', module: 'Autentifikatsiya', localExpressImplemented: true, externalPythonBotNote: 'Sessiyani yopish' },
  { method: 'GET', path: '/auth/me', module: 'Autentifikatsiya', localExpressImplemented: true, externalPythonBotNote: 'Joriy foydalanuvchi va rol' },
  { method: 'GET', path: '/dashboard/overview', module: 'Bosh sahifa', localExpressImplemented: true, externalPythonBotNote: 'Asosiy KPI va grafiklar' },
  { method: 'GET', path: '/finance/summary', module: 'Moliya', localExpressImplemented: true, externalPythonBotNote: 'Kirim, xarajat va sof foyda' },
  { method: 'GET', path: '/finance/transactions', module: 'Moliya', localExpressImplemented: true, externalPythonBotNote: 'Tranzaksiyalar ro‘yxati' },
  { method: 'POST', path: '/finance/transactions', module: 'Moliya', localExpressImplemented: true, externalPythonBotNote: 'Yangi moliyaviy operatsiya' },
  { method: 'GET', path: '/debts', module: 'Qarzlar', localExpressImplemented: true, externalPythonBotNote: 'Qarzdorlik ro‘yxati' },
  { method: 'GET', path: '/debts/{id}', module: 'Qarzlar', localExpressImplemented: true, externalPythonBotNote: 'Qarz tafsiloti va to‘lov tarixi' },
  { method: 'POST', path: '/debts', module: 'Qarzlar', localExpressImplemented: true, externalPythonBotNote: 'Yangi qarz yaratish' },
  { method: 'POST', path: '/debts/{id}/payments', module: 'Qarzlar', localExpressImplemented: true, externalPythonBotNote: 'Qisman yoki to‘liq to‘lov qabul qilish' },
  { method: 'POST', path: '/debts/{id}/reminders', module: 'Qarzlar', localExpressImplemented: true, externalPythonBotNote: 'Python aiogram bot orqali mijozga eslatma yuborish' },
  { method: 'GET', path: '/customers', module: 'Mijozlar', localExpressImplemented: true, externalPythonBotNote: 'Mijozlar bazasi' },
  { method: 'GET', path: '/customers/{id}', module: 'Mijozlar', localExpressImplemented: true, externalPythonBotNote: 'Mijoz profili va tarixi' },
  { method: 'POST', path: '/customers', module: 'Mijozlar', localExpressImplemented: true, externalPythonBotNote: 'Yangi mijoz qo‘shish' },
  { method: 'PATCH', path: '/customers/{id}', module: 'Mijozlar', localExpressImplemented: true, externalPythonBotNote: 'Mijoz ma’lumotlarini tahrirlash' },
  { method: 'GET', path: '/sales', module: 'Savdo', localExpressImplemented: true, externalPythonBotNote: 'Savdolar tarixi' },
  { method: 'POST', path: '/sales', module: 'Savdo', localExpressImplemented: true, externalPythonBotNote: 'Yangi savdo (naqd/qisman/nasiya)' },
  { method: 'GET', path: '/products', module: 'Ombor', localExpressImplemented: true, externalPythonBotNote: 'Mahsulotlar va qoldiq' },
  { method: 'POST', path: '/products', module: 'Ombor', localExpressImplemented: true, externalPythonBotNote: 'Mahsulot qo‘shish' },
  { method: 'PATCH', path: '/products/{id}', module: 'Ombor', localExpressImplemented: true, externalPythonBotNote: 'Narx va qoldiqni yangilash' },
  { method: 'GET', path: '/analytics/overview', module: 'Analitika', localExpressImplemented: true, externalPythonBotNote: 'Umumiy tahlil' },
  { method: 'GET', path: '/analytics/sales', module: 'Analitika', localExpressImplemented: true, externalPythonBotNote: 'Savdo dinamikasi' },
  { method: 'GET', path: '/analytics/debts', module: 'Analitika', localExpressImplemented: true, externalPythonBotNote: 'Qarz undiruvi tahlili' },
  { method: 'POST', path: '/ai/chat', module: 'AI Intelligence', localExpressImplemented: true, externalPythonBotNote: 'Server-side Gemini AI tahliliy chat' },
  { method: 'GET', path: '/ai/insights', module: 'AI Intelligence', localExpressImplemented: true, externalPythonBotNote: 'AI brifing va anomaliyalar' },
  { method: 'GET', path: '/ai/forecasts', module: 'AI Intelligence', localExpressImplemented: true, externalPythonBotNote: 'Taxminiy prognozlar' },
  { method: 'POST', path: '/ai/actions/{id}/approve', module: 'AI Intelligence', localExpressImplemented: true, externalPythonBotNote: 'Foydalanuvchi tasdig‘idan so‘ng harakat' },
  { method: 'GET', path: '/reports/daily', module: 'Hisobotlar', localExpressImplemented: true, externalPythonBotNote: 'Kunlik hisobot' },
  { method: 'GET', path: '/reports/monthly', module: 'Hisobotlar', localExpressImplemented: true, externalPythonBotNote: 'Oylik hisobot' },
  { method: 'GET', path: '/reports/yearly', module: 'Hisobotlar', localExpressImplemented: true, externalPythonBotNote: 'Yillik hisobot' },
  { method: 'GET', path: '/branches', module: 'Filiallar', localExpressImplemented: true, externalPythonBotNote: 'Filiallar ro‘yxati' },
  { method: 'GET', path: '/employees', module: 'Xodimlar', localExpressImplemented: true, externalPythonBotNote: 'Xodimlar va rollar' },
  { method: 'GET', path: '/notifications', module: 'Bildirishnomalar', localExpressImplemented: true, externalPythonBotNote: 'Bildirishnomalar markazi' },
  { method: 'PATCH', path: '/notifications/{id}/read', module: 'Bildirishnomalar', localExpressImplemented: true, externalPythonBotNote: 'O‘qilgan deb belgilash' },
  { method: 'GET', path: '/settings', module: 'Sozlamalar', localExpressImplemented: true, externalPythonBotNote: 'Do‘kon sozlamalari' },
  { method: 'PATCH', path: '/settings', module: 'Sozlamalar', localExpressImplemented: true, externalPythonBotNote: 'Sozlamalarni saqlash' },
];

export class ApiClientError extends Error {
  status: number;
  code?: string;

  constructor(message: string, status = 500, code?: string) {
    super(message);
    this.status = status;
    this.code = code;
  }
}

export class NasiyaApiClient {
  private baseUrl: string;
  // Security rule: keep session token strictly in memory, NEVER in localStorage/sessionStorage
  private accessToken: string | null = null;

  constructor(baseUrl?: string) {
    const envUrl =
      typeof import.meta !== 'undefined' &&
      (import.meta as unknown as { env?: Record<string, string> }).env?.VITE_API_BASE_URL;
    this.baseUrl = (baseUrl || envUrl || '/api').replace(/\/+$/, '');
  }

  setBaseUrl(url: string) {
    this.baseUrl = (url || '/api').replace(/\/+$/, '');
  }

  getBaseUrl(): string {
    return this.baseUrl;
  }

  setAccessToken(token: string | null) {
    this.accessToken = token;
  }

  getAccessToken(): string | null {
    return this.accessToken;
  }

  private async request<T>(path: string, init: RequestInit = {}): Promise<T> {
    const headers: Record<string, string> = {
      'Content-Type': 'application/json',
      ...(init.headers as Record<string, string> | undefined),
    };
    if (this.accessToken) {
      headers['Authorization'] = `Bearer ${this.accessToken}`;
    }

    const res = await fetch(`${this.baseUrl}${path}`, {
      ...init,
      headers,
    });

    const contentType = res.headers.get('content-type') || '';
    const isJson = contentType.includes('application/json');
    const payload = isJson ? await res.json() : await res.text();

    if (!res.ok) {
      const message =
        isJson && payload?.error
          ? String(payload.error)
          : `Server xatosi (${res.status})`;
      throw new ApiClientError(message, res.status, isJson ? payload?.code : undefined);
    }
    return payload as T;
  }

  // Auth
  async getBootstrapStatus(): Promise<{
    needsBootstrap: boolean;
    telegramBotConfigured: boolean;
    geminiConfigured: boolean;
    externalBackendUrl: string | null;
  }> {
    return this.request('/auth/bootstrap-status');
  }

  async bootstrapAdmin(passcode: string, fullName: string, shopName: string): Promise<{
    token: string;
    user: AuthUser;
  }> {
    const data = await this.request<{ token: string; user: AuthUser }>('/auth/bootstrap', {
      method: 'POST',
      body: JSON.stringify({ passcode, fullName, shopName }),
    });
    this.setAccessToken(data.token);
    return data;
  }

  async loginWithPasscode(passcode: string, role?: string): Promise<{
    token: string;
    user: AuthUser;
  }> {
    const data = await this.request<{ token: string; user: AuthUser }>('/auth/login', {
      method: 'POST',
      body: JSON.stringify({ passcode, role }),
    });
    this.setAccessToken(data.token);
    return data;
  }

  async authenticateTelegram(initData: string): Promise<{
    token: string;
    user: AuthUser;
  }> {
    const data = await this.request<{ token: string; user: AuthUser }>('/auth/telegram', {
      method: 'POST',
      body: JSON.stringify({ initData }),
    });
    this.setAccessToken(data.token);
    return data;
  }

  async refreshToken(): Promise<{ token: string }> {
    const data = await this.request<{ token: string }>('/auth/refresh', { method: 'POST' });
    this.setAccessToken(data.token);
    return data;
  }

  async logout(): Promise<void> {
    try {
      await this.request('/auth/logout', { method: 'POST' });
    } finally {
      this.setAccessToken(null);
    }
  }

  async getMe(): Promise<AuthUser> {
    return this.request('/auth/me');
  }

  // Full dataset snapshot for workspace synchronization
  async getDashboardOverview(): Promise<BusinessDataset & { summary: FinancialSummary }> {
    return this.request('/dashboard/overview');
  }

  // Finance
  async getFinanceSummary(): Promise<FinancialSummary> {
    return this.request('/finance/summary');
  }

  async getTransactions(): Promise<FinanceTransaction[]> {
    return this.request('/finance/transactions');
  }

  async createTransaction(input: {
    amount: number;
    category: string;
    description: string;
    date: string;
    type: 'Boshqa kirim' | 'Xarajat';
    paymentMethod: PaymentMethod;
    branchId: string;
  }): Promise<FinanceTransaction> {
    return this.request('/finance/transactions', {
      method: 'POST',
      body: JSON.stringify(input),
    });
  }

  // Debts
  async getDebts(): Promise<Debt[]> {
    return this.request('/debts');
  }

  async getDebtById(id: string): Promise<Debt> {
    return this.request(`/debts/${encodeURIComponent(id)}`);
  }

  async createDebt(input: Record<string, unknown>): Promise<Debt> {
    return this.request('/debts', {
      method: 'POST',
      body: JSON.stringify(input),
    });
  }

  async acceptDebtPayment(
    debtId: string,
    input: {
      amount: number;
      paymentMethod: PaymentMethod;
      note?: string;
      idempotencyKey: string;
    }
  ): Promise<{ debt: Debt; transaction: FinanceTransaction }> {
    return this.request(`/debts/${encodeURIComponent(debtId)}/payments`, {
      method: 'POST',
      body: JSON.stringify(input),
    });
  }

  async sendDebtReminder(
    debtId: string,
    message: string
  ): Promise<{ reminder: Debt['reminders'][number]; deliveredViaBot: boolean }> {
    return this.request(`/debts/${encodeURIComponent(debtId)}/reminders`, {
      method: 'POST',
      body: JSON.stringify({ message }),
    });
  }

  // Customers
  async getCustomers(): Promise<Customer[]> {
    return this.request('/customers');
  }

  async createCustomer(input: Omit<Customer, 'id' | 'createdAt'>): Promise<Customer> {
    return this.request('/customers', {
      method: 'POST',
      body: JSON.stringify(input),
    });
  }

  async updateCustomer(id: string, input: Partial<Customer>): Promise<Customer> {
    return this.request(`/customers/${encodeURIComponent(id)}`, {
      method: 'PATCH',
      body: JSON.stringify(input),
    });
  }

  // Sales
  async getSales(): Promise<Sale[]> {
    return this.request('/sales');
  }

  async createSale(input: {
    customerId: string;
    branchId: string;
    items: Array<{ productId: string; quantity: number; unitPrice: number }>;
    discountAmount: number;
    paidAmount: number;
    paymentMethod: PaymentMethod;
    dueDate?: string;
    idempotencyKey: string;
  }): Promise<{ sale: Sale; debt?: Debt }> {
    return this.request('/sales', {
      method: 'POST',
      body: JSON.stringify(input),
    });
  }

  // Products
  async getProducts(): Promise<Product[]> {
    return this.request('/products');
  }

  async createProduct(input: Omit<Product, 'id' | 'status'>): Promise<Product> {
    return this.request('/products', {
      method: 'POST',
      body: JSON.stringify(input),
    });
  }

  async updateProduct(id: string, input: Partial<Product>): Promise<Product> {
    return this.request(`/products/${encodeURIComponent(id)}`, {
      method: 'PATCH',
      body: JSON.stringify(input),
    });
  }

  // AI Intelligence
  async sendAiChat(question: string, contextPayload?: Record<string, unknown>): Promise<AIChatMessage> {
    return this.request('/ai/chat', {
      method: 'POST',
      body: JSON.stringify({ question, context: contextPayload }),
    });
  }

  async getAiInsights(): Promise<{ insights: AIInsightCard[]; generatedAt: string }> {
    return this.request('/ai/insights');
  }

  async getAiForecasts(): Promise<{ forecasts: AIForecastItem[] }> {
    return this.request('/ai/forecasts');
  }

  async approveAiAction(actionId: string): Promise<{ status: string; message: string }> {
    return this.request(`/ai/actions/${encodeURIComponent(actionId)}/approve`, {
      method: 'POST',
    });
  }

  // Branches, Employees, Notifications, Settings
  async getBranches(): Promise<Branch[]> {
    return this.request('/branches');
  }

  async createBranch(input: Omit<Branch, 'id' | 'status'>): Promise<Branch> {
    return this.request('/branches', { method: 'POST', body: JSON.stringify(input) });
  }

  async getEmployees(): Promise<Employee[]> {
    return this.request('/employees');
  }

  async createEmployee(input: Omit<Employee, 'id' | 'status' | 'lastActiveAt'>): Promise<Employee> {
    return this.request('/employees', { method: 'POST', body: JSON.stringify(input) });
  }

  async getNotifications(): Promise<AppNotification[]> {
    return this.request('/notifications');
  }

  async markNotificationRead(id: string): Promise<AppNotification> {
    return this.request(`/notifications/${encodeURIComponent(id)}/read`, { method: 'PATCH' });
  }

  async getSettings(): Promise<BusinessSettings> {
    return this.request('/settings');
  }

  async updateSettings(input: Partial<BusinessSettings>): Promise<BusinessSettings> {
    return this.request('/settings', { method: 'PATCH', body: JSON.stringify(input) });
  }
}

export const apiClient = new NasiyaApiClient();

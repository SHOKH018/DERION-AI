import type {
  BusinessHealthAssessment,
  DateRangePreset,
  Debt,
  DebtStatus,
  FinanceTransaction,
  FinancialSummary,
  PermissionKey,
  Product,
  Sale,
  SaleItem,
  UserRole,
} from '../types/domain.ts';

/**
 * Format numeric amount into Uzbekistan So'm format: e.g., 1 250 000 so‘m
 */
export function formatUZS(amount: number): string {
  const safe = Number.isFinite(amount) ? Math.round(amount) : 0;
  const sign = safe < 0 ? '-' : '';
  const absStr = Math.abs(safe)
    .toString()
    .replace(/\B(?=(\d{3})+(?!\d))/g, ' ');
  return `${sign}${absStr} so‘m`;
}

/**
 * Compact format for chart axes (e.g., 12.5 mln, 450 ming)
 */
export function formatCompactUZS(amount: number): string {
  const abs = Math.abs(amount);
  const sign = amount < 0 ? '-' : '';
  if (abs >= 1_000_000_000) {
    return `${sign}${(abs / 1_000_000_000).toFixed(1)} mlrd`;
  }
  if (abs >= 1_000_000) {
    return `${sign}${(abs / 1_000_000).toFixed(1)} mln`;
  }
  if (abs >= 1_000) {
    return `${sign}${Math.round(abs / 1_000)} ming`;
  }
  return `${sign}${Math.round(abs)}`;
}

/**
 * Format ISO date string in Asia/Tashkent timezone using DD.MM.YYYY
 */
export function formatDateUZ(isoDate: string, includeTime = false): string {
  if (!isoDate) return '—';
  const d = new Date(isoDate);
  if (Number.isNaN(d.getTime())) return '—';
  const options: Intl.DateTimeFormatOptions = {
    timeZone: 'Asia/Tashkent',
    day: '2-digit',
    month: '2-digit',
    year: 'numeric',
    ...(includeTime ? { hour: '2-digit', minute: '2-digit', hour12: false } : {}),
  };
  return new Intl.DateTimeFormat('ru-RU', options).format(d);
}

/**
 * Check whether an ISO date falls within the requested preset window relative to nowIso
 */
export function isWithinDateRange(
  isoDate: string,
  preset: DateRangePreset,
  nowIso: string = new Date().toISOString()
): boolean {
  if (preset === 'all') return true;
  const target = new Date(isoDate).getTime();
  const now = new Date(nowIso).getTime();
  if (Number.isNaN(target) || Number.isNaN(now)) return true;

  const dayMs = 24 * 60 * 60 * 1000;
  if (preset === 'today') {
    const tStr = new Intl.DateTimeFormat('en-CA', { timeZone: 'Asia/Tashkent' }).format(new Date(target));
    const nStr = new Intl.DateTimeFormat('en-CA', { timeZone: 'Asia/Tashkent' }).format(new Date(now));
    return tStr === nStr;
  }
  const days = preset === '7d' ? 7 : preset === '30d' ? 30 : 90;
  return target >= now - days * dayMs;
}

export interface SaleCalculationInput {
  items: Array<{
    productId: string;
    productName: string;
    quantity: number;
    unitPrice: number;
    purchasePrice: number;
  }>;
  discountAmount: number;
  paidAmount: number;
}

export interface SaleCalculationResult {
  items: SaleItem[];
  subtotal: number;
  discountAmount: number;
  totalAmount: number;
  cogsTotal: number;
  paidAmount: number;
  debtAmount: number;
  paymentStatus: 'To‘langan' | 'Qisman' | 'Nasiya';
}

/**
 * Deterministic sale accounting calculator.
 * Enforces:
 * - subtotal = sum(qty * unitPrice)
 * - totalAmount = subtotal - discount (cannot be negative)
 * - paidAmount cannot exceed totalAmount
 * - debtAmount = totalAmount - paidAmount
 */
export function calculateSaleTotals(input: SaleCalculationInput): SaleCalculationResult {
  if (!input.items.length) {
    throw new Error('Kamida bitta mahsulot tanlanishi shart.');
  }

  let subtotal = 0;
  let cogsTotal = 0;
  const normalizedItems: SaleItem[] = input.items.map((item) => {
    if (!Number.isFinite(item.quantity) || item.quantity <= 0) {
      throw new Error(`"${item.productName}" miqdori 0 dan katta bo‘lishi kerak.`);
    }
    if (!Number.isFinite(item.unitPrice) || item.unitPrice < 0) {
      throw new Error(`"${item.productName}" narxi manfiy bo‘lishi mumkin emas.`);
    }
    const lineTotal = Math.round(item.quantity * item.unitPrice);
    const lineCogs = Math.round(item.quantity * Math.max(0, item.purchasePrice));
    subtotal += lineTotal;
    cogsTotal += lineCogs;
    return {
      productId: item.productId,
      productName: item.productName,
      quantity: item.quantity,
      unitPrice: Math.round(item.unitPrice),
      purchasePrice: Math.round(Math.max(0, item.purchasePrice)),
      lineTotal,
    };
  });

  const discount = Math.round(input.discountAmount || 0);
  if (discount < 0) {
    throw new Error('Chegirma manfiy bo‘lishi mumkin emas.');
  }
  if (discount > subtotal) {
    throw new Error('Chegirma savdo summasidan katta bo‘lishi mumkin emas.');
  }

  const totalAmount = subtotal - discount;
  const paidAmount = Math.round(input.paidAmount || 0);
  if (paidAmount < 0) {
    throw new Error('To‘lov summasi manfiy bo‘lishi mumkin emas.');
  }
  if (paidAmount > totalAmount) {
    throw new Error('Boshlang‘ich to‘lov jami savdo summasidan oshib ketishi mumkin emas.');
  }

  const debtAmount = totalAmount - paidAmount;
  const paymentStatus: SaleCalculationResult['paymentStatus'] =
    debtAmount === 0 ? 'To‘langan' : paidAmount > 0 ? 'Qisman' : 'Nasiya';

  return {
    items: normalizedItems,
    subtotal,
    discountAmount: discount,
    totalAmount,
    cogsTotal,
    paidAmount,
    debtAmount,
    paymentStatus,
  };
}

/**
 * Compute deterministic debt status given balances and due date.
 */
export function resolveDebtStatus(
  remainingAmount: number,
  paidAmount: number,
  dueDateIso: string,
  nowIso: string = new Date().toISOString()
): DebtStatus {
  if (remainingAmount <= 0) {
    return 'To‘langan';
  }
  const dueMs = new Date(dueDateIso).getTime();
  const nowMs = new Date(nowIso).getTime();
  if (!Number.isNaN(dueMs) && !Number.isNaN(nowMs) && dueMs < nowMs) {
    return 'Muddati o‘tgan';
  }
  if (paidAmount > 0) {
    return 'Qisman to‘langan';
  }
  return 'Faol';
}

/**
 * Apply a debt repayment deterministically with strict overpayment guard.
 * Note: A debt repayment NEVER creates new sales revenue.
 */
export function applyDebtPayment(
  debt: Pick<Debt, 'originalAmount' | 'paidAmount' | 'remainingAmount' | 'dueDate'>,
  paymentAmount: number,
  nowIso: string = new Date().toISOString()
): { paidAmount: number; remainingAmount: number; status: DebtStatus } {
  const cleanAmount = Math.round(paymentAmount);
  if (!Number.isFinite(cleanAmount) || cleanAmount <= 0) {
    throw new Error('To‘lov summasi 0 dan katta bo‘lishi shart.');
  }
  if (debt.remainingAmount <= 0) {
    throw new Error('Ushbu qarz allaqachon to‘liq yopilgan.');
  }
  if (cleanAmount > debt.remainingAmount) {
    throw new Error(
      `To‘lov summasi qolgan qarzdan (${formatUZS(debt.remainingAmount)}) oshib ketishi mumkin emas.`
    );
  }

  const nextPaid = debt.paidAmount + cleanAmount;
  const nextRemaining = debt.remainingAmount - cleanAmount;
  const nextStatus = resolveDebtStatus(nextRemaining, nextPaid, debt.dueDate, nowIso);

  return {
    paidAmount: nextPaid,
    remainingAmount: nextRemaining,
    status: nextStatus,
  };
}

/**
 * Deterministic Financial Summary Calculator.
 * Accounting Rules enforced:
 * 1. Sales Revenue = sum(sale.totalAmount). Debt repayments NEVER inflate sales revenue.
 * 2. Debt Collections = sum(transaction.amount where type === 'Qarz undiruvi').
 * 3. Total Cash Inflow = Initial cash from sales + Debt collections + Other income.
 * 4. Net Profit = Sales Revenue - COGS - Operating Expenses (never Cash In minus Cash Out).
 */
export function computeFinancialSummary(params: {
  sales: Sale[];
  debts: Debt[];
  transactions: FinanceTransaction[];
  products: Product[];
  branchId?: string;
  dateRange?: DateRangePreset;
  nowIso?: string;
}): FinancialSummary {
  const {
    sales,
    debts,
    transactions,
    products,
    branchId = 'all',
    dateRange = 'all',
    nowIso = new Date().toISOString(),
  } = params;

  const branchMatch = (bId: string) => branchId === 'all' || bId === branchId;

  const filteredSales = sales.filter(
    (s) => branchMatch(s.branchId) && isWithinDateRange(s.createdAt, dateRange, nowIso)
  );
  const filteredTransactions = transactions.filter(
    (t) => branchMatch(t.branchId) && isWithinDateRange(t.date, dateRange, nowIso)
  );
  const filteredDebts = debts.filter((d) => branchMatch(d.branchId));
  const filteredProducts = products.filter((p) => branchMatch(p.branchId));

  let totalSalesRevenue = 0;
  let initialCashFromSales = 0;
  let totalCOGS = 0;

  for (const sale of filteredSales) {
    totalSalesRevenue += sale.totalAmount;
    initialCashFromSales += sale.paidAmount;
    totalCOGS += sale.cogsTotal;
  }

  let debtCollections = 0;
  let otherIncome = 0;
  let operatingExpenses = 0;
  let cashPayments = 0;
  let cardPayments = 0;
  let transferPayments = 0;

  for (const tx of filteredTransactions) {
    if (tx.type === 'Qarz undiruvi') {
      debtCollections += tx.amount;
    } else if (tx.type === 'Boshqa kirim') {
      otherIncome += tx.amount;
    } else if (tx.type === 'Xarajat') {
      operatingExpenses += tx.amount;
    }

    if (tx.type !== 'Xarajat') {
      if (tx.paymentMethod === 'Naqd') cashPayments += tx.amount;
      else if (tx.paymentMethod === 'Karta') cardPayments += tx.amount;
      else transferPayments += tx.amount;
    }
  }

  // Total cash receipts = initial payments on sales + subsequent debt repayments + other cash income
  const totalCashInflow = initialCashFromSales + debtCollections + otherIncome;
  // Accrual-aligned Net Profit = Sales Revenue - Cost of Goods Sold - Operating Expenses
  const netProfit = totalSalesRevenue - totalCOGS - operatingExpenses;

  let outstandingDebt = 0;
  let overdueDebt = 0;
  let totalOriginalDebt = 0;
  const activeDebtorIds = new Set<string>();

  for (const debt of filteredDebts) {
    totalOriginalDebt += debt.originalAmount;
    if (debt.remainingAmount > 0) {
      outstandingDebt += debt.remainingAmount;
      activeDebtorIds.add(debt.customerId);
      const status = resolveDebtStatus(debt.remainingAmount, debt.paidAmount, debt.dueDate, nowIso);
      if (status === 'Muddati o‘tgan') {
        overdueDebt += debt.remainingAmount;
      }
    }
  }

  let inventoryValuation = 0;
  for (const p of filteredProducts) {
    inventoryValuation += Math.max(0, p.quantity) * Math.max(0, p.purchasePrice);
  }

  return {
    totalSalesRevenue,
    initialCashFromSales,
    debtCollections,
    otherIncome,
    totalCashInflow,
    totalCOGS,
    operatingExpenses,
    netProfit,
    cashPayments,
    cardPayments,
    transferPayments,
    outstandingDebt,
    overdueDebt,
    totalOriginalDebt,
    activeDebtorsCount: activeDebtorIds.size,
    inventoryValuation,
  };
}

/**
 * Deterministic Heuristic Business Health Indicator.
 * Explicitly marked as a heuristic indicator, NOT a verified credit or financial rating.
 */
export function computeBusinessHealthHeuristic(
  summary: FinancialSummary,
  products: Product[]
): BusinessHealthAssessment {
  let score = 70;
  const strengths: string[] = [];
  const weaknesses: string[] = [];
  const recommendations: string[] = [];

  const profitMargin =
    summary.totalSalesRevenue > 0 ? summary.netProfit / summary.totalSalesRevenue : 0;
  const overdueRatio =
    summary.outstandingDebt > 0 ? summary.overdueDebt / summary.outstandingDebt : 0;
  const collectionRatio =
    summary.totalSalesRevenue > 0 ? summary.totalCashInflow / summary.totalSalesRevenue : 1;
  const lowStockCount = products.filter((p) => p.quantity <= p.minStockLevel).length;

  if (profitMargin >= 0.2) {
    score += 12;
    strengths.push(`Sof foyda marjasi barqaror (${Math.round(profitMargin * 100)}%).`);
  } else if (profitMargin > 0) {
    score += 4;
    strengths.push(`Biznes ijobiy foyda bilan ishlamoqda (${Math.round(profitMargin * 100)}%).`);
  } else if (summary.totalSalesRevenue > 0) {
    score -= 18;
    weaknesses.push('Xarajatlar va tannarx savdo daromadidan yuqori.');
    recommendations.push('Operatsion xarajatlar va mahsulot ustama narxlarini qayta ko‘rib chiqing.');
  }

  if (overdueRatio <= 0.15) {
    score += 10;
    strengths.push('Muddati o‘tgan qarzlar ulushi nazorat ostida.');
  } else if (overdueRatio <= 0.35) {
    score -= 8;
    weaknesses.push(
      `Qolgan qarzning ${Math.round(overdueRatio * 100)}% qismi muddati o‘tgan holatda.`
    );
    recommendations.push('Muddati o‘tgan qarzdorlarga Telegram eslatmalarini yuboring.');
  } else {
    score -= 18;
    weaknesses.push(
      `Yuqori xavf: muddati o‘tgan qarzlar ulushi ${Math.round(overdueRatio * 100)}% ga yetgan.`
    );
    recommendations.push('Yangi nasiya savdolarini vaqtincha cheklab, undiruvga ustuvorlik bering.');
  }

  if (collectionRatio >= 0.75) {
    score += 6;
    strengths.push('Pul tushumi va kassa aylanmasi yaxshi muvozanatda.');
  } else if (summary.totalSalesRevenue > 0) {
    score -= 6;
    weaknesses.push('Nasiya ulushi yuqoriligi sabab naqd pul oqimi sekinlashgan.');
    recommendations.push('Nasiya savdolarda kamida 30% boshlang‘ich to‘lov talabini qo‘llang.');
  }

  if (lowStockCount === 0) {
    score += 2;
  } else {
    score -= Math.min(8, lowStockCount * 2);
    weaknesses.push(`${lowStockCount} ta mahsulot minimal qoldiq darajasidan pastga tushgan.`);
    recommendations.push('Ombor bo‘limida kam qolgan mahsulotlarga qayta buyurtma bering.');
  }

  const boundedScore = Math.max(15, Math.min(98, Math.round(score)));
  const label =
    boundedScore >= 80
      ? 'Barqaror holat (Evristik)'
      : boundedScore >= 60
      ? 'O‘rtacha holat (Evristik)'
      : 'Diqqat talab (Evristik)';

  if (recommendations.length === 0) {
    recommendations.push('Joriy moliyaviy intizomni saqlang va haftalik hisobotlarni kuzatib boring.');
  }

  return {
    score: boundedScore,
    isHeuristic: true,
    label,
    methodology:
      'Ushbu ko‘rsatkich sof foyda marjasi (35%), muddati o‘tgan qarz ulushi (35%), pul tushumi nisbati (20%) va ombor qoldig‘i holati (10%) asosida hisoblangan ichki evristik indikator bo‘lib, rasmiy kredit yoki moliyaviy reyting hisoblanmaydi.',
    strengths,
    weaknesses,
    recommendations,
  };
}

/**
 * Role-Based Access Control (RBAC) Permission Matrix
 */
const ROLE_PERMISSIONS: Record<UserRole, PermissionKey[]> = {
  Owner: [
    'view_dashboard',
    'view_ai',
    'approve_ai_actions',
    'view_finance',
    'create_transaction',
    'view_debts',
    'create_debt',
    'accept_payment',
    'send_reminder',
    'view_customers',
    'manage_customers',
    'export_customers',
    'view_sales',
    'create_sale',
    'view_inventory',
    'manage_inventory',
    'view_analytics',
    'view_reports',
    'export_reports',
    'view_branches',
    'manage_branches',
    'view_employees',
    'manage_employees',
    'view_notifications',
    'view_settings',
    'manage_settings',
  ],
  Admin: [
    'view_dashboard',
    'view_ai',
    'approve_ai_actions',
    'view_finance',
    'create_transaction',
    'view_debts',
    'create_debt',
    'accept_payment',
    'send_reminder',
    'view_customers',
    'manage_customers',
    'export_customers',
    'view_sales',
    'create_sale',
    'view_inventory',
    'manage_inventory',
    'view_analytics',
    'view_reports',
    'export_reports',
    'view_branches',
    'view_employees',
    'manage_employees',
    'view_notifications',
    'view_settings',
  ],
  Seller: [
    'view_dashboard',
    'view_debts',
    'create_debt',
    'accept_payment',
    'send_reminder',
    'view_customers',
    'manage_customers',
    'view_sales',
    'create_sale',
    'view_inventory',
    'view_notifications',
  ],
  Accountant: [
    'view_dashboard',
    'view_ai',
    'view_finance',
    'create_transaction',
    'view_debts',
    'accept_payment',
    'view_customers',
    'export_customers',
    'view_sales',
    'view_inventory',
    'view_analytics',
    'view_reports',
    'export_reports',
    'view_branches',
    'view_notifications',
  ],
};

export function hasPermission(role: UserRole, permission: PermissionKey): boolean {
  return ROLE_PERMISSIONS[role]?.includes(permission) ?? false;
}

import test from 'node:test';
import assert from 'node:assert/strict';
import crypto from 'node:crypto';
import { verifyTelegramInitData } from './telegramAuth.ts';

function buildSignedInitData(
  paramsObj: Record<string, string>,
  botToken: string
): string {
  const entries = Object.entries(paramsObj)
    .sort(([a], [b]) => a.localeCompare(b))
    .map(([k, v]) => `${k}=${v}`);
  const dataCheckString = entries.join('\n');
  const secretKey = crypto.createHmac('sha256', 'WebAppData').update(botToken).digest();
  const hash = crypto.createHmac('sha256', secretKey).update(dataCheckString).digest('hex');
  const qs = new URLSearchParams({ ...paramsObj, hash });
  return qs.toString();
}

test('verifyTelegramInitData accepts validly signed initData within expiry', () => {
  const token = '123456:TEST_BOT_TOKEN_EXAMPLE';
  const now = 1_795_674_500;
  const initData = buildSignedInitData(
    {
      auth_date: String(now - 60),
      query_id: 'AAHdF6IQAAAAAN0XohDhrOrc',
      user: JSON.stringify({ id: 987654321, first_name: 'Jahongir', username: 'jahongir_uz' }),
    },
    token
  );

  const result = verifyTelegramInitData(initData, token, 86400, now);
  assert.equal(result.valid, true);
  assert.equal(result.user?.id, 987654321);
  assert.equal(result.user?.first_name, 'Jahongir');
});

test('verifyTelegramInitData rejects tampered user payload', () => {
  const token = '123456:TEST_BOT_TOKEN_EXAMPLE';
  const now = 1_795_674_500;
  const initData = buildSignedInitData(
    {
      auth_date: String(now - 60),
      user: JSON.stringify({ id: 987654321, first_name: 'Jahongir' }),
    },
    token
  );

  const tampered = initData.replace('987654321', '111111111');
  const result = verifyTelegramInitData(tampered, token, 86400, now);
  assert.equal(result.valid, false);
});

test('verifyTelegramInitData rejects expired auth_date', () => {
  const token = '123456:TEST_BOT_TOKEN_EXAMPLE';
  const now = 1_795_674_500;
  const initData = buildSignedInitData(
    {
      auth_date: String(now - 90000),
      user: JSON.stringify({ id: 987654321, first_name: 'Jahongir' }),
    },
    token
  );

  const result = verifyTelegramInitData(initData, token, 86400, now);
  assert.equal(result.valid, false);
  assert.match(result.reason ?? '', /muddati tugagan/);
});

import crypto from 'node:crypto';

export interface VerifiedTelegramUser {
  id: number;
  first_name: string;
  last_name?: string;
  username?: string;
  language_code?: string;
}

export interface TelegramVerifyResult {
  valid: boolean;
  reason?: string;
  user?: VerifiedTelegramUser;
  authDate?: number;
}

/**
 * Cryptographically verifies Telegram Mini App `initData` per official Telegram documentation:
 * 1. Parse URL-encoded params, extract `hash`.
 * 2. Sort remaining key=value pairs alphabetically joined with `\n` (`data_check_string`).
 * 3. Derive secret_key = HMAC_SHA256(key="WebAppData", msg=botToken).
 * 4. Compute expected_hash = HMAC_SHA256(key=secret_key, msg=data_check_string) hex.
 * 5. Compare with timingSafeEqual and validate `auth_date` freshness (default 24h).
 */
export function verifyTelegramInitData(
  initData: string,
  botToken: string,
  maxAgeSeconds = 86400,
  nowUnixSeconds: number = Math.floor(Date.now() / 1000)
): TelegramVerifyResult {
  if (!initData || typeof initData !== 'string') {
    return { valid: false, reason: 'initData bo‘sh yoki noto‘g‘ri formatda.' };
  }
  if (!botToken || typeof botToken !== 'string') {
    return { valid: false, reason: 'Serverda TELEGRAM_BOT_TOKEN sozlanmagan.' };
  }

  const params = new URLSearchParams(initData);
  const hash = params.get('hash');
  if (!hash || !/^[a-f0-9]{64}$/i.test(hash)) {
    return { valid: false, reason: 'Telegram imzosi (hash) topilmadi yoki yaroqsiz.' };
  }

  const authDateRaw = params.get('auth_date');
  const authDate = authDateRaw ? Number(authDateRaw) : NaN;
  if (!Number.isFinite(authDate) || authDate <= 0) {
    return { valid: false, reason: 'auth_date maydoni yaroqsiz.' };
  }
  if (nowUnixSeconds - authDate > maxAgeSeconds) {
    return { valid: false, reason: 'Telegram sessiyasi muddati tugagan. Mini Appni qayta oching.' };
  }

  const entries: string[] = [];
  params.forEach((value, key) => {
    if (key !== 'hash') {
      entries.push(`${key}=${value}`);
    }
  });
  entries.sort((a, b) => a.localeCompare(b));
  const dataCheckString = entries.join('\n');

  const secretKey = crypto.createHmac('sha256', 'WebAppData').update(botToken).digest();
  const computedHash = crypto
    .createHmac('sha256', secretKey)
    .update(dataCheckString)
    .digest('hex');

  const hashBuf = Buffer.from(hash.toLowerCase(), 'utf8');
  const computedBuf = Buffer.from(computedHash.toLowerCase(), 'utf8');
  if (hashBuf.length !== computedBuf.length || !crypto.timingSafeEqual(hashBuf, computedBuf)) {
    return { valid: false, reason: 'Telegram initData kriptografik tekshiruvdan o‘tmadi.' };
  }

  const userJson = params.get('user');
  if (!userJson) {
    return { valid: false, reason: 'Foydalanuvchi ma’lumoti (user) mavjud emas.' };
  }

  try {
    const parsedUser = JSON.parse(userJson) as VerifiedTelegramUser;
    if (!parsedUser || typeof parsedUser.id !== 'number') {
      return { valid: false, reason: 'Telegram foydalanuvchi ID yaroqsiz.' };
    }
    return {
      valid: true,
      user: parsedUser,
      authDate,
    };
  } catch {
    return { valid: false, reason: 'Telegram user JSON ma’lumotini o‘qib bo‘lmadi.' };
  }
}

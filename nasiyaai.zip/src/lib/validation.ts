import { z } from 'zod';

const uzPhoneRegex = /^\+998[\s-]?\d{2}[\s-]?\d{3}[\s-]?\d{2}[\s-]?\d{2}$/;

export const phoneSchema = z
  .string()
  .trim()
  .refine((val) => uzPhoneRegex.test(val) || val.replace(/\D/g, '').length >= 9, {
    message: 'Telefon raqamni +998 90 123 45 67 ko‘rinishida kiriting.',
  });

export const transactionSchema = z.object({
  amount: z.number().positive('Summa 0 dan katta bo‘lishi kerak.'),
  category: z.string().trim().min(2, 'Kategoriya tanlang.'),
  description: z.string().trim().min(3, 'Izoh kamida 3 ta belgidan iborat bo‘lsin.'),
  date: z.string().min(1, 'Sana tanlang.'),
  type: z.enum(['Boshqa kirim', 'Xarajat']),
  paymentMethod: z.enum(['Naqd', 'Karta', 'O‘tkazma']),
  branchId: z.string().min(1, 'Filial tanlang.'),
});

export const createDebtSchema = z.object({
  customerMode: z.enum(['existing', 'new']),
  customerId: z.string().optional(),
  newCustomerName: z.string().optional(),
  newCustomerPhone: z.string().optional(),
  amount: z.number().positive('Qarz summasi 0 dan katta bo‘lishi kerak.'),
  initialPayment: z.number().min(0, 'Boshlang‘ich to‘lov manfiy bo‘lishi mumkin emas.'),
  description: z.string().trim().min(3, 'Izoh kiriting.'),
  date: z.string().min(1, 'Sana kiriting.'),
  dueDate: z.string().min(1, 'Qaytarish muddatini tanlang.'),
  paymentMethod: z.enum(['Naqd', 'Karta', 'O‘tkazma']),
  branchId: z.string().min(1, 'Filial tanlang.'),
  notes: z.string().optional(),
});

export const debtPaymentSchema = z.object({
  amount: z.number().positive('To‘lov summasi 0 dan katta bo‘lishi shart.'),
  paymentMethod: z.enum(['Naqd', 'Karta', 'O‘tkazma']),
  note: z.string().optional(),
});

export const customerSchema = z.object({
  fullName: z.string().trim().min(2, 'Mijoz ismi kamida 2 ta harf bo‘lishi kerak.'),
  phone: phoneSchema,
  address: z.string().optional(),
  notes: z.string().optional(),
  branchId: z.string().min(1, 'Filial tanlang.'),
  status: z.enum(['Faol', 'Kuzatuvda', 'Ishonchli']),
});

export const productSchema = z.object({
  name: z.string().trim().min(2, 'Mahsulot nomi kamida 2 ta belgidan iborat bo‘lsin.'),
  sku: z.string().trim().min(2, 'SKU kodini kiriting.'),
  category: z.string().trim().min(2, 'Kategoriyani kiriting.'),
  purchasePrice: z.number().min(0, 'Xarid narxi manfiy bo‘lmasligi kerak.'),
  sellingPrice: z.number().positive('Sotuv narxi 0 dan katta bo‘lishi kerak.'),
  quantity: z.number().int('Miqdor butun son bo‘lishi kerak.').min(0, 'Miqdor manfiy bo‘lmasligi kerak.'),
  minStockLevel: z.number().int().min(0, 'Minimal qoldiq manfiy bo‘lmasligi kerak.'),
  branchId: z.string().min(1, 'Filial tanlang.'),
});

export const branchSchema = z.object({
  name: z.string().trim().min(2, 'Filial nomi kiriting.'),
  address: z.string().trim().min(3, 'Manzil kiriting.'),
  managerName: z.string().trim().min(2, 'Mas’ul rahbar ismini kiriting.'),
  phone: phoneSchema,
  monthlyTargetUzs: z.number().min(0),
});

export const employeeSchema = z.object({
  fullName: z.string().trim().min(2, 'Xodim F.I.Sh. kiriting.'),
  phone: phoneSchema,
  role: z.enum(['Owner', 'Admin', 'Seller', 'Accountant']),
  branchId: z.string().min(1, 'Filial tanlang.'),
});

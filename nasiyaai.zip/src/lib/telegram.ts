export interface TelegramThemeParams {
  bg_color?: string;
  text_color?: string;
  hint_color?: string;
  link_color?: string;
  button_color?: string;
  button_text_color?: string;
  secondary_bg_color?: string;
}

export interface TelegramWebApp {
  initData: string;
  initDataUnsafe?: {
    user?: {
      id: number;
      first_name: string;
      last_name?: string;
      username?: string;
      language_code?: string;
    };
    auth_date?: number;
  };
  version?: string;
  platform?: string;
  colorScheme?: 'light' | 'dark';
  themeParams?: TelegramThemeParams;
  isExpanded?: boolean;
  viewportHeight?: number;
  viewportStableHeight?: number;
  BackButton?: {
    isVisible: boolean;
    show: () => void;
    hide: () => void;
    onClick: (cb: () => void) => void;
    offClick: (cb: () => void) => void;
  };
  MainButton?: {
    text: string;
    isVisible: boolean;
    isActive: boolean;
    show: () => void;
    hide: () => void;
    setText: (text: string) => void;
    onClick: (cb: () => void) => void;
    offClick: (cb: () => void) => void;
  };
  ready: () => void;
  expand: () => void;
  close: () => void;
  onEvent?: (eventType: string, callback: () => void) => void;
  offEvent?: (eventType: string, callback: () => void) => void;
}

declare global {
  interface Window {
    Telegram?: {
      WebApp?: TelegramWebApp;
    };
  }
}

export interface TelegramEnvironmentInfo {
  isTelegramWebApp: boolean;
  hasInitData: boolean;
  initData: string;
  platform: string;
  version: string;
  colorScheme: 'light' | 'dark';
  viewportStableHeight: number | null;
}

export function getTelegramWebApp(): TelegramWebApp | null {
  if (typeof window === 'undefined') return null;
  return window.Telegram?.WebApp ?? null;
}

export function initTelegramMiniApp(): TelegramEnvironmentInfo {
  const tg = getTelegramWebApp();
  if (!tg || (!tg.initData && tg.platform === undefined)) {
    return {
      isTelegramWebApp: false,
      hasInitData: false,
      initData: '',
      platform: 'web',
      version: '0',
      colorScheme: 'light',
      viewportStableHeight: null,
    };
  }

  try {
    tg.ready();
    tg.expand();
  } catch {
    // Ignore SDK errors when stubbed in desktop browsers
  }

  const hasInitData = Boolean(tg.initData && tg.initData.trim().length > 0);

  return {
    isTelegramWebApp: hasInitData || (Boolean(tg.platform) && tg.platform !== 'unknown'),
    hasInitData,
    initData: tg.initData || '',
    platform: tg.platform || 'telegram',
    version: tg.version || '7.0',
    colorScheme: tg.colorScheme === 'dark' ? 'dark' : 'light',
    viewportStableHeight: typeof tg.viewportStableHeight === 'number' ? tg.viewportStableHeight : null,
  };
}

export function setTelegramBackButton(visible: boolean, onBack?: () => void): () => void {
  const tg = getTelegramWebApp();
  if (!tg?.BackButton) return () => {};
  try {
    if (visible && onBack) {
      tg.BackButton.onClick(onBack);
      tg.BackButton.show();
      return () => {
        try {
          tg.BackButton?.offClick(onBack);
          tg.BackButton?.hide();
        } catch {
          // ignore
        }
      };
    } else {
      tg.BackButton.hide();
    }
  } catch {
    // ignore
  }
  return () => {};
}

export function setTelegramMainButton(
  config: { visible: boolean; text?: string; onClick?: () => void }
): () => void {
  const tg = getTelegramWebApp();
  if (!tg?.MainButton) return () => {};
  try {
    if (config.visible && config.text && config.onClick) {
      tg.MainButton.setText(config.text);
      tg.MainButton.onClick(config.onClick);
      tg.MainButton.show();
      return () => {
        try {
          tg.MainButton?.offClick(config.onClick!);
          tg.MainButton?.hide();
        } catch {
          // ignore
        }
      };
    } else {
      tg.MainButton.hide();
    }
  } catch {
    // ignore
  }
  return () => {};
}

import test from 'node:test';
import assert from 'node:assert/strict';
import {
  applyDebtPayment,
  calculateSaleTotals,
  computeBusinessHealthHeuristic,
  computeFinancialSummary,
  formatUZS,
  hasPermission,
  resolveDebtStatus,
} from './accounting.ts';
import type { Debt, FinanceTransaction, Product, Sale } from '../types/domain.ts';

test('formatUZS formats integers with space separators and so‘m suffix', () => {
  assert.equal(formatUZS(1250000), '1 250 000 so‘m');
  assert.equal(formatUZS(0), '0 so‘m');
  assert.equal(formatUZS(-50000), '-50 000 so‘m');
});

test('Accounting Rule: 10M credit sale with 2M initial payment + 3M subsequent debt repayment', () => {
  // Step 1: 10,000,000 UZS sale (COGS = 7,000,000 UZS), 2,000,000 UZS paid immediately -> 8,000,000 UZS debt
  const saleCalc = calculateSaleTotals({
    items: [
      {
        productId: 'p1',
        productName: 'Samsung Galaxy A55',
        quantity: 2,
        unitPrice: 5_000_000,
        purchasePrice: 3_500_000,
      },
    ],
    discountAmount: 0,
    paidAmount: 2_000_000,
  });

  assert.equal(saleCalc.totalAmount, 10_000_000);
  assert.equal(saleCalc.cogsTotal, 7_000_000);
  assert.equal(saleCalc.paidAmount, 2_000_000);
  assert.equal(saleCalc.debtAmount, 8_000_000);
  assert.equal(saleCalc.paymentStatus, 'Qisman');

  const sale: Sale = {
    id: 'sale-1',
    customerId: 'c1',
    customerName: 'Azizbek',
    branchId: 'b1',
    items: saleCalc.items,
    subtotal: saleCalc.subtotal,
    discountAmount: 0,
    totalAmount: saleCalc.totalAmount,
    cogsTotal: saleCalc.cogsTotal,
    paidAmount: saleCalc.paidAmount,
    debtAmount: saleCalc.debtAmount,
    paymentMethod: 'Naqd',
    paymentStatus: saleCalc.paymentStatus,
    sellerName: 'Sardor',
    createdAt: '2026-11-20T10:00:00.000Z',
  };

  // Step 2: Subsequent repayment of 3,000,000 UZS
  const debtBefore: Debt = {
    id: 'debt-1',
    saleId: 'sale-1',
    customerId: 'c1',
    customerName: 'Azizbek',
    customerPhone: '+998901234567',
    branchId: 'b1',
    description: 'Samsung Galaxy A55 nasiya',
    originalAmount: 8_000_000,
    paidAmount: 0,
    remainingAmount: 8_000_000,
    createdAt: '2026-11-20T10:00:00.000Z',
    dueDate: '2026-12-20T10:00:00.000Z',
    status: 'Faol',
    payments: [],
    reminders: [],
  };

  const repayment = applyDebtPayment(debtBefore, 3_000_000, '2026-11-25T10:00:00.000Z');
  assert.equal(repayment.paidAmount, 3_000_000);
  assert.equal(repayment.remainingAmount, 5_000_000);
  assert.equal(repayment.status, 'Qisman to‘langan');

  const debtAfter: Debt = {
    ...debtBefore,
    paidAmount: repayment.paidAmount,
    remainingAmount: repayment.remainingAmount,
    status: repayment.status,
  };

  const transactions: FinanceTransaction[] = [
    {
      id: 'tx-1',
      date: '2026-11-20T10:00:00.000Z',
      description: 'Savdo #sale-1 boshlang‘ich to‘lov',
      category: 'Savdo',
      type: 'Savdo tushumi',
      paymentMethod: 'Naqd',
      amount: 2_000_000,
      branchId: 'b1',
      status: 'Tasdiqlangan',
    },
    {
      id: 'tx-2',
      date: '2026-11-25T10:00:00.000Z',
      description: 'Qarz to‘lovi #debt-1',
      category: 'Qarz undiruvi',
      type: 'Qarz undiruvi',
      paymentMethod: 'Karta',
      amount: 3_000_000,
      branchId: 'b1',
      status: 'Tasdiqlangan',
    },
    {
      id: 'tx-3',
      date: '2026-11-25T12:00:00.000Z',
      description: 'Do‘kon ijarasi',
      category: 'Ijara',
      type: 'Xarajat',
      paymentMethod: 'O‘tkazma',
      amount: 1_000_000,
      branchId: 'b1',
      status: 'Tasdiqlangan',
    },
  ];

  const products: Product[] = [
    {
      id: 'p1',
      name: 'Samsung Galaxy A55',
      sku: 'SAM-A55',
      category: 'Smartfonlar',
      purchasePrice: 3_500_000,
      sellingPrice: 5_000_000,
      quantity: 5,
      minStockLevel: 2,
      branchId: 'b1',
      status: 'Mavjud',
    },
  ];

  const summary = computeFinancialSummary({
    sales: [sale],
    debts: [debtAfter],
    transactions,
    products,
    nowIso: '2026-11-25T15:00:00.000Z',
  });

  // CRITICAL: 3,000,000 repayment is NOT new sales revenue!
  assert.equal(summary.totalSalesRevenue, 10_000_000);
  assert.equal(summary.initialCashFromSales, 2_000_000);
  assert.equal(summary.debtCollections, 3_000_000);
  assert.equal(summary.totalCashInflow, 5_000_000);
  assert.equal(summary.outstandingDebt, 5_000_000);
  // Profit = Sales Revenue (10M) - COGS (7M) - Operating Expenses (1M) = 2M (NOT cash inflow 5M - 1M = 4M!)
  assert.equal(summary.netProfit, 2_000_000);
});

test('applyDebtPayment rejects overpayments and non-positive amounts', () => {
  const debt = {
    originalAmount: 1_000_000,
    paidAmount: 400_000,
    remainingAmount: 600_000,
    dueDate: '2026-12-01T00:00:00.000Z',
  };

  assert.throws(() => applyDebtPayment(debt, 600_001), /oshib ketishi mumkin emas/);
  assert.throws(() => applyDebtPayment(debt, 0), /0 dan katta/);
  assert.throws(() => applyDebtPayment(debt, -100), /0 dan katta/);
});

test('resolveDebtStatus marks overdue debts accurately', () => {
  assert.equal(
    resolveDebtStatus(500_000, 0, '2026-11-01T00:00:00.000Z', '2026-11-25T00:00:00.000Z'),
    'Muddati o‘tgan'
  );
  assert.equal(
    resolveDebtStatus(0, 500_000, '2026-11-01T00:00:00.000Z', '2026-11-25T00:00:00.000Z'),
    'To‘langan'
  );
});

test('computeBusinessHealthHeuristic explicitly flags itself as heuristic', () => {
  const health = computeBusinessHealthHeuristic(
    {
      totalSalesRevenue: 20_000_000,
      initialCashFromSales: 15_000_000,
      debtCollections: 3_000_000,
      otherIncome: 0,
      totalCashInflow: 18_000_000,
      totalCOGS: 12_000_000,
      operatingExpenses: 2_000_000,
      netProfit: 6_000_000,
      cashPayments: 10_000_000,
      cardPayments: 8_000_000,
      transferPayments: 0,
      outstandingDebt: 5_000_000,
      overdueDebt: 500_000,
      totalOriginalDebt: 10_000_000,
      activeDebtorsCount: 3,
      inventoryValuation: 30_000_000,
    },
    []
  );
  assert.equal(health.isHeuristic, true);
  assert.ok(health.score >= 15 && health.score <= 98);
});

test('RBAC permissions enforce role boundaries', () => {
  assert.equal(hasPermission('Owner', 'manage_employees'), true);
  assert.equal(hasPermission('Seller', 'manage_employees'), false);
  assert.equal(hasPermission('Seller', 'create_sale'), true);
  assert.equal(hasPermission('Accountant', 'create_sale'), false);
  assert.equal(hasPermission('Accountant', 'view_reports'), true);
});

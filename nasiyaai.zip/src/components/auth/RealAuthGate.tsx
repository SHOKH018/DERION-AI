import React, { useState } from 'react';
import { AlertTriangle, KeyRound, Loader2, RefreshCw, ShieldCheck, Smartphone } from 'lucide-react';
import { useApp } from '../../context/AppContext.tsx';
import type { UserRole } from '../../types/domain.ts';
import { Button, Card, FieldLabel, Input, Select } from '../ui/Primitives.tsx';

export function RealAuthGate() {
  const {
    telegramEnv,
    telegramAuthState,
    telegramAuthError,
    retryTelegramAuth,
    needsBootstrap,
    realAuthLoading,
    realAuthError,
    bootstrapRealAdmin,
    loginRealWeb,
    setMode,
    backendCapabilities,
  } = useApp();

  const [fullName, setFullName] = useState('');
  const [shopName, setShopName] = useState('');
  const [passcode, setPasscode] = useState('');
  const [role, setRole] = useState<UserRole>('Owner');
  const [formErr, setFormErr] = useState<string | null>(null);

  const handleBootstrap = async (e: React.FormEvent) => {
    e.preventDefault();
    setFormErr(null);
    if (fullName.trim().length < 2) {
      setFormErr('Ismingizni kiriting.');
      return;
    }
    if (passcode.trim().length < 6) {
      setFormErr('Parol kamida 6 ta belgidan iborat bo‘lishi kerak.');
      return;
    }
    try {
      await bootstrapRealAdmin(passcode.trim(), fullName.trim(), shopName.trim() || 'Mening do‘konim');
    } catch {
      // handled in context
    }
  };

  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    setFormErr(null);
    if (!passcode.trim()) {
      setFormErr('Parolni kiriting.');
      return;
    }
    try {
      await loginRealWeb(passcode.trim(), role);
    } catch {
      // handled in context
    }
  };

  // Telegram Mini App explicit loading & error state
  if (telegramEnv.isTelegramWebApp && telegramEnv.hasInitData) {
    if (telegramAuthState === 'authenticating') {
      return (
        <div className="min-h-[60vh] flex items-center justify-center p-4">
          <Card className="max-w-md w-full p-6 text-center space-y-3">
            <Loader2 className="w-8 h-8 text-[#2563EB] animate-spin mx-auto" />
            <h2 className="font-display text-base font-bold text-slate-900">
              Telegram Mini App tekshirilmoqda
            </h2>
            <p className="text-xs text-slate-500 leading-relaxed">
              Telegram <span className="font-mono">initData</span> imzosi backend serverda
              kriptografik tekshiruvdan o‘tkazilmoqda...
            </p>
          </Card>
        </div>
      );
    }

    if (telegramAuthState === 'error') {
      return (
        <div className="min-h-[60vh] flex items-center justify-center p-4">
          <Card className="max-w-md w-full p-6 space-y-4">
            <div className="flex items-start gap-3">
              <div className="p-2.5 rounded-xl bg-red-50 text-red-600 shrink-0">
                <AlertTriangle className="w-5 h-5" />
              </div>
              <div>
                <h2 className="font-display text-base font-bold text-slate-900">
                  Telegram autentifikatsiyasi xatosi
                </h2>
                <p className="text-xs text-red-700 mt-1 leading-relaxed">{telegramAuthError}</p>
              </div>
            </div>
            <div className="flex flex-wrap gap-2 pt-2">
              <Button onClick={retryTelegramAuth}>
                <RefreshCw className="w-4 h-4" />
                Qayta urinish
              </Button>
              <Button variant="secondary" onClick={() => setMode('demo')}>
                Demo rejimda ko‘rish
              </Button>
            </div>
          </Card>
        </div>
      );
    }
  }

  return (
    <div className="min-h-[65vh] flex items-center justify-center p-4">
      <Card className="max-w-md w-full p-6 space-y-5">
        <div className="flex items-start justify-between gap-3">
          <div>
            <div className="flex items-center gap-2 text-xs font-semibold text-[#2563EB] mb-1">
              <ShieldCheck className="w-4 h-4" />
              <span>Real API rejimi</span>
            </div>
            <h2 className="font-display text-lg font-bold text-slate-900">
              {needsBootstrap
                ? 'Birinchi ishga tushirish: Admin sozlash'
                : 'NasiyaAI tizimiga kirish'}
            </h2>
            <p className="text-xs text-slate-500 mt-1 leading-relaxed">
              {needsBootstrap
                ? 'Tizim hali sozlanmagan. Do‘kon egasi uchun xavfsiz kirish parolini o‘rnating.'
                : 'Haqiqiy biznes ma’lumotlaringizga kirish uchun administrator parolini kiriting.'}
            </p>
          </div>
        </div>

        {(formErr || realAuthError) && (
          <div className="p-3 rounded-xl bg-red-50 border border-red-200 text-xs text-red-700 font-medium">
            {formErr || realAuthError}
          </div>
        )}

        {needsBootstrap ? (
          <form onSubmit={handleBootstrap} className="space-y-3.5">
            <div>
              <FieldLabel htmlFor="boot-fullname" required>
                Do‘kon egasining ismi
              </FieldLabel>
              <Input
                id="boot-fullname"
                value={fullName}
                onChange={(e) => setFullName(e.target.value)}
                placeholder="Masalan: Jahongir Rahimov"
              />
            </div>
            <div>
              <FieldLabel htmlFor="boot-shopname">Do‘kon nomi</FieldLabel>
              <Input
                id="boot-shopname"
                value={shopName}
                onChange={(e) => setShopName(e.target.value)}
                placeholder="Masalan: Baraka Texnika"
              />
            </div>
            <div>
              <FieldLabel htmlFor="boot-passcode" required>
                Administrator paroli (kamida 6 belgi)
              </FieldLabel>
              <Input
                id="boot-passcode"
                type="password"
                value={passcode}
                onChange={(e) => setPasscode(e.target.value)}
                placeholder="••••••••"
              />
            </div>
            <div className="flex items-center gap-2 pt-2">
              <Button type="submit" loading={realAuthLoading} className="flex-1">
                <KeyRound className="w-4 h-4" />
                Saqlash va kirish
              </Button>
              <Button type="button" variant="secondary" onClick={() => setMode('demo')}>
                Demo
              </Button>
            </div>
          </form>
        ) : (
          <form onSubmit={handleLogin} className="space-y-3.5">
            <div>
              <FieldLabel htmlFor="login-passcode" required>
                Kirish paroli
              </FieldLabel>
              <Input
                id="login-passcode"
                type="password"
                value={passcode}
                onChange={(e) => setPasscode(e.target.value)}
                placeholder="Parolingizni kiriting"
              />
            </div>
            <div>
              <FieldLabel htmlFor="login-role">Rol</FieldLabel>
              <Select
                id="login-role"
                value={role}
                onChange={(e) => setRole(e.target.value as UserRole)}
              >
                <option value="Owner">Owner (Do‘kon egasi)</option>
                <option value="Admin">Admin (Boshqaruvchi)</option>
                <option value="Seller">Seller (Sotuvchi)</option>
                <option value="Accountant">Accountant (Buxgalter)</option>
              </Select>
            </div>
            <div className="flex items-center gap-2 pt-2">
              <Button type="submit" loading={realAuthLoading} className="flex-1">
                <KeyRound className="w-4 h-4" />
                Kirish
              </Button>
              <Button type="button" variant="secondary" onClick={() => setMode('demo')}>
                Demo rejim
              </Button>
            </div>
          </form>
        )}

        <div className="pt-3 border-t border-slate-100 text-[11px] text-slate-500 space-y-1">
          <div className="flex items-center gap-1.5">
            <Smartphone className="w-3.5 h-3.5 text-slate-400" />
            <span>
              Telegram Mini App auth:{' '}
              {backendCapabilities.telegramBotConfigured
                ? 'Bot token ulangan'
                : 'TELEGRAM_BOT_TOKEN kutilmoqda'}
            </span>
          </div>
          {backendCapabilities.externalBackendUrl && (
            <div>Tashqi Python backend: {backendCapabilities.externalBackendUrl}</div>
          )}
        </div>
      </Card>
    </div>
  );
}

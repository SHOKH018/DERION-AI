import React, { useState } from 'react';
import {
  BarChart3,
  Bell,
  Bot,
  Building2,
  CreditCard,
  FileSpreadsheet,
  LayoutDashboard,
  LogOut,
  Menu,
  Package,
  Settings,
  ShoppingBag,
  Users,
  UserCheck,
  Wallet,
  X,
} from 'lucide-react';
import { useApp } from '../../context/AppContext.tsx';
import type { DateRangePreset, NavPageId, PermissionKey, UserRole } from '../../types/domain.ts';
import { DEMO_AVATAR_URL } from '../../data/demoDataset.ts';
import { Button } from '../ui/Primitives.tsx';

interface NavConfigItem {
  id: NavPageId;
  icon: React.ComponentType<{ className?: string }>;
  permission: PermissionKey;
}

const NAV_ITEMS: NavConfigItem[] = [
  { id: 'dashboard', icon: LayoutDashboard, permission: 'view_dashboard' },
  { id: 'ai', icon: Bot, permission: 'view_ai' },
  { id: 'finance', icon: Wallet, permission: 'view_finance' },
  { id: 'debts', icon: CreditCard, permission: 'view_debts' },
  { id: 'customers', icon: Users, permission: 'view_customers' },
  { id: 'sales', icon: ShoppingBag, permission: 'view_sales' },
  { id: 'inventory', icon: Package, permission: 'view_inventory' },
  { id: 'analytics', icon: BarChart3, permission: 'view_analytics' },
  { id: 'reports', icon: FileSpreadsheet, permission: 'view_reports' },
  { id: 'branches', icon: Building2, permission: 'view_branches' },
  { id: 'employees', icon: UserCheck, permission: 'view_employees' },
  { id: 'notifications', icon: Bell, permission: 'view_notifications' },
  { id: 'settings', icon: Settings, permission: 'view_settings' },
];

export function AppShell({ children }: { children: React.ReactNode }) {
  const {
    mode,
    setMode,
    activePage,
    setActivePage,
    selectedBranchId,
    setSelectedBranchId,
    dateRange,
    setDateRange,
    user,
    switchDemoRole,
    logoutReal,
    dataset,
    t,
    can,
    telegramEnv,
    setSelectedDebtId,
    setSelectedCustomerId,
  } = useApp();

  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [profileOpen, setProfileOpen] = useState(false);
  const [avatarError, setAvatarError] = useState(false);

  const unreadCount = dataset.notifications.filter((n) => !n.isRead).length;
  const visibleNavItems = NAV_ITEMS.filter((item) => !user || can(item.permission));

  const handleNavigate = (page: NavPageId) => {
    setActivePage(page);
    setSelectedDebtId(null);
    setSelectedCustomerId(null);
    setMobileMenuOpen(false);
  };

  const primaryMobileTabs: NavPageId[] = ['dashboard', 'debts', 'sales', 'ai'];

  return (
    <div className="min-h-screen bg-[#F8FAFC] text-[#0F172A] flex flex-col lg:flex-row overflow-x-hidden">
      {/* Desktop Fixed Dark Navy Sidebar */}
      <aside className="hidden lg:flex lg:flex-col lg:w-64 lg:fixed lg:inset-y-0 bg-[#0B1220] text-slate-200 border-r border-slate-800/80 z-30">
        <div className="h-16 px-5 flex items-center justify-between border-b border-slate-800/80">
          <div className="flex items-center gap-2.5 min-w-0">
            <div className="w-8 h-8 rounded-lg bg-[#2563EB] flex items-center justify-center text-white font-display font-bold text-sm shrink-0">
              N
            </div>
            <span className="font-display font-bold text-base tracking-tight text-white whitespace-nowrap truncate">
              NasiyaAI
            </span>
          </div>
        </div>

        <nav className="flex-1 overflow-y-auto px-3 py-4 space-y-0.5" aria-label="Asosiy menyu">
          {visibleNavItems.map((item) => {
            const Icon = item.icon;
            const isActive = activePage === item.id;
            return (
              <button
                key={item.id}
                type="button"
                onClick={() => handleNavigate(item.id)}
                className={`w-full flex items-center justify-between gap-3 px-3 py-2.5 rounded-[10px] text-sm font-medium transition-colors duration-150 cursor-pointer whitespace-nowrap ${
                  isActive
                    ? 'bg-[#2563EB] text-white'
                    : 'text-slate-300 hover:text-white hover:bg-slate-800/70'
                }`}
              >
                <span className="flex items-center gap-3 min-w-0">
                  <Icon className="w-4 h-4 shrink-0" />
                  <span className="truncate">{t.nav[item.id]}</span>
                </span>
                {item.id === 'notifications' && unreadCount > 0 && (
                  <span
                    className={`text-[11px] font-mono tabular-nums px-1.5 py-0.5 rounded ${
                      isActive ? 'bg-white/20 text-white' : 'bg-slate-800 text-slate-300'
                    }`}
                  >
                    {unreadCount}
                  </span>
                )}
              </button>
            );
          })}
        </nav>

        <div className="p-3 border-t border-slate-800/80 space-y-2">
          <div className="bg-slate-900/90 border border-slate-800 rounded-xl p-2.5">
            <div className="text-[11px] text-slate-400 mb-1.5 font-medium">Ish rejimi</div>
            <div className="grid grid-cols-2 gap-1 bg-slate-950 p-1 rounded-lg">
              <button
                type="button"
                onClick={() => setMode('demo')}
                className={`px-2 py-1.5 text-xs font-medium rounded-md transition-colors cursor-pointer whitespace-nowrap ${
                  mode === 'demo' ? 'bg-[#2563EB] text-white' : 'text-slate-400 hover:text-white'
                }`}
              >
                Demo
              </button>
              <button
                type="button"
                onClick={() => setMode('real')}
                className={`px-2 py-1.5 text-xs font-medium rounded-md transition-colors cursor-pointer whitespace-nowrap ${
                  mode === 'real' ? 'bg-[#2563EB] text-white' : 'text-slate-400 hover:text-white'
                }`}
              >
                Real API
              </button>
            </div>
          </div>
        </div>
      </aside>

      {/* Main Column */}
      <div className="flex-1 lg:pl-64 flex flex-col min-w-0">
        {/* Desktop Top Navigation */}
        <header className="hidden lg:flex h-16 bg-white border-b border-slate-200/90 px-6 items-center justify-between gap-6 sticky top-0 z-20">
          <div className="flex items-center gap-3 min-w-0">
            <h1 className="font-display text-lg font-bold text-slate-900 whitespace-nowrap truncate">
              {t.nav[activePage]}
            </h1>
            <span className="text-slate-300" aria-hidden="true">
              /
            </span>
            <span className="text-sm font-medium text-slate-500 whitespace-nowrap truncate">
              {dataset.settings.shopName}
            </span>
          </div>

          <div className="flex items-center gap-3 shrink-0">
            {/* Branch Selector */}
            <label htmlFor="desktop-branch-select" className="sr-only">
              Filial tanlash
            </label>
            <select
              id="desktop-branch-select"
              value={selectedBranchId}
              onChange={(e) => setSelectedBranchId(e.target.value)}
              className="h-9 rounded-lg border border-slate-200 bg-slate-50/70 px-3 text-xs font-medium text-slate-700 focus:outline-none focus:border-[#2563EB] cursor-pointer"
            >
              <option value="all">{t.common.allBranches}</option>
              {dataset.branches.map((b) => (
                <option key={b.id} value={b.id}>
                  {b.name}
                </option>
              ))}
            </select>

            {/* Date Range Filter */}
            <label htmlFor="desktop-date-range" className="sr-only">
              Sana oralig‘i
            </label>
            <select
              id="desktop-date-range"
              value={dateRange}
              onChange={(e) => setDateRange(e.target.value as DateRangePreset)}
              className="h-9 rounded-lg border border-slate-200 bg-slate-50/70 px-3 text-xs font-medium text-slate-700 focus:outline-none focus:border-[#2563EB] cursor-pointer"
            >
              <option value="today">{t.dateRanges.today}</option>
              <option value="7d">{t.dateRanges['7d']}</option>
              <option value="30d">{t.dateRanges['30d']}</option>
              <option value="90d">{t.dateRanges['90d']}</option>
              <option value="all">{t.dateRanges.all}</option>
            </select>

            {/* Notifications */}
            <button
              type="button"
              onClick={() => handleNavigate('notifications')}
              aria-label={`Bildirishnomalar (${unreadCount} ta o‘qilmagan)`}
              className="relative h-9 w-9 rounded-lg border border-slate-200 flex items-center justify-center text-slate-600 hover:text-slate-900 hover:bg-slate-50 transition-colors cursor-pointer"
            >
              <Bell className="w-4 h-4" />
              {unreadCount > 0 && (
                <span className="absolute -top-1 -right-1 min-w-[18px] h-[18px] px-1 rounded-full bg-red-600 text-white text-[10px] font-mono font-semibold flex items-center justify-center">
                  {unreadCount}
                </span>
              )}
            </button>

            {/* User Profile */}
            <div className="relative">
              <button
                type="button"
                onClick={() => setProfileOpen((p) => !p)}
                aria-expanded={profileOpen}
                aria-label="Foydalanuvchi profili"
                className="flex items-center gap-2.5 pl-2 pr-3 py-1 rounded-lg border border-slate-200 hover:bg-slate-50 transition-colors cursor-pointer"
              >
                {!avatarError ? (
                  <img
                    src={user?.avatarUrl || DEMO_AVATAR_URL}
                    alt={user?.fullName || 'Foydalanuvchi'}
                    referrerPolicy="no-referrer"
                    onError={() => setAvatarError(true)}
                    className="w-7 h-7 rounded-md object-cover bg-slate-200 shrink-0"
                  />
                ) : (
                  <div className="w-7 h-7 rounded-md bg-slate-900 text-white text-xs font-bold flex items-center justify-center shrink-0">
                    {(user?.fullName || 'N').slice(0, 1)}
                  </div>
                )}
                <div className="text-left leading-tight">
                  <div className="text-xs font-semibold text-slate-900 whitespace-nowrap">
                    {user?.fullName || 'Mehmon'}
                  </div>
                  <div className="text-[11px] text-slate-500 whitespace-nowrap">
                    {user?.role || 'Owner'}
                  </div>
                </div>
              </button>

              {profileOpen && (
                <div className="absolute right-0 mt-2 w-64 bg-white border border-slate-200 rounded-xl shadow-lg p-3 z-40 space-y-3">
                  <div className="border-b border-slate-100 pb-2">
                    <p className="text-xs font-bold text-slate-900">{user?.fullName}</p>
                    <p className="text-[11px] text-slate-500 mt-0.5">
                      {dataset.settings.shopName} · {user?.role}
                    </p>
                  </div>

                  {mode === 'demo' && (
                    <div>
                      <p className="text-[11px] font-semibold text-slate-500 mb-1.5">
                        Demo rolni sinash
                      </p>
                      <div className="grid grid-cols-2 gap-1">
                        {(['Owner', 'Admin', 'Seller', 'Accountant'] as UserRole[]).map((role) => (
                          <button
                            key={role}
                            type="button"
                            onClick={() => {
                              switchDemoRole(role);
                              setProfileOpen(false);
                            }}
                            className={`px-2 py-1 text-xs rounded-md border text-left cursor-pointer ${
                              user?.role === role
                                ? 'bg-blue-50 border-blue-200 text-blue-700 font-semibold'
                                : 'border-slate-200 text-slate-600 hover:bg-slate-50'
                            }`}
                          >
                            {role}
                          </button>
                        ))}
                      </div>
                    </div>
                  )}

                  <div className="flex items-center justify-between pt-1">
                    <Button
                      size="sm"
                      variant="ghost"
                      onClick={() => {
                        setProfileOpen(false);
                        handleNavigate('settings');
                      }}
                    >
                      Sozlamalar
                    </Button>
                    {mode === 'real' && user && (
                      <Button
                        size="sm"
                        variant="secondary"
                        onClick={() => {
                          setProfileOpen(false);
                          void logoutReal();
                        }}
                      >
                        <LogOut className="w-3.5 h-3.5" />
                        Chiqish
                      </Button>
                    )}
                  </div>
                </div>
              )}
            </div>
          </div>
        </header>

        {/* Mobile Compact Top Header (<= 52px to stay well inside 15% sticky height cap) */}
        <header className="lg:hidden sticky top-0 z-30 h-12 bg-white/95 backdrop-blur-md border-b border-slate-200 px-3.5 flex items-center justify-between gap-2 pt-tg-safe">
          <div className="flex items-center gap-2 min-w-0">
            <div className="w-7 h-7 rounded-lg bg-[#0B1220] text-white font-display font-bold text-xs flex items-center justify-center shrink-0">
              N
            </div>
            <div className="min-w-0">
              <div className="text-sm font-bold text-slate-900 truncate leading-tight">
                {t.nav[activePage]}
              </div>
              <div className="text-[11px] text-slate-500 truncate leading-tight">
                {dataset.settings.shopName}
              </div>
            </div>
          </div>

          <div className="flex items-center gap-1.5 shrink-0">
            <button
              type="button"
              onClick={() => setMode(mode === 'demo' ? 'real' : 'demo')}
              className="px-2.5 py-1 text-[11px] font-semibold rounded-md border border-slate-200 bg-slate-50 text-slate-700 whitespace-nowrap cursor-pointer"
            >
              {mode === 'demo' ? 'Demo' : 'Real API'}
            </button>
            <button
              type="button"
              onClick={() => handleNavigate('notifications')}
              aria-label={`Bildirishnomalar (${unreadCount})`}
              className="relative w-9 h-9 rounded-lg flex items-center justify-center text-slate-600 hover:bg-slate-100 cursor-pointer"
            >
              <Bell className="w-4 h-4" />
              {unreadCount > 0 && (
                <span className="absolute -top-0.5 -right-0.5 min-w-[16px] h-[16px] px-1 rounded-full bg-red-600 text-white text-[10px] font-mono font-semibold flex items-center justify-center">
                  {unreadCount}
                </span>
              )}
            </button>
          </div>
        </header>

        {/* Explicit Demo / Telegram Environment Banner (Inline, non-sticky) */}
        {mode === 'demo' ? (
          <div className="bg-amber-50/90 border-b border-amber-200/80 px-4 lg:px-6 py-1.5 flex flex-wrap items-center justify-between gap-2 text-[11px] sm:text-xs">
            <div className="text-amber-900 font-medium">
              Demo rejim faol: Ko‘rsatilayotgan raqamlar namuna sifatida berilgan.
            </div>
            <button
              type="button"
              onClick={() => setMode('real')}
              className="text-[11px] sm:text-xs font-semibold text-amber-900 underline underline-offset-2 hover:text-amber-700 whitespace-nowrap cursor-pointer"
            >
              Real API rejimiga o‘tish
            </button>
          </div>
        ) : (
          telegramEnv.isTelegramWebApp && (
            <div className="bg-blue-50/80 border-b border-blue-200/80 px-4 lg:px-6 py-1.5 flex items-center justify-between text-xs text-blue-900">
              <span>Telegram Mini App muhiti aniqlandi ({telegramEnv.platform})</span>
              <span className="font-mono text-[11px]">Asia/Tashkent · UZS</span>
            </div>
          )
        )}

        {/* Main Content Viewport */}
        <main className="flex-1 p-4 lg:p-6 pb-20 lg:pb-8 max-w-[1440px] w-full mx-auto">
          {children}
        </main>
      </div>

      {/* Mobile Bottom Navigation Bar (56px height) */}
      <nav
        aria-label="Mobil navigatsiya"
        className="lg:hidden fixed bottom-0 left-0 right-0 z-30 bg-white/95 backdrop-blur-md border-t border-slate-200 pb-tg-safe"
      >
        <div className="grid grid-cols-5 h-14 items-center">
          {primaryMobileTabs.map((tabId) => {
            const item = NAV_ITEMS.find((i) => i.id === tabId)!;
            const Icon = item.icon;
            const active = activePage === tabId;
            return (
              <button
                key={tabId}
                type="button"
                onClick={() => handleNavigate(tabId)}
                className={`flex flex-col items-center justify-center gap-0.5 h-full min-h-[44px] cursor-pointer ${
                  active ? 'text-[#2563EB]' : 'text-slate-500'
                }`}
              >
                <Icon className="w-5 h-5" />
                <span className="text-[10px] font-medium truncate max-w-[64px]">
                  {tabId === 'dashboard'
                    ? 'Asosiy'
                    : tabId === 'ai'
                    ? 'AI'
                    : t.nav[tabId]}
                </span>
              </button>
            );
          })}
          <button
            type="button"
            onClick={() => setMobileMenuOpen(true)}
            aria-label="Barcha bo‘limlar menyusi"
            className={`flex flex-col items-center justify-center gap-0.5 h-full min-h-[44px] cursor-pointer ${
              !primaryMobileTabs.includes(activePage) ? 'text-[#2563EB]' : 'text-slate-500'
            }`}
          >
            <Menu className="w-5 h-5" />
            <span className="text-[10px] font-medium">Bo‘limlar</span>
          </button>
        </div>
      </nav>

      {/* Mobile Full Sections Drawer */}
      {mobileMenuOpen && (
        <div
          className="lg:hidden fixed inset-0 z-50 bg-slate-950/50 backdrop-blur-[2px] flex items-end"
          role="dialog"
          aria-modal="true"
          aria-label="Bo‘limlar menyusi"
        >
          <div className="w-full bg-white rounded-t-2xl max-h-[82vh] flex flex-col overflow-hidden">
            <div className="px-4 py-3 border-b border-slate-100 flex items-center justify-between">
              <span className="font-display font-bold text-sm text-slate-900">
                Barcha bo‘limlar
              </span>
              <button
                type="button"
                onClick={() => setMobileMenuOpen(false)}
                aria-label="Menyuni yopish"
                className="p-2 rounded-lg text-slate-500 hover:bg-slate-100 cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>
            </div>
            <div className="p-3 overflow-y-auto grid grid-cols-2 gap-2">
              {visibleNavItems.map((item) => {
                const Icon = item.icon;
                const active = activePage === item.id;
                return (
                  <button
                    key={item.id}
                    type="button"
                    onClick={() => handleNavigate(item.id)}
                    className={`flex items-center gap-2.5 px-3 py-3 rounded-xl border text-left text-xs font-medium min-h-[44px] cursor-pointer ${
                      active
                        ? 'bg-blue-50 border-blue-200 text-[#2563EB] font-semibold'
                        : 'bg-white border-slate-200 text-slate-700'
                    }`}
                  >
                    <Icon className="w-4 h-4 shrink-0" />
                    <span className="truncate">{t.nav[item.id]}</span>
                  </button>
                );
              })}
            </div>
            <div className="p-3 border-t border-slate-100 grid grid-cols-2 gap-2 bg-slate-50">
              <select
                aria-label="Filial"
                value={selectedBranchId}
                onChange={(e) => setSelectedBranchId(e.target.value)}
                className="rounded-lg border border-slate-200 bg-white px-2.5 py-2 text-xs text-slate-800"
              >
                <option value="all">{t.common.allBranches}</option>
                {dataset.branches.map((b) => (
                  <option key={b.id} value={b.id}>
                    {b.name}
                  </option>
                ))}
              </select>
              <select
                aria-label="Davr"
                value={dateRange}
                onChange={(e) => setDateRange(e.target.value as DateRangePreset)}
                className="rounded-lg border border-slate-200 bg-white px-2.5 py-2 text-xs text-slate-800"
              >
                <option value="today">{t.dateRanges.today}</option>
                <option value="7d">{t.dateRanges['7d']}</option>
                <option value="30d">{t.dateRanges['30d']}</option>
                <option value="90d">{t.dateRanges['90d']}</option>
                <option value="all">{t.dateRanges.all}</option>
              </select>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

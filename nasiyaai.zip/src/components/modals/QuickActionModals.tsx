import React, { useState } from 'react';
import { useApp } from '../../context/AppContext.tsx';
import { formatUZS } from '../../lib/accounting.ts';
import {
  createDebtSchema,
  customerSchema,
  debtPaymentSchema,
  transactionSchema,
} from '../../lib/validation.ts';
import type { PaymentMethod } from '../../types/domain.ts';
import { Button, FieldLabel, Input, Modal, Select } from '../ui/Primitives.tsx';

export function QuickActionModals() {
  const {
    quickModal,
    setQuickModal,
    dataset,
    createDebt,
    acceptDebtPayment,
    saveCustomer,
    createTransaction,
  } = useApp();

  const defaultBranch = dataset.branches[0]?.id || 'br-main';
  const unpaidDebts = dataset.debts.filter((d) => d.remainingAmount > 0);

  // Debt Form State
  const [customerMode, setCustomerMode] = useState<'existing' | 'new'>('existing');
  const [customerId, setCustomerId] = useState(dataset.customers[0]?.id || '');
  const [newCustomerName, setNewCustomerName] = useState('');
  const [newCustomerPhone, setNewCustomerPhone] = useState('+998 ');
  const [debtAmount, setDebtAmount] = useState('');
  const [initialPayment, setInitialPayment] = useState('0');
  const [debtDesc, setDebtDesc] = useState('');
  const [dueDate, setDueDate] = useState('2026-12-25');
  const [debtMethod, setDebtMethod] = useState<PaymentMethod>('Naqd');
  const [debtBranch, setDebtBranch] = useState(defaultBranch);

  // Payment Form State
  const [payDebtId, setPayDebtId] = useState(unpaidDebts[0]?.id || '');
  const [payAmount, setPayAmount] = useState('');
  const [payMethod, setPayMethod] = useState<PaymentMethod>('Naqd');
  const [payNote, setPayNote] = useState('');

  // Customer Form State
  const [custName, setCustName] = useState('');
  const [custPhone, setCustPhone] = useState('+998 ');
  const [custAddress, setCustAddress] = useState('');
  const [custNotes, setCustNotes] = useState('');
  const [custBranch, setCustBranch] = useState(defaultBranch);

  // Expense Form State
  const [expAmount, setExpAmount] = useState('');
  const [expCategory, setExpCategory] = useState('Ijara');
  const [expDesc, setExpDesc] = useState('');
  const [expMethod, setExpMethod] = useState<PaymentMethod>('Naqd');
  const [expBranch, setExpBranch] = useState(defaultBranch);

  const [submitting, setSubmitting] = useState(false);
  const [errorMsg, setErrorMsg] = useState<string | null>(null);

  const closeModal = () => {
    setErrorMsg(null);
    setQuickModal('none');
  };

  const handleDebtSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMsg(null);
    const parsed = createDebtSchema.safeParse({
      customerMode,
      customerId: customerMode === 'existing' ? customerId || dataset.customers[0]?.id : undefined,
      newCustomerName,
      newCustomerPhone,
      amount: Number(debtAmount),
      initialPayment: Number(initialPayment || 0),
      description: debtDesc,
      date: new Date().toISOString(),
      dueDate: new Date(dueDate).toISOString(),
      paymentMethod: debtMethod,
      branchId: debtBranch || defaultBranch,
    });
    if (!parsed.success) {
      setErrorMsg(parsed.error.issues[0]?.message || 'Maydonlarni tekshiring.');
      return;
    }
    if (customerMode === 'existing' && !parsed.data.customerId) {
      setErrorMsg('Avval mijoz tanlang yoki "Yangi mijoz" bo‘limidan kiriting.');
      return;
    }
    if (
      customerMode === 'new' &&
      (!newCustomerName.trim() || newCustomerPhone.replace(/\D/g, '').length < 9)
    ) {
      setErrorMsg('Yangi mijoz ismi va telefon raqamini kiriting.');
      return;
    }
    if (parsed.data.initialPayment >= parsed.data.amount) {
      setErrorMsg('Boshlang‘ich to‘lov jami qarz summasidan kichik bo‘lishi kerak.');
      return;
    }
    setSubmitting(true);
    try {
      await createDebt(parsed.data);
      setDebtAmount('');
      setInitialPayment('0');
      setDebtDesc('');
      closeModal();
    } catch (err) {
      setErrorMsg(err instanceof Error ? err.message : 'Xatolik yuz berdi.');
    } finally {
      setSubmitting(false);
    }
  };

  const handlePaymentSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMsg(null);
    const targetId = payDebtId || unpaidDebts[0]?.id;
    const targetDebt = unpaidDebts.find((d) => d.id === targetId);
    if (!targetDebt) {
      setErrorMsg('To‘lov uchun faol qarz tanlanmadi.');
      return;
    }
    const parsed = debtPaymentSchema.safeParse({
      amount: Number(payAmount),
      paymentMethod: payMethod,
      note: payNote,
    });
    if (!parsed.success) {
      setErrorMsg(parsed.error.issues[0]?.message || 'Summani tekshiring.');
      return;
    }
    if (parsed.data.amount > targetDebt.remainingAmount) {
      setErrorMsg(
        `To‘lov qolgan qarzdan (${formatUZS(targetDebt.remainingAmount)}) oshib ketishi mumkin emas.`
      );
      return;
    }
    setSubmitting(true);
    try {
      await acceptDebtPayment(targetDebt.id, {
        ...parsed.data,
        idempotencyKey: `pay-${targetDebt.id}-${Date.now()}`,
      });
      setPayAmount('');
      setPayNote('');
      closeModal();
    } catch (err) {
      setErrorMsg(err instanceof Error ? err.message : 'Xatolik yuz berdi.');
    } finally {
      setSubmitting(false);
    }
  };

  const handleCustomerSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMsg(null);
    const parsed = customerSchema.safeParse({
      fullName: custName,
      phone: custPhone,
      address: custAddress,
      notes: custNotes,
      branchId: custBranch || defaultBranch,
      status: 'Faol',
    });
    if (!parsed.success) {
      setErrorMsg(parsed.error.issues[0]?.message || 'Mijoz ma’lumotlarini tekshiring.');
      return;
    }
    setSubmitting(true);
    try {
      await saveCustomer(parsed.data);
      setCustName('');
      setCustPhone('+998 ');
      setCustAddress('');
      setCustNotes('');
      closeModal();
    } catch (err) {
      setErrorMsg(err instanceof Error ? err.message : 'Xatolik yuz berdi.');
    } finally {
      setSubmitting(false);
    }
  };

  const handleExpenseSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMsg(null);
    const parsed = transactionSchema.safeParse({
      amount: Number(expAmount),
      category: expCategory,
      description: expDesc,
      date: new Date().toISOString(),
      type: 'Xarajat',
      paymentMethod: expMethod,
      branchId: expBranch || defaultBranch,
    });
    if (!parsed.success) {
      setErrorMsg(parsed.error.issues[0]?.message || 'Xarajat ma’lumotlarini tekshiring.');
      return;
    }
    setSubmitting(true);
    try {
      await createTransaction(parsed.data);
      setExpAmount('');
      setExpDesc('');
      closeModal();
    } catch (err) {
      setErrorMsg(err instanceof Error ? err.message : 'Xatolik yuz berdi.');
    } finally {
      setSubmitting(false);
    }
  };

  const activePayDebt = unpaidDebts.find((d) => d.id === (payDebtId || unpaidDebts[0]?.id));

  return (
    <>
      <Modal
        open={quickModal === 'debt'}
        onClose={closeModal}
        title="Yangi qarz qo‘shish"
        subtitle="Mijoz va to‘lov muddatini kiriting"
      >
        <form onSubmit={handleDebtSubmit} className="space-y-3.5">
          {errorMsg && (
            <div className="p-3 rounded-lg bg-red-50 border border-red-200 text-xs text-red-700">
              {errorMsg}
            </div>
          )}
          <div className="flex gap-1 p-1 bg-slate-100 rounded-lg">
            <button
              type="button"
              onClick={() => setCustomerMode('existing')}
              className={`flex-1 py-1.5 text-xs font-medium rounded-md cursor-pointer ${
                customerMode === 'existing' ? 'bg-white text-slate-900 shadow-sm' : 'text-slate-600'
              }`}
            >
              Mavjud mijoz
            </button>
            <button
              type="button"
              onClick={() => setCustomerMode('new')}
              className={`flex-1 py-1.5 text-xs font-medium rounded-md cursor-pointer ${
                customerMode === 'new' ? 'bg-white text-slate-900 shadow-sm' : 'text-slate-600'
              }`}
            >
              Yangi mijoz
            </button>
          </div>

          {customerMode === 'existing' ? (
            <div>
              <FieldLabel htmlFor="qd-customer" required>
                Mijoz
              </FieldLabel>
              <Select
                id="qd-customer"
                value={customerId || dataset.customers[0]?.id || ''}
                onChange={(e) => setCustomerId(e.target.value)}
              >
                {dataset.customers.length === 0 && <option value="">Mijozlar mavjud emas</option>}
                {dataset.customers.map((c) => (
                  <option key={c.id} value={c.id}>
                    {c.fullName} ({c.phone})
                  </option>
                ))}
              </Select>
            </div>
          ) : (
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <div>
                <FieldLabel htmlFor="qd-new-name" required>
                  Mijoz ismi
                </FieldLabel>
                <Input
                  id="qd-new-name"
                  value={newCustomerName}
                  onChange={(e) => setNewCustomerName(e.target.value)}
                  placeholder="Ismi familiyasi"
                />
              </div>
              <div>
                <FieldLabel htmlFor="qd-new-phone" required>
                  Telefon
                </FieldLabel>
                <Input
                  id="qd-new-phone"
                  value={newCustomerPhone}
                  onChange={(e) => setNewCustomerPhone(e.target.value)}
                  placeholder="+998 90 123 45 67"
                />
              </div>
            </div>
          )}

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <div>
              <FieldLabel htmlFor="qd-amount" required>
                Qarz summasi (so‘m)
              </FieldLabel>
              <Input
                id="qd-amount"
                type="number"
                min="1"
                value={debtAmount}
                onChange={(e) => setDebtAmount(e.target.value)}
                placeholder="1 500 000"
              />
            </div>
            <div>
              <FieldLabel htmlFor="qd-init-pay">Boshlang‘ich to‘lov (so‘m)</FieldLabel>
              <Input
                id="qd-init-pay"
                type="number"
                min="0"
                value={initialPayment}
                onChange={(e) => setInitialPayment(e.target.value)}
              />
            </div>
          </div>

          <div>
            <FieldLabel htmlFor="qd-desc" required>
              Izoh / Tovar nomi
            </FieldLabel>
            <Input
              id="qd-desc"
              value={debtDesc}
              onChange={(e) => setDebtDesc(e.target.value)}
              placeholder="Masalan: Smartfon bo‘lib to‘lash shartnomasi"
            />
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
            <div>
              <FieldLabel htmlFor="qd-due" required>
                Qaytarish muddati
              </FieldLabel>
              <Input
                id="qd-due"
                type="date"
                value={dueDate}
                onChange={(e) => setDueDate(e.target.value)}
              />
            </div>
            <div>
              <FieldLabel htmlFor="qd-method">To‘lov usuli</FieldLabel>
              <Select
                id="qd-method"
                value={debtMethod}
                onChange={(e) => setDebtMethod(e.target.value as PaymentMethod)}
              >
                <option value="Naqd">Naqd</option>
                <option value="Karta">Karta</option>
                <option value="O‘tkazma">O‘tkazma</option>
              </Select>
            </div>
            <div>
              <FieldLabel htmlFor="qd-branch">Filial</FieldLabel>
              <Select
                id="qd-branch"
                value={debtBranch}
                onChange={(e) => setDebtBranch(e.target.value)}
              >
                {dataset.branches.map((b) => (
                  <option key={b.id} value={b.id}>
                    {b.name}
                  </option>
                ))}
              </Select>
            </div>
          </div>

          <div className="flex justify-end gap-2 pt-2">
            <Button variant="secondary" onClick={closeModal}>
              Bekor qilish
            </Button>
            <Button type="submit" loading={submitting}>
              Saqlash
            </Button>
          </div>
        </form>
      </Modal>

      <Modal
        open={quickModal === 'payment'}
        onClose={closeModal}
        title="Qarz to‘lovini qabul qilish"
        subtitle="To‘lov savdo tushumiga qo‘shilmaydi, faqat qarz qoldig‘ini kamaytiradi"
      >
        <form onSubmit={handlePaymentSubmit} className="space-y-3.5">
          {errorMsg && (
            <div className="p-3 rounded-lg bg-red-50 border border-red-200 text-xs text-red-700">
              {errorMsg}
            </div>
          )}
          <div>
            <FieldLabel htmlFor="qp-debt" required>
              Qarzdor va shartnoma
            </FieldLabel>
            <Select
              id="qp-debt"
              value={payDebtId || unpaidDebts[0]?.id || ''}
              onChange={(e) => setPayDebtId(e.target.value)}
            >
              {unpaidDebts.length === 0 && <option value="">Faol qarzlar mavjud emas</option>}
              {unpaidDebts.map((d) => (
                <option key={d.id} value={d.id}>
                  {d.customerName} — Qolgan: {formatUZS(d.remainingAmount)}
                </option>
              ))}
            </Select>
          </div>
          {activePayDebt && (
            <div className="p-3 rounded-xl bg-slate-50 border border-slate-200 flex items-center justify-between text-xs">
              <span className="text-slate-600">Qolgan qarz qoldig‘i:</span>
              <span className="font-mono font-bold text-slate-900 tabular-nums">
                {formatUZS(activePayDebt.remainingAmount)}
              </span>
            </div>
          )}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <div>
              <FieldLabel htmlFor="qp-amount" required>
                To‘lov summasi (so‘m)
              </FieldLabel>
              <Input
                id="qp-amount"
                type="number"
                min="1"
                value={payAmount}
                onChange={(e) => setPayAmount(e.target.value)}
                placeholder="1 000 000"
              />
            </div>
            <div>
              <FieldLabel htmlFor="qp-method">To‘lov usuli</FieldLabel>
              <Select
                id="qp-method"
                value={payMethod}
                onChange={(e) => setPayMethod(e.target.value as PaymentMethod)}
              >
                <option value="Naqd">Naqd</option>
                <option value="Karta">Karta</option>
                <option value="O‘tkazma">O‘tkazma</option>
              </Select>
            </div>
          </div>
          <div>
            <FieldLabel htmlFor="qp-note">Izoh</FieldLabel>
            <Input
              id="qp-note"
              value={payNote}
              onChange={(e) => setPayNote(e.target.value)}
              placeholder="Qisman to‘lov izohi"
            />
          </div>
          <div className="flex justify-end gap-2 pt-2">
            <Button variant="secondary" onClick={closeModal}>
              Bekor qilish
            </Button>
            <Button type="submit" loading={submitting} disabled={unpaidDebts.length === 0}>
              To‘lovni tasdiqlash
            </Button>
          </div>
        </form>
      </Modal>

      <Modal open={quickModal === 'customer'} onClose={closeModal} title="Yangi mijoz qo‘shish">
        <form onSubmit={handleCustomerSubmit} className="space-y-3.5">
          {errorMsg && (
            <div className="p-3 rounded-lg bg-red-50 border border-red-200 text-xs text-red-700">
              {errorMsg}
            </div>
          )}
          <div>
            <FieldLabel htmlFor="qc-name" required>
              F.I.Sh.
            </FieldLabel>
            <Input
              id="qc-name"
              value={custName}
              onChange={(e) => setCustName(e.target.value)}
              placeholder="Masalan: Akmaljon Karimov"
            />
          </div>
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <div>
              <FieldLabel htmlFor="qc-phone" required>
                Telefon raqam
              </FieldLabel>
              <Input
                id="qc-phone"
                value={custPhone}
                onChange={(e) => setCustPhone(e.target.value)}
                placeholder="+998 90 123 45 67"
              />
            </div>
            <div>
              <FieldLabel htmlFor="qc-branch">Filial</FieldLabel>
              <Select
                id="qc-branch"
                value={custBranch}
                onChange={(e) => setCustBranch(e.target.value)}
              >
                {dataset.branches.map((b) => (
                  <option key={b.id} value={b.id}>
                    {b.name}
                  </option>
                ))}
              </Select>
            </div>
          </div>
          <div>
            <FieldLabel htmlFor="qc-address">Manzil</FieldLabel>
            <Input
              id="qc-address"
              value={custAddress}
              onChange={(e) => setCustAddress(e.target.value)}
              placeholder="Tuman, ko‘cha"
            />
          </div>
          <div>
            <FieldLabel htmlFor="qc-notes">Izoh</FieldLabel>
            <Input
              id="qc-notes"
              value={custNotes}
              onChange={(e) => setCustNotes(e.target.value)}
              placeholder="Mijoz haqida qo‘shimcha eslatma"
            />
          </div>
          <div className="flex justify-end gap-2 pt-2">
            <Button variant="secondary" onClick={closeModal}>
              Bekor qilish
            </Button>
            <Button type="submit" loading={submitting}>
              Saqlash
            </Button>
          </div>
        </form>
      </Modal>

      <Modal open={quickModal === 'expense'} onClose={closeModal} title="Yangi xarajat qo‘shish">
        <form onSubmit={handleExpenseSubmit} className="space-y-3.5">
          {errorMsg && (
            <div className="p-3 rounded-lg bg-red-50 border border-red-200 text-xs text-red-700">
              {errorMsg}
            </div>
          )}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <div>
              <FieldLabel htmlFor="qe-amount" required>
                Xarajat summasi (so‘m)
              </FieldLabel>
              <Input
                id="qe-amount"
                type="number"
                min="1"
                value={expAmount}
                onChange={(e) => setExpAmount(e.target.value)}
                placeholder="500 000"
              />
            </div>
            <div>
              <FieldLabel htmlFor="qe-cat" required>
                Kategoriya
              </FieldLabel>
              <Select
                id="qe-cat"
                value={expCategory}
                onChange={(e) => setExpCategory(e.target.value)}
              >
                <option value="Ijara">Ijara</option>
                <option value="Ish haqi">Ish haqi</option>
                <option value="Logistika">Logistika</option>
                <option value="Kommunal">Kommunal</option>
                <option value="Marketing">Marketing</option>
                <option value="Boshqa">Boshqa</option>
              </Select>
            </div>
          </div>
          <div>
            <FieldLabel htmlFor="qe-desc" required>
              Tavsif
            </FieldLabel>
            <Input
              id="qe-desc"
              value={expDesc}
              onChange={(e) => setExpDesc(e.target.value)}
              placeholder="Xarajat maqsadi"
            />
          </div>
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <div>
              <FieldLabel htmlFor="qe-method">To‘lov usuli</FieldLabel>
              <Select
                id="qe-method"
                value={expMethod}
                onChange={(e) => setExpMethod(e.target.value as PaymentMethod)}
              >
                <option value="Naqd">Naqd</option>
                <option value="Karta">Karta</option>
                <option value="O‘tkazma">O‘tkazma</option>
              </Select>
            </div>
            <div>
              <FieldLabel htmlFor="qe-branch">Filial</FieldLabel>
              <Select
                id="qe-branch"
                value={expBranch}
                onChange={(e) => setExpBranch(e.target.value)}
              >
                {dataset.branches.map((b) => (
                  <option key={b.id} value={b.id}>
                    {b.name}
                  </option>
                ))}
              </Select>
            </div>
          </div>
          <div className="flex justify-end gap-2 pt-2">
            <Button variant="secondary" onClick={closeModal}>
              Bekor qilish
            </Button>
            <Button type="submit" loading={submitting}>
              Saqlash
            </Button>
          </div>
        </form>
      </Modal>
    </>
  );
}

# NasiyaAI — AI Biznes Boshqaruvi va Nasiya Platformasi (Telegram Mini App + Web Dashboard)

**NasiyaAI** — O‘zbekiston kichik va o‘rta bizneslari uchun mo‘ljallangan Telegram Mini App va veb-boshqaruv paneli. Platforma kredit (nasiya) savdolar, mijozlar bazasi, qarz to‘lovlari, moliya, ombor, filiallar, xodimlar va AI biznes tahlilini yagona tizimda birlashtiradi.

- **Asosiy til:** O‘zbek (lotin), qo‘shimcha `ru` / `en` lokalizatsiya tuzilmasi (`src/i18n/translations.ts`).
- **Valyuta:** UZS (`so‘m`), **Vaqt mintaqasi:** `Asia/Tashkent`.

---

## 1. O‘rnatish va ishga tushirish

```bash
npm install
cp .env.example .env
npm run dev
```

Ilova `http://localhost:3000` manzilida ishga tushadi (Express backend API + Vite React frontend).

Ishlab chiqarish (production) uchun yig‘ish va ishga tushirish:

```bash
npm run build
NODE_ENV=production npm start
```

---

## 2. Muhit o‘zgaruvchilari (`.env.example`)

Hech qachon maxfiy kalitlarni (`TELEGRAM_BOT_TOKEN`, `GEMINI_API_KEY`, `SESSION_SECRET`) `VITE_` prefiksi bilan bermang yoki frontend kodiga joylashtirmang.

| O‘zgaruvchi | Vazifasi |
| :--- | :--- |
| `GEMINI_API_KEY` | Backend `/api/ai/chat` orqali Gemini AI tahlili uchun server kaliti |
| `APP_URL` | Ilova joylashgan asosiy URL |
| `TELEGRAM_BOT_TOKEN` | Backendda `initData` HMAC-SHA256 imzosini tekshirish uchun bot tokeni |
| `EXTERNAL_BACKEND_API_URL` | Mavjud Python FastAPI + aiogram 3 backendining asosiy URL manzili |
| `VITE_API_BASE_URL` | Frontend API mijozi murojaat qiladigan manzil (standart: `/api`) |
| `ADMIN_BOOTSTRAP_PASSCODE` | Veb-panelga kirish uchun ixtiyoriy server paroli |

---

## 3. Mavjud Python Telegram Bot (aiogram 3) bilan integratsiya

1. **BotFather orqali Mini App ulash:**
   - `@BotFather` da `/setmenubutton` yoki inline `WebAppInfo(url="https://sizning-domeningiz")` orqali Mini App URL manzilini kiriting.
2. **Kriptografik `initData` autentifikatsiyasi:**
   - Mini App ochilganda `window.Telegram.WebApp.initData` satri `POST /api/auth/telegram` endpointiga yuboriladi.
   - Backend `src/lib/telegramAuth.ts` algoritmi (`HMAC-SHA256("WebAppData", bot_token)` + `auth_date` muddati) bo‘yicha imzoni tekshiradi.
   - **Muhim:** Frontend `initDataUnsafe` ma’lumotiga hech qachon ishonmang.
3. **Python FastAPI + PostgreSQL ga ulash:**
   - `.env` faylida `VITE_API_BASE_URL=https://api.sizning-backend.uz/api/v1` qilib ko‘rsating.
   - `src/services/apiClient.ts` da barcha REST endpointlar shartnomasi tayyorlangan.
   - Agar mavjud Python botingiz Google Sheets bilan ishlayotgan bo‘lsa, FastAPI servis qatlami orqali bir xil REST JSON shartnomasini taqdim eting yoki bosqichma-bosqich PostgreSQL ga migratsiya qiling.

---

## 4. Funksional imkoniyatlar va Backend integratsiyasi holati

### To‘liq ishlayotgan modullar (Frontend + Mahalliy Express API)
- **Bosh sahifa (`DashboardPage`):** 6 ta KPI karta, Recharts grafiklari, tezkor amallar, eng yirik qarzdorlar.
- **Deterministik Buxgalteriya (`src/lib/accounting.ts`):** Savdo daromadi (`Jami savdo`) va qarz undiruvi (`Undirilgan qarz`) qat’iy ajratilgan; sof foyda COGS va operatsion xarajatlar asosida hisoblanadi; ortiqcha to‘lov (overpayment) va takroriy yuborish (idempotencyKey) bloklanadi.
- **Qarzlar (`DebtsPage`), Mijozlar (`CustomersPage`), Savdo (`SalesPage`), Ombor (`InventoryPage`), Moliya (`FinancePage`):** To‘liq CRUD, qisman to‘lovlar, qoldiq kamayishi, filtrlar va CSV eksport.
- **AI Intelligence (`AiIntelligencePage`):** Evristik Business Doctor ko‘rsatkichi (rasmiy kredit reytingi emasligi aniq ko‘rsatilgan), Kunlik brifing, Anomaliyalar, O‘zbek tilida AI Chat (`/api/ai/chat`), Prognozlar (taxminiy ekanligi belgilangan) va tasdiq talab qiluvchi Harakatlar Markazi.
- **Telegram Mini App SDK (`src/lib/telegram.ts`):** `ready()`, `expand()`, `BackButton`, safe-area qo‘llab-quvvatlashi.
- **RBAC (Rollar):** `Owner`, `Admin`, `Seller`, `Accountant` rollari ham UI da, ham Express backend middleware orqali tekshiriladi.

### Tashqi Python Bot / DB / To‘lov tizimlari bilan yakunlanishi kerak bo‘lgan qismlar
- **Haqiqiy Telegram Bot xabarlari (`POST /api/debts/{id}/reminders`):** Hozirda eslatma jurnalga yoziladi; haqiqiy mijozga Telegram xabar jo‘natish uchun Python `aiogram 3` botining webhook/queue servisiga ulanadi.
- **Doimiy PostgreSQL ma’lumotlar bazasi:** Mahalliy Express server hozirda tezkor operativ xotira (in-memory) store dan foydalanadi; ishlab chiqarishda PostgreSQL (yoki Supabase) bilan almashtirilishi lozim.
- **Payme / Click / Uzum to‘lov provayderlari:** Sozlamalarda status ko‘rsatiladi; real to‘lov qabul qilish uchun server tomonida webhook va merchant ID kalitlari ulanishi kerak.

---

## 5. Testlar va sifat nazorati

```bash
npx --yes tsx --test src/lib/accounting.test.ts
npx --yes tsx --test src/lib/telegramAuth.test.ts
npm run lint
npm run build
```

import express from 'express';
import type { Request, Response, NextFunction } from 'express';
import crypto from 'node:crypto';
import fs from 'node:fs';
import path from 'node:path';
import dotenv from 'dotenv';
import { GoogleGenAI, Type } from '@google/genai';
import {
  applyDebtPayment,
  calculateSaleTotals,
  computeBusinessHealthHeuristic,
  computeFinancialSummary,
  formatUZS,
  hasPermission,
  resolveDebtStatus,
} from './src/lib/accounting.ts';
import { verifyTelegramInitData } from './src/lib/telegramAuth.ts';
import type {
  AuthUser,
  BusinessDataset,
  Debt,
  FinanceTransaction,
  PermissionKey,
  Product,
  Sale,
  UserRole,
} from './src/types/domain.ts';

dotenv.config();

const PORT = Number(process.env.PORT || 3000);
const NODE_ENV = process.env.NODE_ENV || 'development';
const SESSION_SECRET = process.env.SESSION_SECRET || crypto.randomBytes(32).toString('hex');

// Server-side rate limiting state
const rateLimitBuckets = new Map<string, { count: number; resetAt: number }>();
function rateLimit(maxRequests: number, windowMs: number) {
  return (req: Request, res: Response, next: NextFunction) => {
    const ip = req.ip || 'unknown';
    const key = `${req.path}:${ip}`;
    const now = Date.now();
    const bucket = rateLimitBuckets.get(key);
    if (!bucket || bucket.resetAt <= now) {
      rateLimitBuckets.set(key, { count: 1, resetAt: now + windowMs });
      return next();
    }
    if (bucket.count >= maxRequests) {
      return res.status(429).json({
        error: 'Juda ko‘p so‘rov yuborildi. Biroz kutib qayta urinib ko‘ring.',
        code: 'RATE_LIMITED',
      });
    }
    bucket.count += 1;
    return next();
  };
}

// Password hashing via scrypt (per-user salt)
function hashPasscode(passcode: string): string {
  const salt = crypto.randomBytes(16).toString('hex');
  const derived = crypto.scryptSync(passcode, salt, 64).toString('hex');
  return `${salt}:${derived}`;
}

function verifyPasscode(passcode: string, storedHash: string): boolean {
  const [salt, keyHex] = storedHash.split(':');
  if (!salt || !keyHex) return false;
  const derived = crypto.scryptSync(passcode, salt, 64);
  const keyBuf = Buffer.from(keyHex, 'hex');
  return derived.length === keyBuf.length && crypto.timingSafeEqual(derived, keyBuf);
}

// HMAC-signed Bearer token issuance & verification
interface TokenPayload {
  sub: string;
  role: UserRole;
  shopId: string;
  branchId: string;
  fullName: string;
  phone: string;
  shopName: string;
  authSource: 'telegram' | 'web';
  exp: number;
}

function signAccessToken(payload: TokenPayload): string {
  const encoded = Buffer.from(JSON.stringify(payload), 'utf8').toString('base64url');
  const sig = crypto.createHmac('sha256', SESSION_SECRET).update(encoded).digest('base64url');
  return `${encoded}.${sig}`;
}

function verifyAccessToken(token: string): TokenPayload | null {
  const parts = token.split('.');
  if (parts.length !== 2) return null;
  const [encoded, sig] = parts;
  const expectedSig = crypto.createHmac('sha256', SESSION_SECRET).update(encoded).digest('base64url');
  const a = Buffer.from(sig, 'utf8');
  const b = Buffer.from(expectedSig, 'utf8');
  if (a.length !== b.length || !crypto.timingSafeEqual(a, b)) return null;
  try {
    const parsed = JSON.parse(Buffer.from(encoded, 'base64url').toString('utf8')) as TokenPayload;
    if (!parsed || typeof parsed.exp !== 'number' || parsed.exp < Date.now()) {
      return null;
    }
    return parsed;
  } catch {
    return null;
  }
}

// Real-mode shop data store (empty by default until user enters real records or connects Python backend!)
interface RealShopStore {
  adminPasscodeHash: string | null;
  ownerName: string;
  dataset: BusinessDataset;
  processedIdempotencyKeys: Set<string>;
  auditLogs: Array<{ id: string; actor: string; action: string; targetId?: string; createdAt: string }>;
}

const shopStore: RealShopStore = {
  adminPasscodeHash: null,
  ownerName: 'Do‘kon egasi',
  processedIdempotencyKeys: new Set(),
  auditLogs: [],
  dataset: {
    branches: [
      {
        id: 'br-main',
        name: 'Asosiy filial',
        address: 'Toshkent shahri',
        managerName: 'Do‘kon egasi',
        phone: '+998 90 000 00 00',
        status: 'Faol',
        monthlyTargetUzs: 100_000_000,
      },
    ],
    employees: [
      {
        id: 'emp-owner',
        fullName: 'Do‘kon egasi',
        phone: '+998 90 000 00 00',
        role: 'Owner',
        branchId: 'br-main',
        status: 'Faol',
        lastActiveAt: new Date().toISOString(),
      },
    ],
    customers: [],
    products: [],
    stockMovements: [],
    sales: [],
    debts: [],
    transactions: [],
    notifications: [],
    aiActions: [],
    settings: {
      shopName: 'Mening do‘konim',
      legalName: '',
      currency: 'UZS',
      timezone: 'Asia/Tashkent',
      language: 'uz',
      telegramBotConnected: Boolean(process.env.TELEGRAM_BOT_TOKEN),
      telegramBotUsername: '@NasiyaAI_Bot',
      connectedPaymentProviders: {
        payme: false,
        click: false,
        uzum: false,
      },
      notifications: {
        overdueDebtAlerts: true,
        lowStockAlerts: true,
        dailySummaryAt2000: true,
        unusualExpenseAlerts: true,
      },
      apiBaseUrl: '/api',
    },
  },
};

function recordAudit(actor: string, action: string, targetId?: string) {
  shopStore.auditLogs.unshift({
    id: `aud-${Date.now()}-${Math.random().toString(36).slice(2, 6)}`,
    actor,
    action,
    targetId,
    createdAt: new Date().toISOString(),
  });
  if (shopStore.auditLogs.length > 500) {
    shopStore.auditLogs.length = 500;
  }
}

interface AuthenticatedRequest extends Request {
  authUser?: AuthUser;
}

const revokedTokens = new Set<string>();

function requireAuth(req: AuthenticatedRequest, res: Response, next: NextFunction) {
  const authHeader = req.headers.authorization || '';
  if (!authHeader.startsWith('Bearer ')) {
    return res.status(401).json({
      error: 'Autentifikatsiya talab qilinadi. Tizimga kiring.',
      code: 'UNAUTHORIZED',
    });
  }
  const token = authHeader.slice(7).trim();
  if (revokedTokens.has(token)) {
    return res.status(401).json({
      error: 'Sessiya yakunlangan. Qayta kiring.',
      code: 'TOKEN_REVOKED',
    });
  }
  const payload = verifyAccessToken(token);
  if (!payload) {
    return res.status(401).json({
      error: 'Token yaroqsiz yoki muddati tugagan.',
      code: 'INVALID_TOKEN',
    });
  }
  req.authUser = {
    id: payload.sub,
    fullName: payload.fullName,
    phone: payload.phone,
    role: payload.role,
    shopId: payload.shopId,
    shopName: payload.shopName,
    branchId: payload.branchId,
    authSource: payload.authSource,
  };
  return next();
}

function requirePermission(permission: PermissionKey) {
  return (req: AuthenticatedRequest, res: Response, next: NextFunction) => {
    if (!req.authUser) {
      return res.status(401).json({ error: 'Autentifikatsiya talab qilinadi.' });
    }
    if (!hasPermission(req.authUser.role, permission)) {
      return res.status(403).json({
        error: `Sizning rolingiz (${req.authUser.role}) ushbu amalga ruxsatga ega emas.`,
        code: 'FORBIDDEN',
      });
    }
    return next();
  };
}

function getGeminiClient(): GoogleGenAI | null {
  const apiKey = process.env.GEMINI_API_KEY;
  if (!apiKey || apiKey === 'MY_GEMINI_API_KEY') return null;
  return new GoogleGenAI({
    apiKey,
    httpOptions: {
      headers: {
        'User-Agent': 'aistudio-build',
      },
    },
  });
}

async function startServer() {
  const app = express();
  app.use(express.json({ limit: '1mb' }));

  // Health check
  app.get('/api/health', (_req, res) => {
    res.json({
      status: 'ok',
      service: 'NasiyaAI API',
      timezone: 'Asia/Tashkent',
      geminiConfigured: Boolean(getGeminiClient()),
      telegramConfigured: Boolean(process.env.TELEGRAM_BOT_TOKEN),
      externalBackendUrl: process.env.EXTERNAL_BACKEND_API_URL || null,
    });
  });

  // Auth Bootstrap & Login Status
  app.get('/api/auth/bootstrap-status', (_req, res) => {
    const envPasscode = process.env.ADMIN_BOOTSTRAP_PASSCODE;
    const hasConfiguredPasscode = Boolean(envPasscode && envPasscode.trim().length > 0);
    res.json({
      needsBootstrap: !hasConfiguredPasscode && !shopStore.adminPasscodeHash,
      telegramBotConfigured: Boolean(process.env.TELEGRAM_BOT_TOKEN),
      geminiConfigured: Boolean(getGeminiClient()),
      externalBackendUrl: process.env.EXTERNAL_BACKEND_API_URL || null,
    });
  });

  // One-time atomic first-run admin setup
  app.post('/api/auth/bootstrap', rateLimit(10, 60_000), (req, res) => {
    const envPasscode = process.env.ADMIN_BOOTSTRAP_PASSCODE;
    if ((envPasscode && envPasscode.trim().length > 0) || shopStore.adminPasscodeHash) {
      return res.status(409).json({
        error: 'Administrator paroli allaqachon o‘rnatilgan.',
        code: 'ALREADY_BOOTSTRAPPED',
      });
    }

    const { passcode, fullName, shopName } = req.body ?? {};
    if (typeof passcode !== 'string' || passcode.trim().length < 6) {
      return res.status(400).json({ error: 'Parol kamida 6 ta belgidan iborat bo‘lishi kerak.' });
    }
    if (typeof fullName !== 'string' || fullName.trim().length < 2) {
      return res.status(400).json({ error: 'Ismingizni kiriting.' });
    }

    shopStore.adminPasscodeHash = hashPasscode(passcode.trim());
    shopStore.ownerName = fullName.trim();
    shopStore.dataset.employees[0].fullName = fullName.trim();
    shopStore.dataset.branches[0].managerName = fullName.trim();
    if (typeof shopName === 'string' && shopName.trim().length >= 2) {
      shopStore.dataset.settings.shopName = shopName.trim();
    }

    const user: AuthUser = {
      id: 'emp-owner',
      fullName: shopStore.ownerName,
      phone: '+998 90 000 00 00',
      role: 'Owner',
      shopId: 'shop-1',
      shopName: shopStore.dataset.settings.shopName,
      branchId: shopStore.dataset.branches[0].id,
      authSource: 'web',
    };

    const token = signAccessToken({
      sub: user.id,
      role: user.role,
      shopId: user.shopId,
      branchId: user.branchId,
      fullName: user.fullName,
      phone: user.phone,
      shopName: user.shopName,
      authSource: 'web',
      exp: Date.now() + 12 * 60 * 60 * 1000,
    });

    recordAudit(user.fullName, 'ADMIN_BOOTSTRAP_COMPLETED');
    return res.status(201).json({ token, user });
  });

  // Web login with passcode
  app.post('/api/auth/login', rateLimit(15, 60_000), (req, res) => {
    const { passcode, role } = req.body ?? {};
    if (typeof passcode !== 'string' || !passcode.trim()) {
      return res.status(400).json({ error: 'Parol kiritilishi shart.' });
    }

    const envPasscode = process.env.ADMIN_BOOTSTRAP_PASSCODE;
    let verified = false;
    if (envPasscode && envPasscode.trim().length > 0) {
      const a = Buffer.from(passcode.trim(), 'utf8');
      const b = Buffer.from(envPasscode.trim(), 'utf8');
      verified = a.length === b.length && crypto.timingSafeEqual(a, b);
    } else if (shopStore.adminPasscodeHash) {
      verified = verifyPasscode(passcode.trim(), shopStore.adminPasscodeHash);
    } else {
      return res.status(400).json({
        error: 'Tizim hali sozlanmagan. Avval administrator parolini yarating.',
        code: 'NEEDS_BOOTSTRAP',
      });
    }

    if (!verified) {
      return res.status(401).json({ error: 'Parol noto‘g‘ri.' });
    }

    const allowedRoles: UserRole[] = ['Owner', 'Admin', 'Seller', 'Accountant'];
    const selectedRole: UserRole = allowedRoles.includes(role) ? role : 'Owner';

    const user: AuthUser = {
      id: `user-${selectedRole.toLowerCase()}`,
      fullName: shopStore.ownerName,
      phone: '+998 90 000 00 00',
      role: selectedRole,
      shopId: 'shop-1',
      shopName: shopStore.dataset.settings.shopName,
      branchId: shopStore.dataset.branches[0]?.id || 'br-main',
      authSource: 'web',
    };

    const token = signAccessToken({
      sub: user.id,
      role: user.role,
      shopId: user.shopId,
      branchId: user.branchId,
      fullName: user.fullName,
      phone: user.phone,
      shopName: user.shopName,
      authSource: 'web',
      exp: Date.now() + 12 * 60 * 60 * 1000,
    });

    recordAudit(user.fullName, 'WEB_LOGIN');
    return res.json({ token, user });
  });

  // Telegram Mini App cryptographic initData auth
  app.post('/api/auth/telegram', rateLimit(20, 60_000), (req, res) => {
    const { initData } = req.body ?? {};
    const botToken = process.env.TELEGRAM_BOT_TOKEN;
    if (!botToken) {
      return res.status(503).json({
        error:
          'Serverda TELEGRAM_BOT_TOKEN sozlanmagan. Telegram Mini App autentifikatsiyasi uchun backendga bot tokenini kiriting.',
        code: 'TELEGRAM_NOT_CONFIGURED',
      });
    }

    const verification = verifyTelegramInitData(String(initData || ''), botToken);
    if (!verification.valid || !verification.user) {
      return res.status(401).json({
        error: verification.reason || 'Telegram autentifikatsiyasi muvaffaqiyatsiz.',
        code: 'TELEGRAM_AUTH_FAILED',
      });
    }

    const tgUser = verification.user;
    const fullName = [tgUser.first_name, tgUser.last_name].filter(Boolean).join(' ');
    const user: AuthUser = {
      id: `tg-${tgUser.id}`,
      fullName: fullName || 'Telegram foydalanuvchi',
      phone: '',
      telegramId: String(tgUser.id),
      telegramUsername: tgUser.username,
      role: 'Owner',
      shopId: 'shop-1',
      shopName: shopStore.dataset.settings.shopName,
      branchId: shopStore.dataset.branches[0]?.id || 'br-main',
      authSource: 'telegram',
    };

    const token = signAccessToken({
      sub: user.id,
      role: user.role,
      shopId: user.shopId,
      branchId: user.branchId,
      fullName: user.fullName,
      phone: user.phone,
      shopName: user.shopName,
      authSource: 'telegram',
      exp: Date.now() + 12 * 60 * 60 * 1000,
    });

    recordAudit(user.fullName, 'TELEGRAM_MINI_APP_LOGIN', String(tgUser.id));
    return res.json({ token, user });
  });

  app.post('/api/auth/refresh', requireAuth, (req: AuthenticatedRequest, res) => {
    const u = req.authUser!;
    const token = signAccessToken({
      sub: u.id,
      role: u.role,
      shopId: u.shopId,
      branchId: u.branchId,
      fullName: u.fullName,
      phone: u.phone,
      shopName: u.shopName,
      authSource: u.authSource === 'telegram' ? 'telegram' : 'web',
      exp: Date.now() + 12 * 60 * 60 * 1000,
    });
    res.json({ token });
  });

  app.post('/api/auth/logout', (req, res) => {
    const authHeader = req.headers.authorization || '';
    if (authHeader.startsWith('Bearer ')) {
      revokedTokens.add(authHeader.slice(7).trim());
    }
    res.json({ ok: true });
  });

  app.get('/api/auth/me', requireAuth, (req: AuthenticatedRequest, res) => {
    res.json(req.authUser);
  });

  // Dashboard overview
  app.get('/api/dashboard/overview', requireAuth, (req: AuthenticatedRequest, res) => {
    const summary = computeFinancialSummary({
      sales: shopStore.dataset.sales,
      debts: shopStore.dataset.debts,
      transactions: shopStore.dataset.transactions,
      products: shopStore.dataset.products,
    });
    res.json({ ...shopStore.dataset, summary });
  });

  // Finance
  app.get('/api/finance/summary', requireAuth, requirePermission('view_finance'), (_req, res) => {
    const summary = computeFinancialSummary({
      sales: shopStore.dataset.sales,
      debts: shopStore.dataset.debts,
      transactions: shopStore.dataset.transactions,
      products: shopStore.dataset.products,
    });
    res.json(summary);
  });

  app.get('/api/finance/transactions', requireAuth, requirePermission('view_finance'), (_req, res) => {
    res.json(shopStore.dataset.transactions);
  });

  app.post(
    '/api/finance/transactions',
    requireAuth,
    requirePermission('create_transaction'),
    (req: AuthenticatedRequest, res) => {
      const { amount, category, description, date, type, paymentMethod, branchId } = req.body ?? {};
      const numAmount = Number(amount);
      if (!Number.isFinite(numAmount) || numAmount <= 0) {
        return res.status(400).json({ error: 'Summa 0 dan katta bo‘lishi kerak.' });
      }
      if (!['Boshqa kirim', 'Xarajat'].includes(type)) {
        return res.status(400).json({ error: 'Tranzaksiya turi yaroqsiz.' });
      }
      if (!description || String(description).trim().length < 3) {
        return res.status(400).json({ error: 'Tavsif kamida 3 ta belgi bo‘lsin.' });
      }
      const tx: FinanceTransaction = {
        id: `tx-${Date.now()}`,
        date: date || new Date().toISOString(),
        description: String(description).trim(),
        category: String(category || 'Boshqa').trim(),
        type,
        paymentMethod: paymentMethod || 'Naqd',
        amount: Math.round(numAmount),
        branchId: branchId || shopStore.dataset.branches[0].id,
        status: 'Tasdiqlangan',
      };
      shopStore.dataset.transactions.unshift(tx);
      recordAudit(req.authUser!.fullName, 'CREATE_TRANSACTION', tx.id);
      return res.status(201).json(tx);
    }
  );

  // Debts
  app.get('/api/debts', requireAuth, requirePermission('view_debts'), (_req, res) => {
    res.json(shopStore.dataset.debts);
  });

  app.get('/api/debts/:id', requireAuth, requirePermission('view_debts'), (req, res) => {
    const debt = shopStore.dataset.debts.find((d) => d.id === req.params.id);
    if (!debt) return res.status(404).json({ error: 'Qarz yozuvi topilmadi.' });
    return res.json(debt);
  });

  app.post('/api/debts', requireAuth, requirePermission('create_debt'), (req: AuthenticatedRequest, res) => {
    const body = req.body ?? {};
    const amount = Math.round(Number(body.amount));
    const initialPayment = Math.round(Number(body.initialPayment || 0));
    if (!Number.isFinite(amount) || amount <= 0) {
      return res.status(400).json({ error: 'Qarz summasi 0 dan katta bo‘lishi shart.' });
    }
    if (!Number.isFinite(initialPayment) || initialPayment < 0 || initialPayment >= amount) {
      return res.status(400).json({ error: 'Boshlang‘ich to‘lov 0 va jami summadan kichik bo‘lishi kerak.' });
    }

    let customer = shopStore.dataset.customers.find((c) => c.id === body.customerId);
    if (!customer && body.newCustomerName && body.newCustomerPhone) {
      customer = {
        id: `cust-${Date.now()}`,
        fullName: String(body.newCustomerName).trim(),
        phone: String(body.newCustomerPhone).trim(),
        branchId: body.branchId || shopStore.dataset.branches[0].id,
        status: 'Faol',
        createdAt: new Date().toISOString(),
      };
      shopStore.dataset.customers.unshift(customer);
    }
    if (!customer) {
      return res.status(400).json({ error: 'Mijoz tanlanmagan yoki yaratilmagan.' });
    }

    const remainingAmount = amount - initialPayment;
    const dueDate = body.dueDate || new Date(Date.now() + 30 * 86400_000).toISOString();
    const debtId = `debt-${Date.now()}`;
    const payments = [];
    if (initialPayment > 0) {
      const txId = `tx-${Date.now()}`;
      shopStore.dataset.transactions.unshift({
        id: txId,
        date: body.date || new Date().toISOString(),
        description: `Qarz boshlang‘ich to‘lovi #${debtId} (${customer.fullName})`,
        category: 'Qarz undiruvi',
        type: 'Qarz undiruvi',
        paymentMethod: body.paymentMethod || 'Naqd',
        amount: initialPayment,
        branchId: body.branchId || customer.branchId,
        status: 'Tasdiqlangan',
        relatedRecordId: debtId,
      });
      payments.push({
        id: `dp-${Date.now()}`,
        debtId,
        amount: initialPayment,
        paymentMethod: body.paymentMethod || 'Naqd',
        note: 'Boshlang‘ich to‘lov',
        receivedBy: req.authUser!.fullName,
        createdAt: new Date().toISOString(),
        transactionId: txId,
      });
    }

    const newDebt: Debt = {
      id: debtId,
      customerId: customer.id,
      customerName: customer.fullName,
      customerPhone: customer.phone,
      branchId: body.branchId || customer.branchId,
      description: String(body.description || 'Nasiya qarz').trim(),
      originalAmount: amount,
      paidAmount: initialPayment,
      remainingAmount,
      createdAt: body.date || new Date().toISOString(),
      dueDate,
      status: resolveDebtStatus(remainingAmount, initialPayment, dueDate),
      notes: body.notes ? String(body.notes) : undefined,
      payments,
      reminders: [],
    };
    shopStore.dataset.debts.unshift(newDebt);
    recordAudit(req.authUser!.fullName, 'CREATE_DEBT', debtId);
    return res.status(201).json(newDebt);
  });

  app.post(
    '/api/debts/:id/payments',
    requireAuth,
    requirePermission('accept_payment'),
    (req: AuthenticatedRequest, res) => {
      const { amount, paymentMethod, note, idempotencyKey } = req.body ?? {};
      if (idempotencyKey && shopStore.processedIdempotencyKeys.has(String(idempotencyKey))) {
        return res.status(409).json({
          error: 'Takroriy to‘lov aniqlandi. Ushbu so‘rov allaqachon qayta ishlangan.',
          code: 'DUPLICATE_SUBMISSION',
        });
      }

      const debt = shopStore.dataset.debts.find((d) => d.id === req.params.id);
      if (!debt) return res.status(404).json({ error: 'Qarz topilmadi.' });

      try {
        const updated = applyDebtPayment(debt, Number(amount));
        const tx: FinanceTransaction = {
          id: `tx-${Date.now()}`,
          date: new Date().toISOString(),
          description: `Qarz to‘lovi #${debt.id} (${debt.customerName})`,
          category: 'Qarz undiruvi',
          type: 'Qarz undiruvi',
          paymentMethod: paymentMethod || 'Naqd',
          amount: Math.round(Number(amount)),
          branchId: debt.branchId,
          status: 'Tasdiqlangan',
          relatedRecordId: debt.id,
        };
        debt.paidAmount = updated.paidAmount;
        debt.remainingAmount = updated.remainingAmount;
        debt.status = updated.status;
        debt.payments.unshift({
          id: `dp-${Date.now()}`,
          idempotencyKey: idempotencyKey ? String(idempotencyKey) : undefined,
          debtId: debt.id,
          amount: tx.amount,
          paymentMethod: tx.paymentMethod,
          note: note ? String(note) : undefined,
          receivedBy: req.authUser!.fullName,
          createdAt: tx.date,
          transactionId: tx.id,
        });
        shopStore.dataset.transactions.unshift(tx);
        if (idempotencyKey) {
          shopStore.processedIdempotencyKeys.add(String(idempotencyKey));
        }
        recordAudit(req.authUser!.fullName, 'ACCEPT_DEBT_PAYMENT', debt.id);
        return res.status(201).json({ debt, transaction: tx });
      } catch (err) {
        return res.status(400).json({
          error: err instanceof Error ? err.message : 'To‘lovni saqlashda xatolik.',
        });
      }
    }
  );

  app.post(
    '/api/debts/:id/reminders',
    requireAuth,
    requirePermission('send_reminder'),
    (req: AuthenticatedRequest, res) => {
      const debt = shopStore.dataset.debts.find((d) => d.id === req.params.id);
      if (!debt) return res.status(404).json({ error: 'Qarz topilmadi.' });
      const msg = String(req.body?.message || '').trim();
      if (!msg) return res.status(400).json({ error: 'Eslatma matni bo‘sh bo‘lmasligi kerak.' });

      const hasExternalBot = Boolean(process.env.EXTERNAL_BACKEND_API_URL);
      const reminder = {
        id: `rem-${Date.now()}`,
        debtId: debt.id,
        channel: 'Telegram Bot' as const,
        message: msg,
        sentAt: new Date().toISOString(),
        status: hasExternalBot ? ('Yuborildi' as const) : ('Demo (simulyatsiya)' as const),
      };
      debt.reminders.unshift(reminder);
      recordAudit(req.authUser!.fullName, 'SEND_DEBT_REMINDER', debt.id);
      return res.status(201).json({ reminder, deliveredViaBot: hasExternalBot });
    }
  );

  // Customers
  app.get('/api/customers', requireAuth, requirePermission('view_customers'), (_req, res) => {
    res.json(shopStore.dataset.customers);
  });

  app.get('/api/customers/:id', requireAuth, requirePermission('view_customers'), (req, res) => {
    const customer = shopStore.dataset.customers.find((c) => c.id === req.params.id);
    if (!customer) return res.status(404).json({ error: 'Mijoz topilmadi.' });
    return res.json(customer);
  });

  app.post(
    '/api/customers',
    requireAuth,
    requirePermission('manage_customers'),
    (req: AuthenticatedRequest, res) => {
      const { fullName, phone, address, notes, branchId, status } = req.body ?? {};
      if (!fullName || String(fullName).trim().length < 2) {
        return res.status(400).json({ error: 'Mijoz ismini kiriting.' });
      }
      if (!phone || String(phone).trim().length < 9) {
        return res.status(400).json({ error: 'Mijoz telefon raqamini kiriting.' });
      }
      const customer = {
        id: `cust-${Date.now()}`,
        fullName: String(fullName).trim(),
        phone: String(phone).trim(),
        address: address ? String(address).trim() : '',
        notes: notes ? String(notes).trim() : '',
        branchId: branchId || shopStore.dataset.branches[0].id,
        status: status || 'Faol',
        createdAt: new Date().toISOString(),
      };
      shopStore.dataset.customers.unshift(customer);
      recordAudit(req.authUser!.fullName, 'CREATE_CUSTOMER', customer.id);
      return res.status(201).json(customer);
    }
  );

  app.patch(
    '/api/customers/:id',
    requireAuth,
    requirePermission('manage_customers'),
    (req: AuthenticatedRequest, res) => {
      const idx = shopStore.dataset.customers.findIndex((c) => c.id === req.params.id);
      if (idx === -1) return res.status(404).json({ error: 'Mijoz topilmadi.' });
      shopStore.dataset.customers[idx] = {
        ...shopStore.dataset.customers[idx],
        ...req.body,
        id: shopStore.dataset.customers[idx].id,
      };
      recordAudit(req.authUser!.fullName, 'UPDATE_CUSTOMER', req.params.id);
      return res.json(shopStore.dataset.customers[idx]);
    }
  );

  // Sales (strict server-side deterministic calculation + inventory deduction + debt creation)
  app.get('/api/sales', requireAuth, requirePermission('view_sales'), (_req, res) => {
    res.json(shopStore.dataset.sales);
  });

  app.post('/api/sales', requireAuth, requirePermission('create_sale'), (req: AuthenticatedRequest, res) => {
    const {
      customerId,
      branchId,
      items,
      discountAmount,
      paidAmount,
      paymentMethod,
      dueDate,
      idempotencyKey,
    } = req.body ?? {};

    if (idempotencyKey && shopStore.processedIdempotencyKeys.has(String(idempotencyKey))) {
      return res.status(409).json({
        error: 'Takroriy savdo yuborildi. Ushbu savdo allaqachon saqlangan.',
        code: 'DUPLICATE_SUBMISSION',
      });
    }

    const customer = shopStore.dataset.customers.find((c) => c.id === customerId);
    if (!customer) return res.status(400).json({ error: 'Mijoz topilmadi.' });
    if (!Array.isArray(items) || items.length === 0) {
      return res.status(400).json({ error: 'Kamida bitta mahsulot tanlang.' });
    }

    const resolvedItems = [];
    for (const row of items) {
      const product = shopStore.dataset.products.find((p) => p.id === row.productId);
      if (!product) {
        return res.status(400).json({ error: `Mahsulot topilmadi (${row.productId}).` });
      }
      const qty = Number(row.quantity);
      if (!Number.isInteger(qty) || qty <= 0) {
        return res.status(400).json({ error: `"${product.name}" miqdori yaroqsiz.` });
      }
      if (product.quantity < qty) {
        return res.status(400).json({
          error: `Omborda "${product.name}" yetarli emas (mavjud: ${product.quantity} dona).`,
        });
      }
      resolvedItems.push({
        productId: product.id,
        productName: product.name,
        quantity: qty,
        unitPrice: Number(row.unitPrice ?? product.sellingPrice),
        purchasePrice: product.purchasePrice,
      });
    }

    try {
      const calc = calculateSaleTotals({
        items: resolvedItems,
        discountAmount: Number(discountAmount || 0),
        paidAmount: Number(paidAmount || 0),
      });

      const saleId = `sale-${Date.now()}`;
      const nowIso = new Date().toISOString();
      const targetBranchId = branchId || customer.branchId;

      // Deduct inventory only after validation passes
      for (const item of calc.items) {
        const product = shopStore.dataset.products.find((p) => p.id === item.productId)!;
        product.quantity -= item.quantity;
        product.status =
          product.quantity <= 0
            ? 'Tugagan'
            : product.quantity <= product.minStockLevel
            ? 'Kam qolgan'
            : 'Mavjud';
        shopStore.dataset.stockMovements.unshift({
          id: `sm-${Date.now()}-${Math.random().toString(36).slice(2, 5)}`,
          productId: product.id,
          productName: product.name,
          branchId: targetBranchId,
          type: 'Sotuv',
          quantityDelta: -item.quantity,
          note: `Savdo #${saleId} (${customer.fullName})`,
          createdAt: nowIso,
          actorName: req.authUser!.fullName,
        });
      }

      const sale: Sale = {
        id: saleId,
        idempotencyKey: idempotencyKey ? String(idempotencyKey) : undefined,
        customerId: customer.id,
        customerName: customer.fullName,
        branchId: targetBranchId,
        items: calc.items,
        subtotal: calc.subtotal,
        discountAmount: calc.discountAmount,
        totalAmount: calc.totalAmount,
        cogsTotal: calc.cogsTotal,
        paidAmount: calc.paidAmount,
        debtAmount: calc.debtAmount,
        paymentMethod: paymentMethod || 'Naqd',
        paymentStatus: calc.paymentStatus,
        sellerName: req.authUser!.fullName,
        createdAt: nowIso,
      };
      shopStore.dataset.sales.unshift(sale);

      if (calc.paidAmount > 0) {
        shopStore.dataset.transactions.unshift({
          id: `tx-${Date.now()}`,
          date: nowIso,
          description: `Savdo #${saleId} to‘lovi (${customer.fullName})`,
          category: 'Savdo',
          type: 'Savdo tushumi',
          paymentMethod: sale.paymentMethod,
          amount: calc.paidAmount,
          branchId: targetBranchId,
          status: 'Tasdiqlangan',
          relatedRecordId: saleId,
        });
      }

      let createdDebt: Debt | undefined;
      if (calc.debtAmount > 0) {
        const debtDue = dueDate || new Date(Date.now() + 30 * 86400_000).toISOString();
        createdDebt = {
          id: `debt-${Date.now()}`,
          saleId,
          customerId: customer.id,
          customerName: customer.fullName,
          customerPhone: customer.phone,
          branchId: targetBranchId,
          description: `${calc.items.map((i) => `${i.productName} (${i.quantity})`).join(', ')} — nasiya`,
          originalAmount: calc.debtAmount,
          paidAmount: 0,
          remainingAmount: calc.debtAmount,
          createdAt: nowIso,
          dueDate: debtDue,
          status: resolveDebtStatus(calc.debtAmount, 0, debtDue, nowIso),
          payments: [],
          reminders: [],
        };
        shopStore.dataset.debts.unshift(createdDebt);
      }

      if (idempotencyKey) {
        shopStore.processedIdempotencyKeys.add(String(idempotencyKey));
      }
      recordAudit(req.authUser!.fullName, 'CREATE_SALE', saleId);
      return res.status(201).json({ sale, debt: createdDebt });
    } catch (err) {
      return res.status(400).json({
        error: err instanceof Error ? err.message : 'Savdoni hisoblashda xatolik.',
      });
    }
  });

  // Inventory
  app.get('/api/products', requireAuth, requirePermission('view_inventory'), (_req, res) => {
    res.json(shopStore.dataset.products);
  });

  app.post(
    '/api/products',
    requireAuth,
    requirePermission('manage_inventory'),
    (req: AuthenticatedRequest, res) => {
      const { name, sku, category, purchasePrice, sellingPrice, quantity, minStockLevel, branchId } =
        req.body ?? {};
      if (!name || String(name).trim().length < 2) {
        return res.status(400).json({ error: 'Mahsulot nomini kiriting.' });
      }
      const qty = Math.max(0, Math.round(Number(quantity || 0)));
      const minLvl = Math.max(0, Math.round(Number(minStockLevel || 0)));
      const product: Product = {
        id: `prod-${Date.now()}`,
        name: String(name).trim(),
        sku: String(sku || `SKU-${Date.now().toString().slice(-5)}`).trim(),
        category: String(category || 'Boshqa').trim(),
        purchasePrice: Math.max(0, Math.round(Number(purchasePrice || 0))),
        sellingPrice: Math.max(0, Math.round(Number(sellingPrice || 0))),
        quantity: qty,
        minStockLevel: minLvl,
        branchId: branchId || shopStore.dataset.branches[0].id,
        status: qty <= 0 ? 'Tugagan' : qty <= minLvl ? 'Kam qolgan' : 'Mavjud',
      };
      shopStore.dataset.products.unshift(product);
      recordAudit(req.authUser!.fullName, 'CREATE_PRODUCT', product.id);
      return res.status(201).json(product);
    }
  );

  app.patch(
    '/api/products/:id',
    requireAuth,
    requirePermission('manage_inventory'),
    (req: AuthenticatedRequest, res) => {
      const idx = shopStore.dataset.products.findIndex((p) => p.id === req.params.id);
      if (idx === -1) return res.status(404).json({ error: 'Mahsulot topilmadi.' });
      const merged = { ...shopStore.dataset.products[idx], ...req.body, id: req.params.id };
      merged.status =
        merged.quantity <= 0
          ? 'Tugagan'
          : merged.quantity <= merged.minStockLevel
          ? 'Kam qolgan'
          : 'Mavjud';
      shopStore.dataset.products[idx] = merged;
      recordAudit(req.authUser!.fullName, 'UPDATE_PRODUCT', req.params.id);
      return res.json(merged);
    }
  );

  // Analytics & Reports
  app.get('/api/analytics/overview', requireAuth, requirePermission('view_analytics'), (_req, res) => {
    const summary = computeFinancialSummary({
      sales: shopStore.dataset.sales,
      debts: shopStore.dataset.debts,
      transactions: shopStore.dataset.transactions,
      products: shopStore.dataset.products,
    });
    res.json({ summary, health: computeBusinessHealthHeuristic(summary, shopStore.dataset.products) });
  });

  app.get('/api/analytics/sales', requireAuth, requirePermission('view_analytics'), (_req, res) => {
    res.json(shopStore.dataset.sales);
  });

  app.get('/api/analytics/debts', requireAuth, requirePermission('view_analytics'), (_req, res) => {
    res.json(shopStore.dataset.debts);
  });

  app.get('/api/reports/:period', requireAuth, requirePermission('view_reports'), (req, res) => {
    const summary = computeFinancialSummary({
      sales: shopStore.dataset.sales,
      debts: shopStore.dataset.debts,
      transactions: shopStore.dataset.transactions,
      products: shopStore.dataset.products,
    });
    res.json({ period: req.params.period, generatedAt: new Date().toISOString(), summary });
  });

  // Branches, Employees, Notifications, Settings
  app.get('/api/branches', requireAuth, (_req, res) => {
    res.json(shopStore.dataset.branches);
  });

  app.post('/api/branches', requireAuth, requirePermission('manage_branches'), (req, res) => {
    const { name, address, managerName, phone, monthlyTargetUzs } = req.body ?? {};
    const branch = {
      id: `br-${Date.now()}`,
      name: String(name || '').trim(),
      address: String(address || '').trim(),
      managerName: String(managerName || '').trim(),
      phone: String(phone || '').trim(),
      status: 'Faol' as const,
      monthlyTargetUzs: Number(monthlyTargetUzs || 0),
    };
    shopStore.dataset.branches.push(branch);
    res.status(201).json(branch);
  });

  app.get('/api/employees', requireAuth, requirePermission('view_employees'), (_req, res) => {
    res.json(shopStore.dataset.employees);
  });

  app.post('/api/employees', requireAuth, requirePermission('manage_employees'), (req, res) => {
    const { fullName, phone, role, branchId } = req.body ?? {};
    const emp = {
      id: `emp-${Date.now()}`,
      fullName: String(fullName || '').trim(),
      phone: String(phone || '').trim(),
      role: (['Owner', 'Admin', 'Seller', 'Accountant'].includes(role) ? role : 'Seller') as UserRole,
      branchId: branchId || shopStore.dataset.branches[0].id,
      status: 'Faol' as const,
      lastActiveAt: new Date().toISOString(),
    };
    shopStore.dataset.employees.push(emp);
    res.status(201).json(emp);
  });

  app.get('/api/notifications', requireAuth, (_req, res) => {
    res.json(shopStore.dataset.notifications);
  });

  app.patch('/api/notifications/:id/read', requireAuth, (req, res) => {
    const n = shopStore.dataset.notifications.find((item) => item.id === req.params.id);
    if (!n) return res.status(404).json({ error: 'Bildirishnoma topilmadi.' });
    n.isRead = true;
    return res.json(n);
  });

  app.get('/api/settings', requireAuth, (_req, res) => {
    res.json(shopStore.dataset.settings);
  });

  app.patch('/api/settings', requireAuth, requirePermission('manage_settings'), (req, res) => {
    shopStore.dataset.settings = {
      ...shopStore.dataset.settings,
      ...req.body,
      currency: 'UZS',
      timezone: 'Asia/Tashkent',
    };
    res.json(shopStore.dataset.settings);
  });

  // Server-side AI Intelligence endpoints (Gemini SDK strictly on backend!)
  app.post('/api/ai/chat', rateLimit(20, 60_000), async (req, res) => {
    const { question, context } = req.body ?? {};
    if (!question || typeof question !== 'string' || !question.trim()) {
      return res.status(400).json({ error: 'Savol matnini kiriting.' });
    }

    const ai = getGeminiClient();
    if (!ai) {
      return res.status(503).json({
        error:
          'Serverda GEMINI_API_KEY sozlanmagan. AI tahlilchi ishlashi uchun Settings > Secrets bo‘limida API kalitni belgilang.',
        code: 'GEMINI_NOT_CONFIGURED',
      });
    }

    const summarySnapshot =
      context && typeof context === 'object'
        ? context
        : computeFinancialSummary({
            sales: shopStore.dataset.sales,
            debts: shopStore.dataset.debts,
            transactions: shopStore.dataset.transactions,
            products: shopStore.dataset.products,
          });

    try {
      const response = await ai.models.generateContent({
        model: 'gemini-4-hydrogen',
        contents: `Foydalanuvchi savoli: "${question.trim()}"\n\nBiznesning deterministik moliyaviy ma'lumotlari (UZS, Asia/Tashkent):\n${JSON.stringify(
          summarySnapshot,
          null,
          2
        )}`,
        config: {
          systemInstruction:
            'Siz NasiyaAI biznes tahlilchisiz. Faqat o‘zbek (lotin) tilida javob bering. Hech qachon buxgalteriya raqamlarini o‘zingiz o‘ylab topmang; faqat berilgan JSON ma’lumotlarga tayaning. Javobda: 1) aniq raqamlar va sana oralig‘ini ayting, 2) faktlar va taxminiy baholarni ajrating, 3) amaliy tavsiyalar bering, 4) agar ma’lumot yetishmasa ochiq ayting.',
          responseMimeType: 'application/json',
          responseSchema: {
            type: Type.OBJECT,
            properties: {
              answer: { type: Type.STRING },
              dateRangeUsed: { type: Type.STRING },
              basis: { type: Type.STRING },
              isEstimate: { type: Type.BOOLEAN },
              recommendations: {
                type: Type.ARRAY,
                items: { type: Type.STRING },
              },
              missingData: { type: Type.STRING },
            },
            required: ['answer', 'dateRangeUsed', 'basis', 'isEstimate', 'recommendations'],
          },
        },
      });

      const raw = (response.text || '{}').trim();
      const parsed = JSON.parse(raw) as {
        answer: string;
        dateRangeUsed: string;
        basis: string;
        isEstimate: boolean;
        recommendations: string[];
        missingData?: string;
      };

      return res.json({
        id: `ai-${Date.now()}`,
        role: 'assistant',
        text: parsed.answer,
        createdAt: new Date().toISOString(),
        dateRangeUsed: parsed.dateRangeUsed,
        basis: parsed.basis,
        isEstimate: Boolean(parsed.isEstimate),
        recommendations: Array.isArray(parsed.recommendations) ? parsed.recommendations : [],
        missingData: parsed.missingData || undefined,
      });
    } catch (err) {
      return res.status(502).json({
        error:
          err instanceof Error
            ? `Gemini AI xatosi: ${err.message}`
            : 'AI javobini olishda xatolik yuz berdi.',
        code: 'AI_UPSTREAM_ERROR',
      });
    }
  });

  app.get('/api/ai/insights', requireAuth, (_req, res) => {
    const summary = computeFinancialSummary({
      sales: shopStore.dataset.sales,
      debts: shopStore.dataset.debts,
      transactions: shopStore.dataset.transactions,
      products: shopStore.dataset.products,
    });
    res.json({
      generatedAt: new Date().toISOString(),
      insights: [
        {
          id: 'ins-real-1',
          category: 'briefing',
          severity: 'info',
          title: 'Moliyaviy holat xulosasi',
          summary: `Jami savdo ${formatUZS(summary.totalSalesRevenue)}, qolgan qarz ${formatUZS(
            summary.outstandingDebt
          )}.`,
          basis: 'Deterministik backend hisob-kitobi',
          factVsEstimate: 'Fakt',
          recommendedAction: 'Qarzlar bo‘limini tekshiring',
        },
      ],
    });
  });

  app.get('/api/ai/forecasts', requireAuth, (_req, res) => {
    const summary = computeFinancialSummary({
      sales: shopStore.dataset.sales,
      debts: shopStore.dataset.debts,
      transactions: shopStore.dataset.transactions,
      products: shopStore.dataset.products,
    });
    res.json({
      forecasts: [
        {
          id: 'fc-real-1',
          metricLabel: 'Kutilayotgan qarz undiruvi (30 kun)',
          horizon: 'Kelgusi 30 kun',
          projectedValueUzs: Math.round(summary.outstandingDebt * 0.55),
          confidenceLabel: shopStore.dataset.sales.length > 3 ? 'O‘rta' : 'Past',
          historicalPeriodUsed: 'Joriy aktiv qarzlar portfeli',
          assumptions: 'Taxminiy prognoz: aktiv qarzlarning o‘rtacha 55% undirilishi farazi.',
        },
      ],
    });
  });

  app.post('/api/ai/actions/:id/approve', requireAuth, requirePermission('approve_ai_actions'), (req: AuthenticatedRequest, res) => {
    const action = shopStore.dataset.aiActions.find((a) => a.id === req.params.id);
    if (action) {
      action.status = 'Tasdiqlangan';
    }
    recordAudit(req.authUser!.fullName, 'APPROVE_AI_ACTION', req.params.id);
    res.json({ status: 'Tasdiqlangan', message: 'Amal foydalanuvchi tasdig‘i bilan bajarildi.' });
  });

  // Vite middleware in dev / static dist in production
  if (NODE_ENV === 'production') {
    const distDir = path.resolve(process.cwd(), 'dist');
    app.use(express.static(distDir));
    app.get('*', (_req, res) => {
      res.sendFile(path.join(distDir, 'index.html'));
    });
  } else {
    const { createServer: createViteServer } = await import('vite');
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`NasiyaAI server listening on http://0.0.0.0:${PORT}`);
  });
}

startServer().catch((err) => {
  console.error('Failed to start NasiyaAI server:', err);
  process.exit(1);
});
